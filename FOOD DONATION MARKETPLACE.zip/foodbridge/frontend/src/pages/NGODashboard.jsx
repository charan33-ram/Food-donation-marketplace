import { useCallback, useEffect, useMemo, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { AlertTriangle, ArrowRight, Check, Clock3, Filter, Leaf, MapPin, Search, ShieldCheck, Utensils, X } from 'lucide-react';
import { api, fmtDate, messageOf, timeLeft } from '../api';
import { useAuth } from '../auth';
import { DashNav, EmptyState, FoodCard, Loading, PageHeader, StatCard, StatusBadge, useToast } from '../components';

function PickupHistoryRow({ request, onAction, busy }) {
  return <article className="ngo-request-row"><span className={`ngo-request-symbol ngo-symbol-${request.status.toLowerCase().replaceAll(' ', '-')}`}>{request.status === 'Completed' ? <Check size={17} /> : <Clock3 size={17} />}</span><div className="ngo-request-main"><div className="ngo-request-heading"><strong>{request.foodName}</strong><StatusBadge status={request.status} /></div><p>{request.quantity} portions · {request.donation?.city || request.city || '—'} · pickup {fmtDate(request.pickupAt)}</p><small>Donor: {request.donor?.organizationName || request.donor?.name || 'Food donor'}</small></div><div className="ngo-request-actions">{request.status === 'Requested' && <button disabled={busy} className="button button-quiet button-small" onClick={() => onAction(request.id, 'cancel')}>Cancel request</button>}{request.status === 'Approved' && <button disabled={busy} className="button button-primary button-small" onClick={() => onAction(request.id, 'picked-up')}>Mark picked up</button>}{request.status === 'Picked Up' && <button disabled={busy} className="button button-secondary button-small" onClick={() => onAction(request.id, 'complete')}>Confirm completed</button>}{['Rejected', 'Cancelled', 'Completed'].includes(request.status) && <span className="request-finished">{request.status === 'Completed' ? 'Added to impact' : 'Closed'}</span>}</div></article>;
}

export default function NGODashboard() {
  const { user } = useAuth();
  const location = useLocation();
  const toast = useToast();
  const [donations, setDonations] = useState([]);
  const [requests, setRequests] = useState([]);
  const [impact, setImpact] = useState(null);
  const [categories, setCategories] = useState([]);
  const [filters, setFilters] = useState({ search: '', city: user?.city || '', category: '', foodType: '', minQuantity: '', expiryWithinHours: '', sort: 'expiry' });
  const [submitted, setSubmitted] = useState({ search: '', city: user?.city || '', category: '', foodType: '', minQuantity: '', expiryWithinHours: '', sort: 'expiry' });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [actionId, setActionId] = useState('');

  const query = useMemo(() => {
    const params = new URLSearchParams();
    Object.entries(submitted).forEach(([key, value]) => { if (value) params.set(key, value); });
    params.set('limit', '60');
    return params.toString();
  }, [submitted]);
  const load = useCallback(async () => {
    setError('');
    try {
      const [food, pickup, stats, cats] = await Promise.all([api.get(`/donations?${query}`), api.get('/pickup-requests'), api.get('/stats/impact?scope=me'), api.get('/categories')]);
      setDonations(food.data.items || []); setRequests(pickup.data.items || []); setImpact(stats.data); setCategories(cats.data.items || []);
    } catch (e) { setError(messageOf(e)); }
    finally { setLoading(false); }
  }, [query]);
  useEffect(() => { load(); }, [load]);
  useEffect(() => { if (location.hash === '#requests') setTimeout(() => document.getElementById('requests')?.scrollIntoView({ behavior: 'smooth' }), 150); }, [location.hash]);
  async function action(id, verb) {
    setActionId(id);
    try { const { data } = await api.patch(`/pickup-requests/${id}/${verb}`); toast(data.message); await load(); }
    catch (e) { toast(messageOf(e), 'error'); }
    finally { setActionId(''); }
  }
  function resetFilters() {
    const clean = { search: '', city: '', category: '', foodType: '', minQuantity: '', expiryWithinHours: '', sort: 'expiry' };
    setFilters(clean); setSubmitted(clean);
  }
  if (loading) return <DashNav role="NGO" title="Find food"><Loading label="Finding food near your community…" /></DashNav>;
  const pending = requests.filter((r) => ['Requested', 'Approved', 'Picked Up'].includes(r.status));
  return <DashNav role="NGO" title="Find food"><div className="dashboard-content">
    <PageHeader eyebrow="COMMUNITY PARTNER WORKSPACE" title={`Hello, ${user?.organizationName || user?.name?.split(' ')[0] || 'friend'}.`} description="Find a good meal for someone in your community." action={<Link to="/history" className="button button-secondary"><Leaf size={16} /> My food history</Link>} />
    {!user?.ngoVerified && <div className="verification-note"><ShieldCheck size={18} /><span><strong>Your organization is not verified yet.</strong> You can use FoodBridge while our team reviews your organization details.</span><Link to="/profile">Complete profile <ArrowRight size={14} /></Link></div>}
    {error && <div className="dashboard-error"><AlertTriangle size={16} />{error}<button onClick={load}>Retry</button></div>}
    <div className="dashboard-stats-grid ngo-stats"><StatCard label="Nearby food listings" value={donations.length} caption="Available for a safe pickup" icon={MapPin} /><StatCard label="My pickup requests" value={requests.length} caption={`${pending.length} active handoffs`} icon={Clock3} tone="orange" /><StatCard label="Meals received" value={(impact?.mealsProvided ?? 0).toLocaleString('en-IN')} caption={`${impact?.kilogramsSaved ?? 0} kg food rescued`} icon={Utensils} tone="blue" /><StatCard label="Completed pickups" value={impact?.completedPickups ?? 0} caption="Thanks for closing the loop" icon={Check} tone="yellow" /></div>
    <section className="ngo-search-section" id="nearby"><div className="dashboard-section-heading"><div><span className="eyebrow">GOOD FOOD, CLOSE TO HOME</span><h2>Find nearby food</h2><p>Filter by location, type and time. Pickup locations are listed—no map key required.</p></div><span className="nearby-pill"><span className="nearby-live-dot" /> Location list view</span></div>
      <form className="search-filter-panel" onSubmit={(e) => { e.preventDefault(); setSubmitted({ ...filters }); }}>
        <label className="filter-search"><Search size={17} /><input value={filters.search} onChange={(e) => setFilters((f) => ({ ...f, search: e.target.value }))} placeholder="Search food, category or description" /></label>
        <div className="filter-row"><label className="filter-field"><span>City / address</span><div><MapPin size={15} /><input value={filters.city} onChange={(e) => setFilters((f) => ({ ...f, city: e.target.value }))} placeholder="Any location" /></div></label><label className="filter-field"><span>Category</span><select value={filters.category} onChange={(e) => setFilters((f) => ({ ...f, category: e.target.value }))}><option value="">All categories</option>{categories.map((category) => <option value={category.name} key={category.id}>{category.name}</option>)}</select></label><label className="filter-field"><span>Food type</span><select value={filters.foodType} onChange={(e) => setFilters((f) => ({ ...f, foodType: e.target.value }))}><option value="">All types</option><option>Vegetarian</option><option>Non-vegetarian</option></select></label><label className="filter-field"><span>At least</span><select value={filters.minQuantity} onChange={(e) => setFilters((f) => ({ ...f, minQuantity: e.target.value }))}><option value="">Any quantity</option><option value="5">5 portions</option><option value="10">10 portions</option><option value="25">25 portions</option><option value="50">50 portions</option></select></label><label className="filter-field"><span>Expiry window</span><select value={filters.expiryWithinHours} onChange={(e) => setFilters((f) => ({ ...f, expiryWithinHours: e.target.value }))}><option value="">Any time</option><option value="6">Within 6 hours</option><option value="12">Within 12 hours</option><option value="24">Within 24 hours</option><option value="48">Within 48 hours</option></select></label><label className="filter-field"><span>Sort by</span><select value={filters.sort} onChange={(e) => setFilters((f) => ({ ...f, sort: e.target.value }))}><option value="expiry">Expiring soon</option><option value="newest">Recently added</option><option value="quantity">Most portions</option></select></label></div>
        <div className="filter-actions"><button className="button button-primary button-small" type="submit"><Filter size={15} /> Apply filters</button><button className="text-button" type="button" onClick={resetFilters}><X size={14} /> Clear all</button><span>{donations.length} listing{donations.length === 1 ? '' : 's'} found</span></div>
      </form>
      {donations.length ? <div className="food-grid ngo-food-grid">{donations.map((donation) => <div className="ngo-food-wrap" key={donation.id}><FoodCard donation={donation} /><div className="ngo-food-action"><Link to={`/donations/${donation.id}`} className="button button-primary button-small">View details & request <ArrowRight size={14} /></Link></div></div>)}</div> : <EmptyState icon={Leaf} title="No food found with those filters" >Try a nearby city, widen the expiry window, or clear a filter to see more listings.<button className="text-link" onClick={resetFilters}>Clear filters <ArrowRight size={14} /></button></EmptyState>}
    </section>
    <section className="dashboard-section" id="requests"><div className="dashboard-section-heading"><div><span className="eyebrow">YOUR PICKUP HANDOFFS</span><h2>My requests</h2><p>Track each pickup from request to completion.</p></div><Link to="/notifications" className="text-link">Check notifications <ArrowRight size={14} /></Link></div>
      {requests.length ? <div className="ngo-request-list">{requests.map((request) => <PickupHistoryRow key={request.id} request={request} onAction={action} busy={actionId === request.id} />)}</div> : <EmptyState icon={Clock3} title="No pickup requests yet">When you request a listing, it will appear here with its latest status.</EmptyState>}
    </section>
    <section className="ngo-bottom-callout"><div><span className="safety-mini-icon"><ShieldCheck size={19} /></span><div><strong>Safe food for the people you serve.</strong><p>Check expiry, handling details and allergens before each pickup.</p></div></div><Link to="/guidelines" className="button button-secondary button-small">Read safety guidelines <ArrowRight size={14} /></Link></section>
  </div></DashNav>;
}
