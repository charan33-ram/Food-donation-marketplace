import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { AlertTriangle, ArrowLeft, ArrowRight, CalendarClock, CheckCircle2, Clock3, MapPin, MessageSquareWarning, ShieldCheck, Utensils } from 'lucide-react';
import { api, fmtDate, messageOf, timeLeft } from '../api';
import { useAuth } from '../auth';
import { Avatar, Loading, StatusBadge, useToast } from '../components';

function toLocalDatetime(value) {
  const date = new Date(value);
  const local = new Date(date.getTime() - date.getTimezoneOffset() * 60000);
  return local.toISOString().slice(0, 16);
}
function defaultPickupTime(expiryAt) {
  const twoHours = Date.now() + 2 * 60 * 60 * 1000;
  const latest = new Date(expiryAt).getTime() - 30 * 60 * 1000;
  const chosen = new Date(Math.min(twoHours, latest));
  const local = new Date(chosen.getTime() - chosen.getTimezoneOffset() * 60000);
  return local.toISOString().slice(0, 16);
}

export default function DonationDetails() {
  const { id } = useParams();
  const { user } = useAuth();
  const toast = useToast();
  const [donation, setDonation] = useState(null);
  const [existingRequest, setExistingRequest] = useState(null);
  const [quantity, setQuantity] = useState(1);
  const [pickupAt, setPickupAt] = useState('');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  async function load() {
    setLoading(true); setError(''); setDonation(null); setExistingRequest(null);
    try {
      const [foodResult, requestResult] = await Promise.all([
        api.get(`/donations/${id}`),
        user?.role === 'NGO' ? api.get('/pickup-requests') : Promise.resolve({ data: { items: [] } })
      ]);
      setDonation(foodResult.data.donation);
      setExistingRequest((requestResult.data.items || []).find((request) => request.donationId === id && ['Requested', 'Approved', 'Picked Up'].includes(request.status)) || null);
      setQuantity(1); setPickupAt(defaultPickupTime(foodResult.data.donation.expiryAt));
    }
    catch (e) { setError(messageOf(e)); }
    finally { setLoading(false); }
  }
  useEffect(() => { load(); }, [id, user?.id, user?.role]);
  async function requestPickup(event) {
    event.preventDefault(); setError(''); setBusy(true);
    try {
      const { data } = await api.post(`/donations/${id}/requests`, { quantity: Number(quantity), pickupAt: new Date(pickupAt).toISOString(), message });
      toast(data.message);
      setExistingRequest(data.request);
      setDonation((old) => old ? { ...old, status: 'Requested' } : old);
      setMessage('');
    } catch (e) { setError(messageOf(e)); } finally { setBusy(false); }
  }
  if (loading) return <div className="page-container detail-loading"><Loading label="Loading food listing…" /></div>;
  if (error && !donation) return <section className="page-container detail-not-found"><div className="empty-icon"><AlertTriangle size={22} /></div><h1>We couldn't find that food listing.</h1><p>{error}</p><Link className="button button-primary" to="/donations">Browse available food <ArrowRight size={15} /></Link></section>;
  if (!donation) return null;
  const available = donation.availableQuantity ?? donation.quantity - (donation.reservedQuantity || 0) - (donation.collectedQuantity || 0);
  const own = user?.id === donation.donorId;
  const active = available > 0 && new Date(donation.expiryAt).getTime() > Date.now() && !['Completed', 'Expired'].includes(donation.status);
  const canRequest = user?.role === 'NGO' && active && !existingRequest;
  return <div className="page-container detail-page">
    <div className="detail-breadcrumb"><Link to="/donations"><ArrowLeft size={15} /> Back to available food</Link><span> / </span><span>{donation.category}</span></div>
    <div className="detail-grid">
      <div className="detail-main">
        <div className="detail-image-wrap">{donation.image ? <img src={donation.image} alt={donation.name} /> : <div className="detail-image-placeholder"><span>{donation.category === 'Bakery' ? '🥐' : donation.category === 'Produce' ? '🥬' : donation.category === 'Dairy' ? '🥛' : '🍲'}</span><small>Shared with care</small></div>}<span className={`detail-expiry-chip ${new Date(donation.expiryAt).getTime() - Date.now() < 8 * 3600000 ? 'expiry-soon' : ''}`}><Clock3 size={14} /> {timeLeft(donation.expiryAt)}</span></div>
        <div className="detail-title-block"><div className="detail-kickers"><span className="category-pill">{donation.category}</span><span className={`food-type-pill ${donation.foodType === 'Non-vegetarian' ? 'nonveg-pill' : ''}`}>{donation.foodType}</span><StatusBadge status={donation.status} /></div><h1>{donation.name}</h1><p>{donation.description}</p></div>
        <div className="detail-facts-grid"><div className="detail-fact"><span><Utensils size={17} /></span><div><small>Available now</small><strong>{available} of {donation.quantity} portions</strong></div></div><div className="detail-fact"><span><CheckCircle2 size={17} /></span><div><small>Estimated servings</small><strong>About {donation.servings} meals total</strong></div></div><div className="detail-fact"><span><CalendarClock size={17} /></span><div><small>Prepared</small><strong>{fmtDate(donation.preparedAt)}</strong></div></div><div className="detail-fact"><span className="fact-warning"><Clock3 size={17} /></span><div><small>Use by</small><strong>{fmtDate(donation.expiryAt)}</strong></div></div></div>
        <div className="detail-section"><h2><MapPin size={18} /> Pickup details</h2><div className="pickup-address-card"><strong>{donation.pickupAddress}</strong><span>{donation.city}</span><div className="pickup-time-line"><CalendarClock size={15} /><span>{donation.availablePickupTime}</span></div></div><p className="location-fallback-note"><MapPin size={14} /> Location-based list view · confirm exact directions with the donor before travelling.</p></div>
        <div className="detail-section allergens-section"><h2>Allergens & dietary notes</h2>{donation.allergens?.length ? <div className="allergen-pills">{donation.allergens.map((allergen) => <span key={allergen}>{allergen}</span>)}</div> : <p className="muted-copy">No allergens listed. Please confirm any dietary requirements with the donor.</p>}</div>
        <div className="detail-safety-note"><ShieldCheck size={18} /><p><strong>Care before collection.</strong> Check the listed preparation and expiry information. Recipients should inspect food at pickup, and donors should share only food that has been safely stored.</p><Link to="/guidelines">Safety guide <ArrowRight size={13} /></Link></div>
      </div>
      <aside className="detail-sidebar">
        <div className="detail-donor-card"><span className="eyebrow">SHARED BY</span><div className="detail-donor-profile"><Avatar user={donation.donor} /><div><strong>{donation.donor?.organizationName || donation.donor?.name || 'Food donor'}</strong><span>{donation.donor?.name || 'Community partner'}{donation.donor?.ngoVerified && <ShieldCheck size={13} className="verified-icon" />}</span></div></div><div className="donor-city-line"><MapPin size={14} />{donation.city}</div>{donation.contactName && <div className="contact-details"><span>Pickup contact</span><strong>{donation.contactName}</strong>{donation.contactPhone && <a href={`tel:${donation.contactPhone}`}>{donation.contactPhone}</a>}</div>}{own && <Link to="/dashboard/donor#listings" className="text-link">Manage this listing <ArrowRight size={14} /></Link>}</div>
        {canRequest ? <form className="request-pickup-card" onSubmit={requestPickup}><span className="eyebrow">RESERVE A PICKUP</span><h2>Make this food matter.</h2><p>Choose the amount your team can collect and a pickup time within the donor’s window.</p><label className="field"><span className="field-label">Quantity to request</span><div className="input-suffix"><input type="number" min="1" max={available} required value={quantity} onChange={(e) => setQuantity(e.target.value)} /><span>of {available} portions</span></div></label><label className="field"><span className="field-label">Your pickup time</span><input type="datetime-local" required min={toLocalDatetime(Date.now() + 60000)} max={toLocalDatetime(donation.expiryAt)} value={pickupAt} onChange={(e) => setPickupAt(e.target.value)} /></label><label className="field"><span className="field-label">Message to the donor <small>Optional</small></span><textarea rows="3" maxLength={500} value={message} onChange={(e) => setMessage(e.target.value)} placeholder="Tell them about your pickup plan…" /></label>{error && <div className="form-alert"><AlertTriangle size={15} />{error}</div>}<button className="button button-primary button-full" disabled={busy}>{busy ? 'Sending request…' : 'Request this food'} <ArrowRight size={16} /></button><small className="request-caption"><ShieldCheck size={13} /> The donor must approve before the quantity is reserved.</small></form> : user?.role === 'NGO' && existingRequest ? <div className="request-pickup-card request-existing-card"><span className="eyebrow">PICKUP REQUEST SENT</span><h2>You're on your way.</h2><p>You already have a request for <strong>{existingRequest.quantity} portion{existingRequest.quantity === 1 ? '' : 's'}</strong> of this food.</p><StatusBadge status={existingRequest.status} /><Link to="/dashboard/ngo#requests" className="button button-primary button-full request-track-button">Track pickup request <ArrowRight size={15} /></Link><small className="request-caption">You can cancel an eligible request from your dashboard.</small></div> : user?.role === 'NGO' ? <div className="closed-listing-card"><span><AlertTriangle size={18} /></span><strong>This listing is no longer available</strong><p>The available quantity may be reserved, collected, or expired.</p></div> : !user ? <div className="request-pickup-card"><span className="eyebrow">COMMUNITY PICKUP</span><h2>Want to collect this food?</h2><p>Sign in as an NGO to request a pickup and coordinate the handoff.</p><Link to="/login" state={{ from: { pathname: `/donations/${id}` } }} className="button button-primary button-full">Sign in to request <ArrowRight size={16} /></Link><small className="request-caption">Not an NGO? <Link to="/register?role=NGO">Create a community account</Link>.</small></div> : <div className="closed-listing-card"><span><ShieldCheck size={18} /></span><strong>Food pickup is for community partners</strong><p>Donors can manage this listing from their dashboard.</p></div>}
        <Link className="report-listing-link" to={`/reports/new?donationId=${id}`}><MessageSquareWarning size={16} /> Report incorrect or unsafe food details</Link>
      </aside>
    </div>
  </div>;
}
