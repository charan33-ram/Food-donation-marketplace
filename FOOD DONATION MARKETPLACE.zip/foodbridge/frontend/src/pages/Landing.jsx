import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowDown, ArrowRight, Check, ChevronDown, Heart, Leaf, MapPin, ShieldCheck, Sprout, Utensils, Users, Wheat } from 'lucide-react';
import { api, messageOf } from '../api';
import { FoodCard, Loading } from '../components';
import { useAuth } from '../auth';

const faqs = [
  ['Who can donate food?', 'Restaurants, hotels, supermarkets, event organizers and individuals can share suitable surplus food. Donors add a clear preparation time, expiry time, allergens and a safe pickup window.'],
  ['Who can request a pickup?', 'Registered NGOs, shelters, community kitchens and other verified community organizations can browse local listings and request the quantity they can collect.'],
  ['Does it cost anything to use FoodBridge?', 'No. FoodBridge is a community marketplace built to make safe surplus-food sharing easier. Donations are shared without a platform fee.'],
  ['How do you keep food handoffs safe?', 'Donors provide accurate preparation and expiry details. Pickup organizations review the listing before requesting, and both sides can report concerns. Please follow our food safety guide and local regulations.'],
  ['Can I find donations near me?', 'Use the city and address filters on Find food. FoodBridge works as a location-based list without a paid map key, so it is ready to use in any city.']
];

export default function Landing() {
  const { user } = useAuth();
  const [impact, setImpact] = useState(null);
  const [donations, setDonations] = useState([]);
  const [faq, setFaq] = useState(0);
  const [error, setError] = useState('');
  useEffect(() => {
    let active = true;
    Promise.all([api.get('/stats/impact'), api.get('/donations?limit=3&sort=expiry')])
      .then(([stats, food]) => { if (active) { setImpact(stats.data); setDonations(food.data.items || []); } })
      .catch((e) => { if (active) setError(messageOf(e)); });
    return () => { active = false; };
  }, []);
  const dashboard = user?.role === 'Admin' ? '/dashboard/admin' : user?.role === 'NGO' ? '/dashboard/ngo' : '/dashboard/donor';
  return <>
    <section className="hero-section">
      <div className="hero-orbit hero-orbit-one" /><div className="hero-orbit hero-orbit-two" />
      <div className="hero-inner page-container">
        <div className="hero-copy">
          <div className="hero-kicker"><span className="hero-kicker-icon"><Sprout size={15} /></span> A little less waste. A lot more care.</div>
          <h1>Good food deserves<br /><em>a good home.</em></h1>
          <p className="hero-lede">FoodBridge brings surplus food and local communities together. Share what you have, find what you need, and make every meal matter.</p>
          <div className="hero-actions"><Link to={user ? dashboard : '/register?role=Donor'} className="button button-light button-large"><Heart size={18} /> Donate food <ArrowRight size={17} /></Link><Link to="/donations" className="button button-glass button-large"><MapPin size={17} /> Find food near you</Link></div>
          <div className="hero-trust"><div className="trust-avatars"><span>A</span><span>M</span><span>S</span><span>+</span></div><div><div className="trust-stars">★★★★★</div><span>Community-powered, city by city</span></div></div>
        </div>
        <div className="hero-art" aria-label="FoodBridge connects food donors with local community kitchens">
          <div className="hero-photo-card">
            <div className="hero-photo-top"><span className="live-pulse" /> Happening near you</div>
            <div className="hero-basket"><div className="basket-orb orb-a">🥬</div><div className="basket-orb orb-b">🍅</div><div className="basket-orb orb-c">🥕</div><div className="basket-orb orb-d">🥖</div><div className="basket-lines" /><span className="basket-leaf leaf-one">✦</span><span className="basket-leaf leaf-two">✧</span></div>
            <div className="hero-photo-footer"><div><span className="hero-mini-label">TODAY'S SHARED PLATE</span><strong>Fresh food. Fresh starts.</strong></div><span className="hero-round-check"><Check size={17} /></span></div>
          </div>
          <div className="float-note float-note-top"><span className="float-icon"><Heart size={17} fill="currentColor" /></span><span><strong>Goodness, delivered</strong><small>One pickup at a time</small></span></div>
          <div className="float-note float-note-bottom"><span className="float-number">{impact ? `${impact.mealsProvided.toLocaleString('en-IN')}+` : '...'}</span><span><strong>meals made possible</strong><small>by neighbors like you</small></span></div>
          <div className="hero-doodle">✳</div>
        </div>
      </div>
      <div className="hero-bottom page-container"><span><span className="scroll-dot" /> Scroll to discover</span><a href="#how-it-works" aria-label="Scroll to how it works"><ArrowDown size={16} /></a><span className="hero-location"><MapPin size={14} /> Starting in Hyderabad, growing everywhere</span></div>
    </section>

    <section className="impact-strip"><div className="page-container impact-strip-inner"><div className="impact-intro"><span className="eyebrow">SMALL ACTS, REAL IMPACT</span><h2>Every shared meal<br />moves us forward.</h2></div><div className="impact-metric"><span className="impact-metric-icon"><Utensils size={18} /></span><strong>{impact ? impact.mealsProvided.toLocaleString('en-IN') : '—'}</strong><small>meals provided</small></div><div className="impact-metric"><span className="impact-metric-icon"><Leaf size={18} /></span><strong>{impact ? `${impact.kilogramsSaved.toLocaleString('en-IN')} kg` : '—'}</strong><small>food saved from waste*</small></div><div className="impact-metric"><span className="impact-metric-icon"><Users size={18} /></span><strong>{impact ? impact.participatingNgos.toLocaleString('en-IN') : '—'}</strong><small>community partners</small></div></div><div className="impact-footnote page-container">*Estimated from completed pickups at 0.45 kg per meal. {error && <span className="api-note">Live impact is temporarily unavailable.</span>}</div></section>

    <section className="section section-how page-container" id="how-it-works">
      <div className="section-heading centered"><span className="eyebrow">THE FOODBRIDGE WAY</span><h2>Three steps. <em>One better world.</em></h2><p>A thoughtful bridge from a surplus plate to someone who needs it.</p></div>
      <div className="steps-grid"><article className="step-card"><span className="step-number">01</span><span className="step-icon step-green"><Utensils size={22} /></span><h3>Share what you have</h3><p>Donors list fresh surplus food with servings, allergens, an expiry time and a pickup window.</p><Link to={user ? dashboard : '/register?role=Donor'}>Become a food donor <ArrowRight size={15} /></Link></article><div className="step-connector">··············· <ArrowRight size={16} /></div><article className="step-card"><span className="step-number">02</span><span className="step-icon step-orange"><MapPin size={22} /></span><h3>Find it close by</h3><p>Local NGOs discover available food, check the details and request only what they can collect.</p><Link to="/donations">Explore nearby food <ArrowRight size={15} /></Link></article><div className="step-connector">··············· <ArrowRight size={16} /></div><article className="step-card"><span className="step-number">03</span><span className="step-icon step-yellow"><Heart size={22} /></span><h3>Make a real impact</h3><p>Donors approve the pickup. The NGO collects it. Every completed handoff grows our shared impact.</p><Link to="/guidelines">Read our safety promise <ArrowRight size={15} /></Link></article></div>
    </section>

    <section className="section featured-section"><div className="page-container"><div className="section-heading heading-row"><div><span className="eyebrow">FRESHLY SHARED</span><h2>Good food, <em>up for grabs.</em></h2><p>Browse current community listings and find a pickup near you.</p></div><Link className="text-link" to="/donations">Explore all food <ArrowRight size={16} /></Link></div>
      {donations.length ? <div className="food-grid">{donations.map((donation) => <FoodCard key={donation.id} donation={donation} />)}</div> : <div className="feature-empty"><span className="feature-empty-icon"><Wheat size={22} /></span><div><strong>{error ? 'Food listings are taking a moment' : 'A fresh start is on the way'}</strong><p>{error || 'No active listings right now. Check back soon, or be the first to share surplus food.'}</p></div><Link className="button button-secondary button-small" to="/donations">Browse listings</Link></div>}
    </div></section>

    <section className="story-section"><div className="page-container story-inner"><div className="story-art"><div className="story-plate"><span>🌱</span><i /><i /><i /></div><div className="story-stamp">GOOD<br />GROWS<br />HERE <Sprout size={17} /></div><div className="story-leaves">✿</div></div><div className="story-copy"><span className="eyebrow">WHY WE BUILT THIS</span><h2>Good food shouldn't<br />end up <em>forgotten.</em></h2><p>Every day, perfectly good food is left behind while families and community kitchens are still looking for their next meal. FoodBridge is a simple, local way to change that—one safe, thoughtful pickup at a time.</p><div className="story-quote"><span>“</span><p>When a meal finds the right home, everybody at the table wins.</p></div><Link to="/guidelines" className="text-link">Our promise to the community <ArrowRight size={15} /></Link></div></div></section>

    <section className="section testimonial-section page-container"><div className="testimonial-top"><span className="eyebrow">BETTER TOGETHER</span><h2>A bridge built on <em>kindness.</em></h2></div><div className="testimonials-grid"><article className="testimonial-card"><div className="testimonial-stars">★★★★★</div><p>“We used to have lovely food left after events. Now it reaches a community kitchen the very same evening.”</p><div className="testimonial-person"><span className="testimonial-avatar avatar-peach">SM</span><div><strong>Shreya M.</strong><small>Restaurant donor · Hyderabad</small></div><span className="testimonial-mark">“</span></div></article><article className="testimonial-card testimonial-featured"><div className="testimonial-stars">★★★★★</div><p>“The pickup details are clear and the process is humane. We can plan meals for our families with confidence.”</p><div className="testimonial-person"><span className="testimonial-avatar avatar-sage">RK</span><div><strong>Ravi K.</strong><small>Community kitchen partner</small></div><span className="testimonial-mark">“</span></div></article><article className="testimonial-card"><div className="testimonial-stars">★★★★★</div><p>“It feels good knowing yesterday’s surplus can become someone’s warm meal today. Every small contribution counts.”</p><div className="testimonial-person"><span className="testimonial-avatar avatar-sun">AP</span><div><strong>Anu P.</strong><small>FoodBridge volunteer</small></div><span className="testimonial-mark">“</span></div></article></div></section>

    <section className="faq-section"><div className="page-container faq-inner"><div className="faq-intro"><span className="eyebrow">GOOD QUESTIONS</span><h2>Here to make<br /><em>things clearer.</em></h2><p>Everything you need to get started with sharing food safely.</p><Link to="/reports/new" className="text-link">Still have a question? Talk to us <ArrowRight size={15} /></Link></div><div className="faq-list">{faqs.map(([question, answer], index) => <div className={`faq-item ${faq === index ? 'faq-open' : ''}`} key={question}><button onClick={() => setFaq(faq === index ? -1 : index)} aria-expanded={faq === index}><span>{question}</span><ChevronDown size={18} /></button>{faq === index && <p>{answer}</p>}</div>)}</div></div></section>

    <section className="closing-cta page-container"><div className="closing-cta-shape">✳</div><div><span className="eyebrow">YOUR NEXT MEAL CAN MAKE A DIFFERENCE</span><h2>Ready to pass good food forward?</h2><p>Join your neighbors in making food sharing the easy, caring choice.</p></div><div className="closing-actions"><Link className="button button-light" to={user ? dashboard : '/register'}>Join FoodBridge <ArrowRight size={16} /></Link><Link className="closing-secondary" to="/donations">Browse food first</Link></div></section>
  </>;
}
