import { useCallback, useEffect, useMemo, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { ArrowDownWideNarrow, ArrowLeft, ArrowRight, Filter, Leaf, MapPin, Search, SlidersHorizontal, X } from 'lucide-react';
import { api, messageOf } from '../api';
import { EmptyState, ErrorState, FoodCard, Loading, PageHeader } from '../components';

export default function SearchPage() {
  const [params, setParams] = useSearchParams();
  const [categories, setCategories] = useState([]);
  const [filters, setFilters] = useState({ search: params.get('search') || '', city: params.get('city') || '', category: params.get('category') || '', foodType: params.get('foodType') || '', minQuantity: params.get('minQuantity') || '', expiryWithinHours: params.get('expiryWithinHours') || '', sort: params.get('sort') || 'expiry' });
  const [items, setItems] = useState([]);
  const [pagination, setPagination] = useState({ total: 0, page: Number(params.get('page') || 1), pages: 1 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [mobileFilters, setMobileFilters] = useState(false);
  const query = useMemo(() => {
    const queryParams = new URLSearchParams();
    Object.entries(filters).forEach(([key, value]) => { if (value) queryParams.set(key, value); });
    queryParams.set('page', params.get('page') || '1'); queryParams.set('limit', '9');
    return queryParams.toString();
  }, [filters, params]);
  const load = useCallback(async () => {
    setLoading(true); setError('');
    try { const { data } = await api.get(`/donations?${query}`); setItems(data.items || []); setPagination({ total: data.total, page: data.page, pages: data.pages }); }
    catch (e) { setError(messageOf(e)); }
    finally { setLoading(false); }
  }, [query]);
  useEffect(() => { load(); }, [load]);
  useEffect(() => { api.get('/categories').then(({ data }) => setCategories(data.items || [])).catch(() => {}); }, []);
  function apply(event) { event?.preventDefault(); setParams(Object.fromEntries(Object.entries(filters).filter(([, value]) => value).concat([['page', '1']]))); }
  function clear() {
    const next = { search: '', city: '', category: '', foodType: '', minQuantity: '', expiryWithinHours: '', sort: 'expiry' };
    setFilters(next); setParams({ page: '1' });
  }
  function setPage(page) { setParams((old) => ({ ...Object.fromEntries(old.entries()), page: String(page) })); window.scrollTo({ top: 250, behavior: 'smooth' }); }
  const hasFilters = Boolean(filters.search || filters.city || filters.category || filters.foodType || filters.minQuantity || filters.expiryWithinHours);
  return <div className="search-page page-container">
    <PageHeader eyebrow="FOOD NEAR YOUR COMMUNITY" title="Find food to pass forward." description="Search local listings, check the pickup details and help good food find a good home." />
    <form className="public-search-bar" onSubmit={apply}><label><Search size={19} /><input value={filters.search} onChange={(e) => setFilters((old) => ({ ...old, search: e.target.value }))} placeholder="What food are you looking for?" aria-label="Search food" /></label><span className="search-divider" /><label><MapPin size={18} /><input value={filters.city} onChange={(e) => setFilters((old) => ({ ...old, city: e.target.value }))} placeholder="City or neighborhood" aria-label="City or address" /></label><button className="button button-primary button-large"><Search size={16} /> Search food</button></form>
    <div className="search-toolbar"><div><strong>{loading ? 'Finding listings…' : `${pagination.total} food listing${pagination.total === 1 ? '' : 's'}`}</strong><span>{filters.city ? ` near ${filters.city}` : ' shared by the community'}</span></div><div className="search-toolbar-actions"><button className={`button button-secondary button-small filter-mobile-toggle ${mobileFilters ? 'active' : ''}`} onClick={() => setMobileFilters(!mobileFilters)}><SlidersHorizontal size={15} /> Filters</button><label className="sort-select"><ArrowDownWideNarrow size={15} /><span>Sort:</span><select value={filters.sort} onChange={(e) => { const next = { ...filters, sort: e.target.value }; setFilters(next); setParams((old) => ({ ...Object.fromEntries(old.entries()), sort: e.target.value, page: '1' })); }}><option value="expiry">Expiring soon</option><option value="newest">Recently added</option><option value="quantity">Most portions</option></select></label></div></div>
    <div className="search-layout">
      <aside className={`search-filters ${mobileFilters ? 'filters-open' : ''}`}><div className="filter-sidebar-head"><div><SlidersHorizontal size={16} /><strong>Filter food</strong></div><button className="text-button" onClick={clear}>Clear all</button></div><form onSubmit={apply}>
        <label className="sidebar-filter"><span>Search</span><div className="sidebar-input"><Search size={15} /><input value={filters.search} onChange={(e) => setFilters((old) => ({ ...old, search: e.target.value }))} placeholder="Food name or details" /></div></label>
        <label className="sidebar-filter"><span>City or pickup area</span><div className="sidebar-input"><MapPin size={15} /><input value={filters.city} onChange={(e) => setFilters((old) => ({ ...old, city: e.target.value }))} placeholder="e.g. Hyderabad" /></div><small>We use city and address matching—no paid map service needed.</small></label>
        <label className="sidebar-filter"><span>Food category</span><select value={filters.category} onChange={(e) => setFilters((old) => ({ ...old, category: e.target.value }))}><option value="">All categories</option>{categories.map((c) => <option key={c.id} value={c.name}>{c.name}</option>)}</select></label>
        <div className="sidebar-filter"><span>Food type</span><div className="check-options"><label><input type="radio" name="foodType" value="" checked={!filters.foodType} onChange={() => setFilters((old) => ({ ...old, foodType: '' }))} /> All food</label><label><input type="radio" name="foodType" value="Vegetarian" checked={filters.foodType === 'Vegetarian'} onChange={(e) => setFilters((old) => ({ ...old, foodType: e.target.value }))} /> Vegetarian</label><label><input type="radio" name="foodType" value="Non-vegetarian" checked={filters.foodType === 'Non-vegetarian'} onChange={(e) => setFilters((old) => ({ ...old, foodType: e.target.value }))} /> Non-vegetarian</label></div></div>
        <label className="sidebar-filter"><span>Minimum available quantity</span><select value={filters.minQuantity} onChange={(e) => setFilters((old) => ({ ...old, minQuantity: e.target.value }))}><option value="">Any amount</option><option value="5">5 or more portions</option><option value="10">10 or more portions</option><option value="25">25 or more portions</option><option value="50">50 or more portions</option></select></label>
        <label className="sidebar-filter"><span>Expiry time</span><select value={filters.expiryWithinHours} onChange={(e) => setFilters((old) => ({ ...old, expiryWithinHours: e.target.value }))}><option value="">Any time</option><option value="6">Within 6 hours</option><option value="12">Within 12 hours</option><option value="24">Within 24 hours</option><option value="48">Within 48 hours</option></select></label>
        <button className="button button-primary button-full button-small"><Filter size={15} /> Apply filters</button>
      </form><div className="location-fallback"><MapPin size={16} /><p><strong>Nearby, without the fuss.</strong> Listings are grouped by city and pickup address. Confirm directions with the donor.</p></div></aside>
      <div className="search-results">{error ? <ErrorState message={error} onRetry={load} /> : loading ? <Loading label="Finding fresh food near you…" /> : items.length ? <><div className="food-grid search-food-grid">{items.map((item) => <FoodCard key={item.id} donation={item} />)}</div>{pagination.pages > 1 && <nav className="pagination" aria-label="Search results pages"><button disabled={pagination.page <= 1} onClick={() => setPage(pagination.page - 1)}><ArrowLeft size={15} /> Previous</button><span>Page <strong>{pagination.page}</strong> of {pagination.pages}</span><button disabled={pagination.page >= pagination.pages} onClick={() => setPage(pagination.page + 1)}>Next <ArrowRight size={15} /></button></nav>}</> : <EmptyState icon={Leaf} title={hasFilters ? 'No matching food just yet' : 'No active listings right now'}>Try clearing a filter or searching another neighborhood. New food donations appear here as soon as they are published.<button className="text-link" onClick={clear}><X size={14} /> Clear filters</button></EmptyState>}</div>
    </div>
    <div className="search-safety-banner"><span><Leaf size={18} /></span><p>Every listing is shared by a community donor. Please check preparation time, expiry and allergen information before each pickup.</p><Link to="/guidelines">Food safety guide <ArrowRight size={14} /></Link></div>
  </div>;
}
