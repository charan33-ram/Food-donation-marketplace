import { useState } from 'react';
import { Link, useLocation, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { AlertTriangle, ArrowLeft, ArrowRight, CheckCircle2, Eye, EyeOff, HeartHandshake, Leaf, Mail, ShieldCheck, Sparkles, Sprout, Utensils, Users } from 'lucide-react';
import { api, messageOf } from '../api';
import { useAuth } from '../auth';
import { useToast } from '../components';

function AuthFrame({ eyebrow, title, description, children, sideTitle = 'Good food.\nA little more good in the world.', sideText = 'Join a community that believes surplus food can become someone’s next nourishing meal.' }) {
  return <section className="auth-page page-container"><div className="auth-main"><Link to="/" className="auth-back"><ArrowLeft size={15} /> Back to FoodBridge</Link><div className="auth-form-wrap"><span className="eyebrow">{eyebrow}</span><h1>{title}</h1><p className="auth-subtitle">{description}</p>{children}</div></div><aside className="auth-aside"><div className="auth-aside-shape" /><div className="auth-aside-content"><span className="auth-aside-logo"><Leaf size={21} fill="currentColor" /></span><h2>{sideTitle.split('\n').map((part, i) => <span key={i}>{part}{i === 0 && <br />}</span>)}</h2><p>{sideText}</p><div className="auth-aside-points"><span><CheckCircle2 size={16} /> A local, community-powered network</span><span><CheckCircle2 size={16} /> Safe, thoughtful food handoffs</span><span><CheckCircle2 size={16} /> Real impact, one pickup at a time</span></div><div className="auth-aside-note"><Sparkles size={17} /><span>Small acts can make<br />a world of difference.</span></div></div></aside></section>;
}
function Field({ label, error, hint, children, className = '' }) { return <label className={`field ${className}`}><span className="field-label">{label}</span>{children}{hint && !error && <small className="field-hint">{hint}</small>}{error && <small className="field-error">{error}</small>}</label>; }
function PasswordInput({ value, onChange, placeholder = 'Enter your password', autoComplete = 'current-password' }) {
  const [show, setShow] = useState(false);
  return <div className="password-wrap"><input type={show ? 'text' : 'password'} value={value} onChange={onChange} placeholder={placeholder} autoComplete={autoComplete} /><button type="button" className="password-toggle" aria-label={show ? 'Hide password' : 'Show password'} onClick={() => setShow(!show)}>{show ? <EyeOff size={17} /> : <Eye size={17} />}</button></div>;
}

export function LoginPage() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const toast = useToast();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  async function submit(event) {
    event.preventDefault(); setError('');
    if (!email.trim() || !password) { setError('Enter your email and password to continue.'); return; }
    setBusy(true);
    try {
      const user = await login({ email: email.trim(), password });
      toast(`Welcome back, ${user.name.split(' ')[0]}!`);
      const from = location.state?.from?.pathname;
      navigate(from && from !== '/login' ? from : user.role === 'Admin' ? '/dashboard/admin' : user.role === 'NGO' ? '/dashboard/ngo' : '/dashboard/donor', { replace: true });
    } catch (e) { setError(messageOf(e)); } finally { setBusy(false); }
  }
  return <AuthFrame eyebrow="WELCOME BACK" title="Good to see you." description="Sign in to pick up where your community left off.">
    <form className="auth-form" onSubmit={submit} noValidate><Field label="Email address"><input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.org" autoComplete="email" /></Field><Field label="Password"><PasswordInput value={password} onChange={(e) => setPassword(e.target.value)} /></Field><div className="auth-inline"><label className="check-label"><input type="checkbox" defaultChecked /> <span>Keep me signed in</span></label><Link to="/forgot-password">Forgot password?</Link></div>{error && <div className="form-alert" role="alert"><AlertTriangle size={16} />{error}</div>}<button className="button button-primary button-full button-large" disabled={busy}>{busy ? 'Signing in…' : 'Sign in'} {!busy && <ArrowRight size={17} />}</button><p className="auth-switch">New to FoodBridge? <Link to="/register">Create an account</Link></p><div className="demo-login-hint"><span className="demo-dot" /><span>Hackathon demo accounts are listed in the project README.</span></div></form>
  </AuthFrame>;
}

export function RegisterPage() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const toast = useToast();
  const [role, setRole] = useState(params.get('role') === 'NGO' ? 'NGO' : 'Donor');
  const [form, setForm] = useState({ name: '', email: '', password: '', confirmPassword: '', phone: '', city: '', organizationName: '', address: '' });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const change = (key) => (event) => setForm((old) => ({ ...old, [key]: event.target.value }));
  async function submit(event) {
    event.preventDefault(); setError('');
    if (form.name.trim().length < 2) return setError('Please enter your full name.');
    if (!/^\S+@\S+\.\S+$/.test(form.email)) return setError('Please enter a valid email address.');
    if (form.password.length < 8) return setError('Your password must be at least 8 characters.');
    if (form.password !== form.confirmPassword) return setError('The passwords do not match.');
    if (role === 'NGO' && form.organizationName.trim().length < 2) return setError('Add the name of your organization.');
    setBusy(true);
    try {
      const user = await register({ ...form, role, name: form.name.trim(), email: form.email.trim().toLowerCase() });
      toast('Welcome to FoodBridge. Your account is ready.');
      navigate(user.role === 'NGO' ? '/dashboard/ngo' : '/dashboard/donor', { replace: true });
    } catch (e) { setError(messageOf(e)); } finally { setBusy(false); }
  }
  return <AuthFrame eyebrow="LET GOOD FOOD GO FURTHER" title="Join the bridge." description="Create an account and bring more good to your neighborhood." sideTitle="A better meal\nstarts with a bridge." sideText="FoodBridge makes it simple for people with surplus food to connect with community organizations nearby.">
    <form className="auth-form register-form" onSubmit={submit} noValidate>
      <div className="role-choice-label">I’m joining FoodBridge as a…</div><div className="role-choice-grid"><button type="button" className={`role-choice ${role === 'Donor' ? 'role-choice-active' : ''}`} onClick={() => setRole('Donor')}><span className="role-choice-icon"><Utensils size={18} /></span><strong>Food donor</strong><small>Share surplus food</small></button><button type="button" className={`role-choice ${role === 'NGO' ? 'role-choice-active' : ''}`} onClick={() => setRole('NGO')}><span className="role-choice-icon"><Users size={18} /></span><strong>Community NGO</strong><small>Request local food</small></button></div>
      <div className="form-two-col"><Field label="Your name"><input value={form.name} onChange={change('name')} placeholder="Full name" autoComplete="name" /></Field><Field label="Email address"><input type="email" value={form.email} onChange={change('email')} placeholder="you@example.org" autoComplete="email" /></Field></div>
      {role === 'NGO' && <Field label="Organization name"><input value={form.organizationName} onChange={change('organizationName')} placeholder="Community kitchen or NGO" autoComplete="organization" /></Field>}
      <div className="form-two-col"><Field label="Phone number"><input type="tel" value={form.phone} onChange={change('phone')} placeholder="+91 98765 43210" autoComplete="tel" /></Field><Field label="City"><input value={form.city} onChange={change('city')} placeholder="Hyderabad" autoComplete="address-level2" /></Field></div>
      <Field label="Address (optional)"><input value={form.address} onChange={change('address')} placeholder="Street, neighborhood" autoComplete="street-address" /></Field>
      <div className="form-two-col"><Field label="Password"><PasswordInput value={form.password} onChange={change('password')} placeholder="At least 8 characters" autoComplete="new-password" /></Field><Field label="Confirm password"><PasswordInput value={form.confirmPassword} onChange={change('confirmPassword')} placeholder="Repeat password" autoComplete="new-password" /></Field></div>
      {role === 'NGO' && <div className="form-note"><ShieldCheck size={15} /> New NGO accounts can be verified by the FoodBridge administrator.</div>}
      {error && <div className="form-alert" role="alert"><AlertTriangle size={16} />{error}</div>}<button className="button button-primary button-full button-large" disabled={busy}>{busy ? 'Creating account…' : 'Create my account'} {!busy && <ArrowRight size={17} />}</button><p className="auth-switch">Already part of the bridge? <Link to="/login">Sign in</Link></p>
    </form>
  </AuthFrame>;
}

export function ForgotPasswordPage() {
  const [email, setEmail] = useState('');
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  const [resetToken, setResetToken] = useState('');
  const [error, setError] = useState('');
  async function submit(event) {
    event.preventDefault(); setError(''); setBusy(true);
    try { const { data } = await api.post('/auth/forgot-password', { email }); setMessage(data.message); setResetToken(data.resetToken || ''); }
    catch (e) { setError(messageOf(e)); } finally { setBusy(false); }
  }
  return <AuthFrame eyebrow="ACCOUNT HELP" title="Let’s get you back." description="Enter the email address on your account and we’ll help you reset your password." sideTitle="A little reset.\nA fresh start." sideText="Your account stays protected. Reset links are time-limited and only work once.">
    {message ? <div className="reset-success"><span className="reset-success-icon"><Mail size={22} /></span><h2>Check your next step</h2><p>{message}</p>{resetToken && <div className="dev-reset-link"><strong>Demo reset link</strong><span>For local development, open the one-time reset page below. In production, an email provider should deliver this link.</span><Link className="button button-primary" to={`/reset-password/${resetToken}`}>Continue to reset password <ArrowRight size={15} /></Link></div>}<Link className="text-link" to="/login"><ArrowLeft size={15} /> Back to sign in</Link></div> : <form className="auth-form" onSubmit={submit}><Field label="Email address"><input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.org" autoComplete="email" /></Field>{error && <div className="form-alert"><AlertTriangle size={16} />{error}</div>}<button className="button button-primary button-full button-large" disabled={busy}>{busy ? 'Preparing reset…' : 'Send reset instructions'} {!busy && <ArrowRight size={17} />}</button><p className="auth-switch"><Link to="/login">Back to sign in</Link></p></form>}
  </AuthFrame>;
}

export function ResetPasswordPage() {
  const { token: pathToken } = useParams();
  const [params] = useSearchParams();
  const token = pathToken || params.get('token') || '';
  const navigate = useNavigate();
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [complete, setComplete] = useState(false);
  async function submit(event) {
    event.preventDefault(); setError('');
    if (password.length < 8) return setError('Your new password must be at least 8 characters.');
    if (password !== confirm) return setError('The passwords do not match.');
    setBusy(true);
    try { await api.post('/auth/reset-password', { token, password }); setComplete(true); }
    catch (e) { setError(messageOf(e)); } finally { setBusy(false); }
  }
  return <AuthFrame eyebrow="SECURE YOUR ACCOUNT" title={complete ? 'All set.' : 'Choose a new password.'} description={complete ? 'Your password is updated. Sign in to continue sharing good.' : 'Make it something strong and memorable. At least 8 characters.'} sideTitle="Your good work\nis safe here." sideText="FoodBridge uses secure password hashing and expiring reset links to protect your account.">
    {complete ? <div className="reset-success"><span className="reset-success-icon"><CheckCircle2 size={24} /></span><h2>Password updated</h2><p>You can sign in with your new password.</p><button className="button button-primary" onClick={() => navigate('/login')}>Go to sign in <ArrowRight size={16} /></button></div> : <form className="auth-form" onSubmit={submit}><Field label="New password"><PasswordInput value={password} onChange={(e) => setPassword(e.target.value)} placeholder="At least 8 characters" autoComplete="new-password" /></Field><Field label="Confirm new password"><PasswordInput value={confirm} onChange={(e) => setConfirm(e.target.value)} placeholder="Repeat your password" autoComplete="new-password" /></Field>{error && <div className="form-alert"><AlertTriangle size={16} />{error}</div>}<button className="button button-primary button-full button-large" disabled={busy || !token}>{busy ? 'Saving password…' : 'Save new password'} {!busy && <ArrowRight size={17} />}</button>{!token && <p className="field-error">The reset link is missing. <Link to="/forgot-password">Request a new one</Link>.</p>}</form>}
  </AuthFrame>;
}

export function GuidelinesPage() {
  const practices = [
    ['Share food that is safe to eat', 'Only list food that has been handled, stored and packed safely. Never donate food that has spoiled, been left in unsafe conditions, or is past its safe consumption time.'],
    ['Be precise about preparation and expiry', 'Add the actual preparation time and a conservative expiry time. If storage temperature matters, include clear instructions in the description.'],
    ['Tell the whole allergen story', 'List known allergens and cross-contamination risks. If something is uncertain, say so rather than guessing.'],
    ['Make collection practical', 'Choose a pickup window with enough time before expiry. Keep the food packed, labeled and ready for the agreed handoff.'],
    ['Speak up when something feels wrong', 'Use the report form for unsafe food, suspicious activity or inaccurate listing details. Contact local emergency services if there is an immediate risk.']
  ];
  return <div className="page-container content-page safety-page"><div className="safety-hero"><span className="safety-hero-icon"><ShieldCheck size={25} /></span><span className="eyebrow">A SHARED RESPONSIBILITY</span><h1>Food safety comes<br /><em>before food sharing.</em></h1><p>FoodBridge helps communities connect. Safe handling, honest information and local food regulations always come first.</p><Link className="button button-primary" to="/reports/new">Report a concern <ArrowRight size={16} /></Link></div><div className="safety-content"><div className="safety-warning"><AlertTriangle size={19} /><div><strong>When in doubt, don't donate it.</strong><p>FoodBridge is a connection platform, not a food inspector. Donors remain responsible for the safety and accuracy of their listings. Recipients should check food before serving.</p></div></div><div className="safety-list">{practices.map(([title, body], i) => <article className="safety-item" key={title}><span className="safety-number">0{i + 1}</span><div><h3>{title}</h3><p>{body}</p></div></article>)}</div><div className="safety-bottom"><Leaf size={20} /><p>Thank you for treating every meal, every person and every handoff with care.</p></div></div></div>;
}

export function NotFoundPage() { return <section className="not-found page-container"><div className="not-found-number">404</div><span className="eyebrow">THIS PAGE TOOK A WRONG TURN</span><h1>Let's find a better<br /><em>way forward.</em></h1><p>The page you’re looking for may have moved. The good things are still right here.</p><div className="not-found-actions"><Link to="/" className="button button-primary"><Leaf size={16} /> Go home</Link><Link to="/donations" className="button button-secondary">Explore food <ArrowRight size={15} /></Link></div><div className="not-found-doodle">✳</div></section>; }
