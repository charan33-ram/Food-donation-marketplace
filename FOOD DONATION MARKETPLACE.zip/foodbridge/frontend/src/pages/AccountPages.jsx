import { useEffect, useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { AlertTriangle, ArrowDownToLine, ArrowRight, Bell, CalendarClock, Check, CheckCheck, ChevronRight, Clock3, FileText, ImagePlus, Leaf, MapPin, MessageSquareWarning, PackageCheck, ShieldCheck, UserRound } from 'lucide-react';
import { api, fileToDataUrl, fmtDate, messageOf } from '../api';
import { useAuth } from '../auth';
import { Avatar, EmptyState, Loading, PageHeader, StatusBadge, useToast } from '../components';

export function ProfilePage() {
  const { user, setUser } = useAuth();
  const toast = useToast();
  const [form, setForm] = useState(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [passwordForm, setPasswordForm] = useState({ currentPassword: '', newPassword: '', confirmPassword: '' });
  const [passwordBusy, setPasswordBusy] = useState(false);
  const [passwordError, setPasswordError] = useState('');
  useEffect(() => {
    let alive = true;
    api.get('/users/me').then(({ data }) => { if (alive) setForm({ ...data.user }); }).catch((e) => alive && setError(messageOf(e))).finally(() => alive && setLoading(false));
    return () => { alive = false; };
  }, []);
  const set = (key) => (event) => setForm((old) => ({ ...old, [key]: event.target.value }));
  async function photo(event) {
    const file = event.target.files?.[0]; if (!file) return;
    try { const profilePhoto = await fileToDataUrl(file); setForm((old) => ({ ...old, profilePhoto })); }
    catch (e) { setError(e.message); }
    finally { event.target.value = ''; }
  }
  async function saveProfile(event) {
    event.preventDefault(); setError(''); setBusy(true);
    try { const { data } = await api.put('/users/me', form); setForm(data.user); setUser(data.user); toast(data.message); }
    catch (e) { setError(messageOf(e)); }
    finally { setBusy(false); }
  }
  async function changePassword(event) {
    event.preventDefault(); setPasswordError('');
    if (passwordForm.newPassword.length < 8) return setPasswordError('New password must have at least 8 characters.');
    if (passwordForm.newPassword !== passwordForm.confirmPassword) return setPasswordError('New passwords do not match.');
    setPasswordBusy(true);
    try { const { data } = await api.patch('/auth/change-password', { currentPassword: passwordForm.currentPassword, newPassword: passwordForm.newPassword }); toast(data.message); setPasswordForm({ currentPassword: '', newPassword: '', confirmPassword: '' }); }
    catch (e) { setPasswordError(messageOf(e)); }
    finally { setPasswordBusy(false); }
  }
  if (loading) return <div className="page-container content-page"><Loading label="Loading your profile…" /></div>;
  if (!form) return <div className="page-container content-page"><div className="dashboard-error">{error || 'Profile could not be loaded.'}</div></div>;
  return <div className="page-container content-page profile-page"><PageHeader eyebrow="YOUR FOODBRIDGE ACCOUNT" title="Your profile." description="Keep your contact and pickup details up to date for the community." action={<span className="profile-role-tag"><ShieldCheck size={14} /> {user?.role}{user?.role === 'NGO' && user.ngoVerified ? ' · verified' : ''}</span>} />
    <div className="profile-layout"><div className="profile-primary"><form className="profile-card" onSubmit={saveProfile}><div className="profile-card-header"><div><span className="eyebrow">PERSONAL DETAILS</span><h2>Profile information</h2></div><span className="profile-card-icon"><UserRound size={19} /></span></div><div className="profile-photo-row"><div className="profile-photo-preview"><Avatar user={form} size="large" /></div><div><label className="upload-button"><ImagePlus size={15} /> Change photo<input type="file" accept="image/png,image/jpeg,image/webp" hidden onChange={photo} /></label><p>JPG, PNG or WebP, up to 4 MB.</p></div>{form.profilePhoto && <button type="button" className="text-button danger-text" onClick={() => setForm((old) => ({ ...old, profilePhoto: '' }))}>Remove</button>}</div><div className="profile-form-grid"><label className="field"><span className="field-label">Full name</span><input value={form.name || ''} onChange={set('name')} required minLength={2} maxLength={80} /></label><label className="field"><span className="field-label">Email address</span><input value={form.email || ''} disabled /><small className="field-hint">Email is used for sign-in and cannot be changed here.</small></label>{form.role === 'NGO' && <label className="field field-span-2"><span className="field-label">Organization name</span><input value={form.organizationName || ''} onChange={set('organizationName')} placeholder="Community kitchen or NGO" /></label>}<label className="field"><span className="field-label">Phone number</span><input type="tel" value={form.phone || ''} onChange={set('phone')} placeholder="+91 98765 43210" /></label><label className="field"><span className="field-label">City</span><input value={form.city || ''} onChange={set('city')} placeholder="Hyderabad" /></label><label className="field field-span-2"><span className="field-label">Address</span><input value={form.address || ''} onChange={set('address')} placeholder="Street, neighborhood, landmark" /></label></div>{error && <div className="form-alert"><AlertTriangle size={15} />{error}</div>}<div className="form-actions"><button className="button button-primary" disabled={busy}>{busy ? 'Saving…' : 'Save profile'} <Check size={15} /></button></div></form>
      <form className="profile-card password-card" onSubmit={changePassword}><div className="profile-card-header"><div><span className="eyebrow">ACCOUNT SECURITY</span><h2>Change password</h2></div><span className="profile-card-icon"><ShieldCheck size={19} /></span></div><p className="profile-card-intro">Choose a strong password. Passwords are securely hashed and never shown in your profile.</p><div className="profile-form-grid"><label className="field field-span-2"><span className="field-label">Current password</span><input type="password" autoComplete="current-password" value={passwordForm.currentPassword} onChange={(e) => setPasswordForm((f) => ({ ...f, currentPassword: e.target.value }))} required /></label><label className="field"><span className="field-label">New password</span><input type="password" autoComplete="new-password" value={passwordForm.newPassword} onChange={(e) => setPasswordForm((f) => ({ ...f, newPassword: e.target.value }))} minLength={8} required /></label><label className="field"><span className="field-label">Confirm new password</span><input type="password" autoComplete="new-password" value={passwordForm.confirmPassword} onChange={(e) => setPasswordForm((f) => ({ ...f, confirmPassword: e.target.value }))} minLength={8} required /></label></div>{passwordError && <div className="form-alert"><AlertTriangle size={15} />{passwordError}</div>}<div className="form-actions"><button className="button button-secondary" disabled={passwordBusy}>{passwordBusy ? 'Updating…' : 'Update password'}</button></div></form></div>
      <aside className="profile-aside"><div className="account-summary-card"><span className="eyebrow">ACCOUNT AT A GLANCE</span><div className="summary-avatar"><Avatar user={form} size="large" /></div><h3>{form.organizationName || form.name}</h3><p>{form.email}</p><span className={`role-tag role-tag-${form.role.toLowerCase()}`}>{form.role}</span>{form.role === 'NGO' && <div className={`verification-status ${form.ngoVerified ? 'is-verified' : ''}`}><ShieldCheck size={16} /><span>{form.ngoVerified ? 'Verified community partner' : 'Verification pending'}</span></div>}<div className="account-summary-links"><Link to={form.role === 'Admin' ? '/dashboard/admin' : form.role === 'NGO' ? '/dashboard/ngo' : '/dashboard/donor'}>Go to your dashboard <ArrowRight size={14} /></Link><Link to="/notifications">Notification center <ArrowRight size={14} /></Link><Link to="/reports/new">Report a problem <ArrowRight size={14} /></Link></div></div><div className="settings-note"><ShieldCheck size={17} /><p>Your personal details are only used to support safe account access and food handoffs.</p></div></aside></div>
  </div>;
}

function HistoryRow({ request, isDonor }) {
  const other = isDonor ? request.ngo : request.donor;
  return <tr><td><Link className="history-food-link" to={`/donations/${request.donationId}`}><strong>{request.foodName}</strong><small>{request.city || request.donation?.city || '—'}</small></Link></td><td>{other?.organizationName || other?.name || '—'}</td><td>{request.quantity}</td><td>{fmtDate(request.pickupAt)}</td><td><StatusBadge status={request.status} /></td></tr>;
}
export function HistoryPage() {
  const { user } = useAuth();
  const toast = useToast();
  const [requests, setRequests] = useState([]);
  const [donations, setDonations] = useState([]);
  const [impact, setImpact] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [downloading, setDownloading] = useState(false);
  useEffect(() => {
    let alive = true;
    const calls = [api.get('/pickup-requests'), api.get('/stats/impact?scope=me')];
    if (user?.role === 'Donor') calls.push(api.get('/donations?mine=1&limit=100'));
    Promise.all(calls).then(([r, stats, d]) => { if (alive) { setRequests(r.data.items || []); setImpact(stats.data); setDonations(d?.data.items || []); } }).catch((e) => alive && setError(messageOf(e))).finally(() => alive && setLoading(false));
    return () => { alive = false; };
  }, [user?.id, user?.role]);
  async function exportCsv() {
    setDownloading(true);
    try { const { data } = await api.get('/history.csv', { responseType: 'blob' }); const url = URL.createObjectURL(data); const a = document.createElement('a'); a.href = url; a.download = 'foodbridge-donation-history.csv'; a.click(); URL.revokeObjectURL(url); toast('Donation history downloaded.'); }
    catch (e) { toast(messageOf(e), 'error'); }
    finally { setDownloading(false); }
  }
  if (loading) return <div className="page-container content-page"><Loading label="Loading your donation history…" /></div>;
  return <div className="page-container content-page history-page"><PageHeader eyebrow="EVERY HANDOFF COUNTS" title="Donation history." description="A record of food shared, pickups requested and meals rescued." action={<button className="button button-primary" disabled={downloading} onClick={exportCsv}><ArrowDownToLine size={16} /> {downloading ? 'Preparing…' : 'Download CSV'}</button>} />{error && <div className="dashboard-error">{error}</div>}
    <div className="history-impact-strip"><div><span className="history-impact-icon"><Leaf size={20} /></span><div><small>{user?.role === 'Donor' ? 'Food listings shared' : 'Food pickups requested'}</small><strong>{impact?.totalDonations ?? 0}</strong></div></div><div><span className="history-impact-icon history-icon-orange"><PackageCheck size={20} /></span><div><small>Completed pickups</small><strong>{impact?.completedPickups ?? 0}</strong></div></div><div><span className="history-impact-icon history-icon-blue"><Utensils size={20} /></span><div><small>Meals provided</small><strong>{(impact?.mealsProvided ?? 0).toLocaleString('en-IN')}</strong></div></div><div><span className="history-impact-icon history-icon-yellow"><Leaf size={20} /></span><div><small>Estimated food saved</small><strong>{impact?.kilogramsSaved ?? 0} kg</strong></div></div></div>
    {user?.role === 'Donor' && <section className="history-section"><div className="history-section-heading"><div><span className="eyebrow">YOUR SHARED FOOD</span><h2>Food listings</h2><p>Active and past donations from your account.</p></div><Link to="/dashboard/donor#listings" className="text-link">Manage listings <ArrowRight size={14} /></Link></div>{donations.length ? <div className="admin-table-wrap history-table-wrap"><table className="admin-table history-table"><thead><tr><th>Food listing</th><th>Available now</th><th>Expiry</th><th>Listing status</th><th>Added</th></tr></thead><tbody>{donations.map((d) => <tr key={d.id}><td><Link className="history-food-link" to={`/donations/${d.id}`}><strong>{d.name}</strong><small>{d.city} · {d.category}</small></Link></td><td>{d.availableQuantity} / {d.quantity}</td><td>{fmtDate(d.expiryAt)}</td><td><StatusBadge status={d.status} /></td><td>{fmtDate(d.createdAt)}</td></tr>)}</tbody></table></div> : <EmptyState icon={Leaf} title="No food listings yet">Your shared food will appear here after you publish a listing.</EmptyState>}</section>}
    <section className="history-section"><div className="history-section-heading"><div><span className="eyebrow">PICKUP JOURNEY</span><h2>{user?.role === 'Donor' ? 'Requests for your food' : 'Your pickup requests'}</h2><p>Follow every handoff through its latest status.</p></div><span className="history-count">{requests.length} record{requests.length === 1 ? '' : 's'}</span></div>{requests.length ? <div className="admin-table-wrap history-table-wrap"><table className="admin-table history-table"><thead><tr><th>Food</th><th>{user?.role === 'Donor' ? 'Community partner' : 'Donor'}</th><th>Quantity</th><th>Pickup time</th><th>Status</th></tr></thead><tbody>{requests.map((r) => <HistoryRow key={r.id} request={r} isDonor={user?.role === 'Donor'} />)}</tbody></table></div> : <EmptyState icon={PackageCheck} title="No pickup history yet">When a pickup request is made, its full journey will be saved here.</EmptyState>}</section>
    <div className="csv-note"><FileText size={18} /><p>Your CSV includes pickup quantity, community partner, pickup time, city and status. Exported records reflect the live FoodBridge database.</p><button className="text-link" onClick={exportCsv}>Export report <ArrowRight size={14} /></button></div>
  </div>;
}

const notificationIcon = (type) => ({ pickup_request: PackageCheck, request_approved: Check, request_rejected: AlertTriangle, expiring: Clock3, expired: AlertTriangle, pickup_completed: Leaf, new_report: MessageSquareWarning, report_update: Check, request_cancelled: Bell, picked_up: PackageCheck, listing_removed: AlertTriangle }[type] || Bell);
export function NotificationsPage() {
  const navigate = useNavigate();
  const toast = useToast();
  const [items, setItems] = useState([]);
  const [unread, setUnread] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  async function load(silent = false) {
    if (!silent) setLoading(true);
    try { const { data } = await api.get('/notifications'); setItems(data.items || []); setUnread(data.unreadCount || 0); setError(''); }
    catch (e) { setError(messageOf(e)); }
    finally { if (!silent) setLoading(false); }
  }
  useEffect(() => { load(); const timer = setInterval(() => load(true), 15000); return () => clearInterval(timer); }, []);
  async function openNotification(item) {
    if (!item.readAt) {
      try { await api.patch(`/notifications/${item.id}/read`); setItems((old) => old.map((n) => n.id === item.id ? { ...n, readAt: new Date().toISOString() } : n)); setUnread((n) => Math.max(0, n - 1)); }
      catch (e) { toast(messageOf(e), 'error'); }
    }
    if (item.link) navigate(item.link); else toast(item.message, 'success');
  }
  async function markAll() {
    setBusy(true);
    try { await api.patch('/notifications/read-all'); setItems((old) => old.map((n) => ({ ...n, readAt: n.readAt || new Date().toISOString() }))); setUnread(0); toast('All notifications marked as read.'); }
    catch (e) { toast(messageOf(e), 'error'); }
    finally { setBusy(false); }
  }
  const todayStart = new Date(); todayStart.setHours(0, 0, 0, 0);
  const today = items.filter((n) => new Date(n.createdAt) >= todayStart);
  const earlier = items.filter((n) => new Date(n.createdAt) < todayStart);
  const group = (list) => list.map((item) => { const Icon = notificationIcon(item.type); return <button key={item.id} className={`notification-item ${!item.readAt ? 'notification-unread' : ''}`} onClick={() => openNotification(item)}><span className={`notification-item-icon notification-type-${item.type}`}><Icon size={18} /></span><span className="notification-item-content"><span className="notification-item-top"><strong>{item.title}</strong><small>{fmtDate(item.createdAt)}</small></span><span>{item.message}</span>{item.link && <span className="notification-action-hint">Open details <ChevronRight size={13} /></span>}</span>{!item.readAt && <span className="unread-dot" />}</button>; });
  if (loading) return <div className="page-container content-page"><Loading label="Loading your notifications…" /></div>;
  return <div className="page-container content-page notifications-page"><PageHeader eyebrow="YOUR FOODBRIDGE INBOX" title="Notifications." description="Stay up to date on pickup requests, approvals and food expiry alerts." action={<button className="button button-secondary" onClick={markAll} disabled={!unread || busy}><CheckCheck size={16} /> Mark all read</button>} />{error && <div className="dashboard-error">{error}<button onClick={() => load()}>Retry</button></div>}<div className="notification-summary"><span><Bell size={18} /></span><div><strong>{unread} unread notification{unread === 1 ? '' : 's'}</strong><small>Updates refresh automatically every 15 seconds.</small></div><span className="polling-live"><i /> Live updates</span></div>{items.length ? <div className="notification-groups">{today.length > 0 && <section><h2>Today</h2><div className="notification-list">{group(today)}</div></section>}{earlier.length > 0 && <section><h2>Earlier</h2><div className="notification-list">{group(earlier)}</div></section>}</div> : <EmptyState icon={Bell} title="You're all caught up">Important FoodBridge updates will appear here as your community shares food.</EmptyState>}<div className="notification-safety-link"><ShieldCheck size={16} /><span>See an unsafe listing or something suspicious?</span><Link to="/reports/new">Report a concern <ArrowRight size={14} /></Link></div></div>;
}

export function ReportProblemPage() {
  const [searchParams] = useSearchParams();
  const targetId = searchParams.get('donationId') || '';
  const [form, setForm] = useState({ subject: '', category: 'Unsafe food', targetType: targetId ? 'Donation' : 'Other', targetId, details: '' });
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const toast = useToast();
  useEffect(() => { api.get('/reports').then(({ data }) => setReports(data.items || [])).catch((e) => setError(messageOf(e))).finally(() => setLoading(false)); }, []);
  const set = (key) => (e) => setForm((old) => ({ ...old, [key]: e.target.value }));
  async function submit(e) {
    e.preventDefault(); setError(''); setBusy(true);
    try { const { data } = await api.post('/reports', form); toast(data.message); setReports((old) => [data.report, ...old]); setForm({ subject: '', category: 'Unsafe food', targetType: 'Other', targetId: '', details: '' }); }
    catch (e) { setError(messageOf(e)); }
    finally { setBusy(false); }
  }
  return <div className="page-container content-page report-page"><PageHeader eyebrow="COMMUNITY CARE" title="Report a problem." description="Help us keep FoodBridge accurate, safe and welcoming for everyone." />
    <div className="report-page-grid"><form className="profile-card report-form-card" onSubmit={submit}><div className="profile-card-header"><div><span className="eyebrow">SEND A PRIVATE REPORT</span><h2>What happened?</h2></div><span className="profile-card-icon"><MessageSquareWarning size={19} /></span></div><p className="profile-card-intro">Reports are only shared with the FoodBridge safety team. If someone is in immediate danger, contact local emergency services.</p><label className="field"><span className="field-label">Report type</span><select value={form.category} onChange={set('category')}><option>Unsafe food</option><option>Incorrect listing information</option><option>Suspicious activity</option><option>Harassment or inappropriate conduct</option><option>Other safety concern</option></select></label><label className="field"><span className="field-label">Short subject</span><input required minLength={4} maxLength={120} value={form.subject} onChange={set('subject')} placeholder="A short summary of the concern" /></label><div className="form-two-col"><label className="field"><span className="field-label">Related to</span><select value={form.targetType} onChange={set('targetType')}><option>Donation</option><option>User</option><option>Other</option></select></label><label className="field"><span className="field-label">Listing or user ID <small>Optional</small></span><input value={form.targetId} onChange={set('targetId')} placeholder="Paste an ID if available" /></label></div><label className="field"><span className="field-label">Details</span><textarea required minLength={12} maxLength={1500} rows="5" value={form.details} onChange={set('details')} placeholder="Tell us what you saw, when it happened and what follow-up might help." /></label>{error && <div className="form-alert"><AlertTriangle size={15} />{error}</div>}<div className="form-actions"><button className="button button-primary" disabled={busy}>{busy ? 'Sending report…' : 'Send private report'} <ArrowRight size={15} /></button></div></form>
      <aside className="report-aside"><div className="report-aside-card"><span className="report-aside-icon"><ShieldCheck size={20} /></span><h3>Your safety report matters.</h3><p>Our admin team reviews reports and updates the status as they investigate. You’ll receive a notification when the report is reviewed.</p><div className="report-type-list"><span><Check size={14} /> Unsafe or expired food</span><span><Check size={14} /> Incorrect preparation or allergen info</span><span><Check size={14} /> Suspicious activity or behavior</span></div><Link to="/guidelines" className="text-link">Review food safety guidelines <ArrowRight size={14} /></Link></div><div className="report-disclaimer"><AlertTriangle size={16} /><p>FoodBridge is not an emergency response service. If anyone is in immediate danger, use local emergency services first.</p></div></aside></div>
    <section className="my-reports-section"><div className="history-section-heading"><div><span className="eyebrow">YOUR REPORTS</span><h2>Follow-up history</h2></div></div>{loading ? <Loading /> : reports.length ? <div className="report-history-list">{reports.map((report) => <article key={report.id}><span className="report-history-icon"><MessageSquareWarning size={16} /></span><div><strong>{report.subject}</strong><small>{report.category} · {fmtDate(report.createdAt)}</small></div><StatusBadge status={report.status} /></article>)}</div> : <p className="muted-copy">You haven’t sent a report yet.</p>}</section>
  </div>;
}
