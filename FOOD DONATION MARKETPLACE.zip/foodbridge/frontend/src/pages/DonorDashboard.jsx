import { useCallback, useEffect, useMemo, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { AlertTriangle, ArrowDownToLine, ArrowRight, CalendarClock, Camera, Check, Clock3, Leaf, PackagePlus, Pencil, Plus, ShieldCheck, Trash2, Utensils, X } from 'lucide-react';
import { api, fileToDataUrl, fmtDate, messageOf, timeLeft } from '../api';
import { useAuth } from '../auth';
import { DashNav, EmptyState, FoodCard, Loading, PageHeader, StatCard, StatusBadge, useToast } from '../components';

const localInputDate = (value) => {
  const date = value ? new Date(value) : new Date();
  if (Number.isNaN(date.getTime())) return '';
  const local = new Date(date.getTime() - date.getTimezoneOffset() * 60000);
  return local.toISOString().slice(0, 16);
};
const futureLocal = (hours) => localInputDate(Date.now() + hours * 3600000);
const initialForm = () => ({ name: '', category: 'Prepared meals', description: '', quantity: 10, servings: 20, foodType: 'Vegetarian', preparedAt: localInputDate(), expiryAt: futureLocal(24), pickupAddress: '', city: '', availablePickupTime: '', image: '', allergens: '', contactName: '', contactPhone: '' });
const payloadFromForm = (form) => ({ ...form, quantity: Number(form.quantity), servings: Number(form.servings), allergens: form.allergens.split(',').map((x) => x.trim()).filter(Boolean), preparedAt: new Date(form.preparedAt).toISOString(), expiryAt: new Date(form.expiryAt).toISOString() });

function DonationForm({ donation, categories, onCancel, onSaved }) {
  const [form, setForm] = useState(() => donation ? {
    name: donation.name, category: donation.category, description: donation.description, quantity: donation.quantity, servings: donation.servings,
    foodType: donation.foodType, preparedAt: localInputDate(donation.preparedAt), expiryAt: localInputDate(donation.expiryAt), pickupAddress: donation.pickupAddress,
    city: donation.city, availablePickupTime: donation.availablePickupTime, image: donation.image || '', allergens: (donation.allergens || []).join(', '),
    contactName: donation.contactName || '', contactPhone: donation.contactPhone || ''
  } : initialForm());
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [imageBusy, setImageBusy] = useState(false);
  const toast = useToast();
  const set = (key) => (event) => setForm((old) => ({ ...old, [key]: event.target.value }));
  async function chooseImage(event) {
    const file = event.target.files?.[0];
    if (!file) return;
    setImageBusy(true); setError('');
    try { const image = await fileToDataUrl(file); setForm((old) => ({ ...old, image })); }
    catch (e) { setError(e.message); }
    finally { setImageBusy(false); event.target.value = ''; }
  }
  async function submit(event) {
    event.preventDefault(); setError('');
    if (form.name.trim().length < 2) return setError('Add a food name.');
    if (form.description.trim().length < 10) return setError('Add a few details so the NGO can decide if it is suitable.');
    if (Number(form.quantity) < 1 || Number(form.servings) < 1) return setError('Quantity and servings must be at least 1.');
    if (!form.pickupAddress.trim() || !form.city.trim() || !form.availablePickupTime.trim()) return setError('Add the pickup address, city and pickup window.');
    if (new Date(form.expiryAt) <= new Date()) return setError('Expiry must be in the future.');
    setBusy(true);
    try {
      const payload = payloadFromForm(form);
      const { data } = donation ? await api.put(`/donations/${donation.id}`, payload) : await api.post('/donations', payload);
      toast(data.message || (donation ? 'Listing updated.' : 'Your food listing is live.'));
      onSaved();
    } catch (e) { setError(messageOf(e)); } finally { setBusy(false); }
  }
  return <form className="donation-form-card" onSubmit={submit}>
    <div className="form-panel-header"><div><span className="eyebrow">{donation ? 'UPDATE YOUR LISTING' : 'MAKE A DIFFERENCE TODAY'}</span><h2>{donation ? 'Edit food listing' : 'Share food with your community'}</h2><p>Clear details help an NGO make a safe, timely pickup.</p></div><button type="button" className="icon-button" onClick={onCancel} aria-label="Close form"><X size={18} /></button></div>
    <div className="donation-form-grid">
      <label className="field field-span-2"><span className="field-label">Food name <i>Required</i></span><input required maxLength={100} value={form.name} onChange={set('name')} placeholder="e.g. Fresh vegetable biryani packs" /></label>
      <label className="field"><span className="field-label">Category</span><select value={form.category} onChange={set('category')}>{(categories.length ? categories.map((c) => c.name) : ['Prepared meals', 'Bakery', 'Produce', 'Dairy', 'Grains & staples', 'Packaged food', 'Beverages', 'Other']).map((category) => <option key={category}>{category}</option>)}</select></label>
      <label className="field"><span className="field-label">Food type</span><select value={form.foodType} onChange={set('foodType')}><option>Vegetarian</option><option>Non-vegetarian</option></select></label>
      <label className="field"><span className="field-label">Quantity <i>Required</i></span><div className="input-suffix"><input required type="number" min="1" max="100000" value={form.quantity} onChange={set('quantity')} /><span>portions / packs</span></div></label>
      <label className="field"><span className="field-label">Number of servings <i>Required</i></span><div className="input-suffix"><input required type="number" min="1" value={form.servings} onChange={set('servings')} /><span>meals</span></div></label>
      <label className="field field-span-2"><span className="field-label">Description <i>Required</i></span><textarea required minLength={10} rows="3" maxLength={1500} value={form.description} onChange={set('description')} placeholder="Share what is included, how it is packed, and anything the recipient should know." /></label>
      <label className="field"><span className="field-label">Preparation date & time</span><input required type="datetime-local" value={form.preparedAt} onChange={set('preparedAt')} /></label>
      <label className="field"><span className="field-label">Expiry date & time <i>Required</i></span><input required type="datetime-local" value={form.expiryAt} onChange={set('expiryAt')} /></label>
      <label className="field"><span className="field-label">Pickup address <i>Required</i></span><input required value={form.pickupAddress} onChange={set('pickupAddress')} placeholder="Street, landmark, entrance" /></label>
      <label className="field"><span className="field-label">City <i>Required</i></span><input required value={form.city} onChange={set('city')} placeholder="Hyderabad" /></label>
      <label className="field field-span-2"><span className="field-label">Available pickup time <i>Required</i></span><input required value={form.availablePickupTime} onChange={set('availablePickupTime')} placeholder="Today, 5:00 PM – 8:00 PM" /></label>
      <label className="field"><span className="field-label">Allergen information</span><input value={form.allergens} onChange={set('allergens')} placeholder="e.g. Peanuts, dairy, wheat" /><small className="field-hint">Separate known allergens with commas. Write “None known” if appropriate.</small></label>
      <label className="field"><span className="field-label">Contact name</span><input value={form.contactName} onChange={set('contactName')} placeholder="Pickup point contact" /></label>
      <label className="field"><span className="field-label">Contact phone</span><input type="tel" value={form.contactPhone} onChange={set('contactPhone')} placeholder="+91 98765 43210" /></label>
      <div className="field field-span-2"><span className="field-label">Food photo <small>Optional</small></span><div className="image-upload-control"><label className="upload-button"><Camera size={16} />{imageBusy ? 'Loading image…' : form.image ? 'Change photo' : 'Add food photo'}<input type="file" accept="image/png,image/jpeg,image/webp" onChange={chooseImage} hidden /></label><span>JPG, PNG or WebP · up to 4 MB</span>{form.image && <button type="button" className="text-button danger-text" onClick={() => setForm((old) => ({ ...old, image: '' }))}>Remove photo</button>}</div>{form.image && <img src={form.image} alt="Food listing preview" className="upload-preview" />}</div>
    </div>
    <div className="food-safety-inline"><ShieldCheck size={16} /><span>Only list food that is safe to eat. Provide accurate preparation, expiry and allergen details.</span><Link to="/guidelines">Safety guide <ArrowRight size={13} /></Link></div>
    {error && <div className="form-alert"><AlertTriangle size={16} />{error}</div>}
    <div className="form-actions"><button type="button" className="button button-secondary" onClick={onCancel}>Cancel</button><button className="button button-primary" disabled={busy || imageBusy}>{busy ? 'Saving listing…' : donation ? 'Save changes' : 'Publish food listing'} {!busy && <ArrowRight size={16} />}</button></div>
  </form>;
}

function DonorRequestCard({ request, onAction, busy }) {
  return <article className="request-row"><span className="request-row-icon">{request.status === 'Requested' ? <Clock3 size={18} /> : <Check size={18} />}</span><div className="request-row-main"><div className="request-row-title"><strong>{request.ngo?.organizationName || request.ngo?.name || 'Community partner'}</strong><StatusBadge status={request.status} /></div><p><b>{request.quantity}</b> portions of <Link to={`/donations/${request.donationId}`}>{request.foodName}</Link></p><small>Pickup requested for {fmtDate(request.pickupAt)}{request.ngo?.city ? ` · ${request.ngo.city}` : ''}</small>{request.message && <div className="request-message">“{request.message}”</div>}</div><div className="request-row-actions">{request.status === 'Requested' && <><button disabled={busy} className="button button-primary button-small" onClick={() => onAction(request.id, 'approve')}>Approve</button><button disabled={busy} className="button button-quiet button-small" onClick={() => onAction(request.id, 'reject')}>Decline</button></>}{request.status === 'Picked Up' && <button disabled={busy} className="button button-secondary button-small" onClick={() => onAction(request.id, 'complete')}>Confirm completed</button>}</div></article>;
}

function DonationRow({ donation, requestCount, onEdit, onDelete }) {
  const available = donation.availableQuantity ?? donation.quantity - (donation.reservedQuantity || 0) - (donation.collectedQuantity || 0);
  const expiring = new Date(donation.expiryAt).getTime() - Date.now() < 8 * 3600000;
  return <article className="donor-listing-row">
    <div className="donor-listing-thumb">{donation.image ? <img src={donation.image} alt="" /> : <span>{donation.category === 'Bakery' ? '🥐' : donation.category === 'Produce' ? '🥬' : '🍲'}</span>}</div>
    <div className="donor-listing-main"><div className="donor-listing-heading"><Link to={`/donations/${donation.id}`}><h3>{donation.name}</h3></Link><StatusBadge status={donation.status} /></div><div className="donor-listing-meta"><span>{donation.category}</span><span>{donation.foodType}</span><span>{donation.city}</span></div><div className="donor-listing-details"><span><Utensils size={14} /> {available} available of {donation.quantity}</span><span className={expiring ? 'text-danger' : ''}><Clock3 size={14} /> {timeLeft(donation.expiryAt)}</span><span>{requestCount} pickup {requestCount === 1 ? 'request' : 'requests'}</span></div></div>
    <div className="donor-listing-actions"><button className="icon-button" aria-label={`Edit ${donation.name}`} title="Edit listing" onClick={() => onEdit(donation)}><Pencil size={16} /></button><button className="icon-button icon-danger" aria-label={`Delete ${donation.name}`} title="Delete listing" onClick={() => onDelete(donation)}><Trash2 size={16} /></button></div>
  </article>;
}

export default function DonorDashboard() {
  const { user } = useAuth();
  const location = useLocation();
  const toast = useToast();
  const [donations, setDonations] = useState([]);
  const [requests, setRequests] = useState([]);
  const [impact, setImpact] = useState(null);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const [actionId, setActionId] = useState('');
  const [filter, setFilter] = useState('All');
  const load = useCallback(async () => {
    setError('');
    try {
      const [food, pickups, stats, categoryList] = await Promise.all([api.get('/donations?mine=1&limit=100'), api.get('/pickup-requests'), api.get('/stats/impact?scope=me'), api.get('/categories')]);
      setDonations(food.data.items || []); setRequests(pickups.data.items || []); setImpact(stats.data); setCategories(categoryList.data.items || []);
    } catch (e) { setError(messageOf(e)); }
    finally { setLoading(false); }
  }, []);
  useEffect(() => { load(); }, [load]);
  useEffect(() => { if (location.hash) setTimeout(() => document.getElementById(location.hash.slice(1))?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 180); }, [location.hash, loading]);
  const visibleDonations = useMemo(() => filter === 'All' ? donations : donations.filter((d) => d.status === filter), [donations, filter]);
  const activeRequests = requests.filter((r) => r.status === 'Requested' || r.status === 'Approved' || r.status === 'Picked Up');
  async function requestAction(id, action) {
    setActionId(id);
    try { const { data } = await api.patch(`/pickup-requests/${id}/${action}`); toast(data.message); await load(); }
    catch (e) { toast(messageOf(e), 'error'); }
    finally { setActionId(''); }
  }
  async function removeDonation(donation) {
    if (!window.confirm(`Remove “${donation.name}” from FoodBridge?`)) return;
    try { const { data } = await api.delete(`/donations/${donation.id}`); toast(data.message); await load(); }
    catch (e) { toast(messageOf(e), 'error'); }
  }
  const requestCounts = requests.reduce((acc, request) => ({ ...acc, [request.donationId]: (acc[request.donationId] || 0) + 1 }), {});
  const openDonationForm = (donation = null) => {
    setEditing(donation);
    setShowForm(true);
    setTimeout(() => document.getElementById('donation-form')?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 100);
  };
  if (loading) return <DashNav role="Donor" title="Donor dashboard"><Loading label="Loading your donor dashboard…" /></DashNav>;
  return <DashNav role="Donor" title="Donor dashboard"><div className="dashboard-content">
    <PageHeader eyebrow="DONOR WORKSPACE" title={`Good morning, ${user?.name?.split(' ')[0] || 'friend'}.`} description="Your surplus can be someone's next good meal." action={<button className="button button-primary" onClick={() => openDonationForm()}><Plus size={17} /> Share food</button>} />
    {error && <div className="dashboard-error"><AlertTriangle size={16} />{error}<button onClick={load}>Retry</button></div>}
    <div className="dashboard-stats-grid"><StatCard label="My listings" value={impact?.totalDonations ?? 0} caption={`${impact?.activeListings ?? 0} currently available`} icon={Leaf} /><StatCard label="Meals provided" value={(impact?.mealsProvided ?? 0).toLocaleString('en-IN')} caption={`${impact?.kilogramsSaved ?? 0} kg estimated food saved`} icon={Utensils} tone="orange" /><StatCard label="Pickup requests" value={requests.length} caption={`${requests.filter((r) => r.status === 'Requested').length} need your review`} icon={PackagePlus} tone="blue" /><StatCard label="Completed pickups" value={impact?.completedPickups ?? 0} caption="Every handoff matters" icon={Check} tone="yellow" /></div>
    <div className="dashboard-inline-callout"><span><ShieldCheck size={18} /></span><div><strong>Safe food sharing starts with clear details.</strong><p>Keep preparation time, expiry and allergen information accurate so every pickup is safe and predictable.</p></div><Link to="/guidelines">Read guidelines <ArrowRight size={14} /></Link></div>
    {showForm && <div id="donation-form" className="form-anchor"><DonationForm donation={editing} categories={categories} onCancel={() => { setShowForm(false); setEditing(null); }} onSaved={async () => { setShowForm(false); setEditing(null); await load(); }} /></div>}
    <section className="dashboard-section" id="requests"><div className="dashboard-section-heading"><div><span className="eyebrow">PICKUP HANDOFFS</span><h2>Requests to review <span className="count-pill">{requests.filter((r) => r.status === 'Requested').length}</span></h2><p>Approve a request to reserve that portion for the NGO.</p></div><Link to="/notifications" className="text-link">Notifications <ArrowRight size={14} /></Link></div>
      {activeRequests.length ? <div className="request-list">{activeRequests.map((request) => <DonorRequestCard key={request.id} request={request} onAction={requestAction} busy={actionId === request.id} />)}</div> : <EmptyState icon={PackagePlus} title="No active pickup requests" >When an NGO requests one of your listings, it will appear here for review.</EmptyState>}
    </section>
    <section className="dashboard-section" id="listings"><div className="dashboard-section-heading"><div><span className="eyebrow">YOUR FOOD, YOUR IMPACT</span><h2>My food listings</h2><p>Update availability, review status and keep information current.</p></div><div className="listing-toolbar"><select value={filter} onChange={(e) => setFilter(e.target.value)} aria-label="Filter listings by status"><option>All</option>{['Available', 'Requested', 'Approved', 'Completed', 'Expired'].map((s) => <option key={s}>{s}</option>)}</select><button className="button button-secondary button-small" onClick={() => openDonationForm()}><Plus size={15} /> Add listing</button></div></div>
      {visibleDonations.length ? <div className="donor-listing-list">{visibleDonations.map((donation) => <DonationRow key={donation.id} donation={donation} requestCount={requestCounts[donation.id] || 0} onEdit={(item) => openDonationForm(item)} onDelete={removeDonation} />)}</div> : <EmptyState icon={Leaf} title={filter === 'All' ? 'Your first listing starts here' : `No ${filter.toLowerCase()} listings`} >Share surplus food with nearby community organizations, and keep it from going to waste.<button className="button button-primary button-small" onClick={() => openDonationForm()}><Plus size={15} /> Create a listing</button></EmptyState>}
    </section>
    <section className="dashboard-bottom-row"><div className="mini-impact-card"><div className="mini-impact-icon"><Leaf size={20} /></div><div><span className="eyebrow">YOUR FOODBRIDGE IMPACT</span><h3>{impact?.mealsProvided ?? 0} meals and counting</h3><p>Completed pickups update this number automatically.</p><Link to="/history">See your donation history <ArrowRight size={14} /></Link></div></div><Link to="/history" className="export-card"><span className="export-icon"><ArrowDownToLine size={20} /></span><strong>Take your records with you</strong><small>Download your pickup history as a CSV report.</small><span className="export-action">Open donation history <ArrowRight size={14} /></span></Link></section>
  </div></DashNav>;
}
