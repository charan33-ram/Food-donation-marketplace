import { useCallback, useEffect, useMemo, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { Activity, AlertTriangle, ArrowRight, Check, CheckCircle2, CircleSlash2, ClipboardList, Leaf, Plus, RefreshCw, ShieldCheck, Trash2, Users, Utensils, X } from 'lucide-react';
import { api, fmtDate, messageOf } from '../api';
import { DashNav, EmptyState, Loading, PageHeader, StatCard, StatusBadge, useToast } from '../components';

const adminTabs = [['overview', 'Overview'], ['users', 'People & partners'], ['listings', 'Food listings'], ['requests', 'Pickup requests'], ['reports', 'Safety reports'], ['categories', 'Categories']];

function AdminOverview({ analytics, requests, reports, donations }) {
  const impact = analytics?.impact || {};
  const categoryEntries = Object.entries(analytics?.byCategory || {}).sort((a, b) => b[1] - a[1]).slice(0, 6);
  const categoryMax = Math.max(1, ...categoryEntries.map(([, value]) => value));
  const statusEntries = Object.entries(analytics?.byRequestStatus || {}).sort((a, b) => b[1] - a[1]);
  const totalStatus = Math.max(1, statusEntries.reduce((sum, [, value]) => sum + value, 0));
  return <>
    <div className="admin-welcome-card"><div><span className="eyebrow">PLATFORM PULSE</span><h2>A little more good, every day.</h2><p>Here’s what the FoodBridge community has made possible so far.</p></div><span className="admin-welcome-mark"><Activity size={25} /></span></div>
    <div className="dashboard-stats-grid admin-stats"><StatCard label="Total donations" value={impact.totalDonations ?? 0} caption={`${impact.activeListings ?? 0} currently active`} icon={Leaf} /><StatCard label="Meals provided" value={(impact.mealsProvided ?? 0).toLocaleString('en-IN')} caption="From completed handoffs" icon={Utensils} tone="orange" /><StatCard label="Food saved" value={`${impact.kilogramsSaved ?? 0} kg`} caption="Estimated from meals served" icon={Leaf} tone="blue" /><StatCard label="Completed pickups" value={impact.completedPickups ?? 0} caption="Handoffs completed" icon={CheckCircle2} tone="yellow" /><StatCard label="Active donors" value={impact.activeDonors ?? 0} caption="With food currently listed" icon={Users} /><StatCard label="Participating NGOs" value={impact.participatingNgos ?? 0} caption={`${analytics?.userCounts?.ngos ?? 0} registered partners`} icon={Users} tone="orange" /></div>
    <div className="admin-overview-grid"><section className="admin-panel"><div className="admin-panel-heading"><div><span className="eyebrow">WHAT'S SHARED</span><h3>Listings by category</h3></div><Leaf size={17} /></div>{categoryEntries.length ? <div className="chart-bars">{categoryEntries.map(([name, value]) => <div className="chart-bar-row" key={name}><span>{name}</span><div className="chart-track"><div style={{ width: `${Math.max(5, value / categoryMax * 100)}%` }} /></div><strong>{value}</strong></div>)}</div> : <div className="chart-empty">Category totals appear when food is listed.</div>}</section><section className="admin-panel"><div className="admin-panel-heading"><div><span className="eyebrow">PICKUP WORKFLOW</span><h3>Request status</h3></div><ClipboardList size={17} /></div>{statusEntries.length ? <div className="status-breakdown">{statusEntries.map(([name, value]) => <div className="status-breakdown-row" key={name}><span className="status-breakdown-label"><i className={`status-dot status-color-${name.toLowerCase().replaceAll(' ', '-')}`} />{name}</span><div className="status-breakdown-track"><span style={{ width: `${value / totalStatus * 100}%` }} /></div><strong>{value}</strong></div>)}</div> : <div className="chart-empty">Pickup activity will appear here as partners connect.</div>}</section></div>
    <section className="admin-panel admin-recent-panel"><div className="admin-panel-heading"><div><span className="eyebrow">NEEDS A LOOK</span><h3>Recent community activity</h3></div></div><div className="admin-recent-grid"><div><strong>{requests.filter((r) => r.status === 'Requested').length}</strong><span>pickup requests waiting</span><Link to="/dashboard/admin?tab=requests">Review requests <ArrowRight size={13} /></Link></div><div><strong>{reports.filter((r) => ['Open', 'In Review'].includes(r.status)).length}</strong><span>safety reports in progress</span><Link to="/dashboard/admin?tab=reports">Review reports <ArrowRight size={13} /></Link></div><div><strong>{donations.filter((d) => d.status === 'Expired').length}</strong><span>expired food listings</span><Link to="/dashboard/admin?tab=listings">Review listings <ArrowRight size={13} /></Link></div></div></section>
  </>;
}

function UsersPanel({ users, act, busyId }) {
  const [search, setSearch] = useState('');
  const visible = users.filter((user) => `${user.name} ${user.email} ${user.organizationName} ${user.city}`.toLowerCase().includes(search.toLowerCase()));
  return <section className="admin-panel admin-table-panel"><div className="admin-panel-heading"><div><span className="eyebrow">COMMUNITY DIRECTORY</span><h3>People & partner accounts</h3><p>{users.length} accounts · verification and access controls</p></div><label className="admin-table-search"><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search people, email or city" /></label></div>{visible.length ? <div className="admin-table-wrap"><table className="admin-table"><thead><tr><th>Account</th><th>Role</th><th>Location</th><th>Joined</th><th>Account status</th><th>Actions</th></tr></thead><tbody>{visible.map((user) => <tr key={user.id}><td><div className="admin-user-cell"><span className={`admin-user-avatar role-${user.role.toLowerCase()}`}>{user.name.split(/\s+/).slice(0, 2).map((s) => s[0]).join('').toUpperCase()}</span><div><strong>{user.organizationName || user.name}</strong><small>{user.email}</small></div></div></td><td><span className={`role-tag role-tag-${user.role.toLowerCase()}`}>{user.role}</span>{user.role === 'NGO' && <small className={`verify-tag ${user.ngoVerified ? 'verified' : ''}`}>{user.ngoVerified ? 'Verified' : 'Unverified'}</small>}</td><td>{user.city || '—'}</td><td>{fmtDate(user.createdAt, { timeStyle: undefined })}</td><td>{user.suspended ? <span className="account-state state-suspended"><CircleSlash2 size={13} /> Suspended</span> : <span className="account-state state-active"><CheckCircle2 size={13} /> Active</span>}</td><td><div className="admin-action-stack">{user.role === 'NGO' && <button className="table-action" disabled={busyId === user.id} onClick={() => act(user, 'ngoVerified', !user.ngoVerified)}>{user.ngoVerified ? <><X size={13} /> Revoke verification</> : <><ShieldCheck size={13} /> Verify NGO</>}</button>}{user.role !== 'Admin' && <button className={`table-action ${user.suspended ? 'action-positive' : 'action-danger'}`} disabled={busyId === user.id} onClick={() => act(user, 'suspended', !user.suspended)}>{user.suspended ? <><Check size={13} /> Restore account</> : <><CircleSlash2 size={13} /> Suspend</>}</button>}</div></td></tr>)}</tbody></table></div> : <EmptyState icon={Users} title="No matching accounts">Try another name, email or city.</EmptyState>}</section>;
}

function ListingsPanel({ donations, remove, busyId }) {
  return <section className="admin-panel admin-table-panel"><div className="admin-panel-heading"><div><span className="eyebrow">FOOD SAFETY MONITORING</span><h3>All food listings</h3><p>Review published listings and remove inappropriate content.</p></div><span className="admin-count-badge">{donations.length} total</span></div>{donations.length ? <div className="admin-table-wrap"><table className="admin-table"><thead><tr><th>Food listing</th><th>Donor</th><th>Location</th><th>Availability</th><th>Expiry</th><th>Status</th><th>Moderation</th></tr></thead><tbody>{donations.map((d) => <tr key={d.id}><td><Link className="admin-food-link" to={`/donations/${d.id}`}><strong>{d.name}</strong><small>{d.category} · {d.foodType}</small></Link></td><td>{d.donor?.organizationName || d.donor?.name || '—'}</td><td>{d.city}</td><td>{d.availableQuantity ?? d.quantity} / {d.quantity} portions</td><td>{fmtDate(d.expiryAt)}</td><td><StatusBadge status={d.status} /></td><td><button className="table-action action-danger" disabled={busyId === d.id} onClick={() => remove(d)}><Trash2 size={13} /> Remove listing</button></td></tr>)}</tbody></table></div> : <EmptyState icon={Leaf} title="No food listings yet">When a donor shares food, it will be available here for moderation.</EmptyState>}</section>;
}

function RequestsPanel({ requests }) {
  return <section className="admin-panel admin-table-panel"><div className="admin-panel-heading"><div><span className="eyebrow">END-TO-END HANDOFFS</span><h3>Pickup requests</h3><p>Track the full request, approval and collection workflow.</p></div><span className="admin-count-badge">{requests.length} total</span></div>{requests.length ? <div className="admin-table-wrap"><table className="admin-table"><thead><tr><th>Food listing</th><th>Community organization</th><th>Donor</th><th>Quantity</th><th>Pickup time</th><th>Status</th></tr></thead><tbody>{requests.map((r) => <tr key={r.id}><td><Link className="admin-food-link" to={`/donations/${r.donationId}`}><strong>{r.foodName}</strong><small>{r.city}</small></Link></td><td>{r.ngo?.organizationName || r.ngo?.name || '—'}</td><td>{r.donor?.organizationName || r.donor?.name || '—'}</td><td>{r.quantity}</td><td>{fmtDate(r.pickupAt)}</td><td><StatusBadge status={r.status} /></td></tr>)}</tbody></table></div> : <EmptyState icon={ClipboardList} title="No pickup requests yet">Pickup activity will appear here as NGOs request a donation.</EmptyState>}</section>;
}

function ReportsPanel({ reports, act, busyId }) {
  const [search, setSearch] = useState('');
  const visible = reports.filter((r) => `${r.subject} ${r.category} ${r.details} ${r.reporter?.name}`.toLowerCase().includes(search.toLowerCase()));
  return <section className="admin-panel admin-table-panel"><div className="admin-panel-heading"><div><span className="eyebrow">COMMUNITY TRUST & SAFETY</span><h3>Safety reports</h3><p>Review reports about unsafe food, inaccurate details or suspicious activity.</p></div><label className="admin-table-search"><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search reports" /></label></div>{visible.length ? <div className="report-review-list">{visible.map((report) => <article className="report-review-card" key={report.id}><div className="report-review-icon"><AlertTriangle size={18} /></div><div className="report-review-content"><div className="report-review-top"><div><strong>{report.subject}</strong><span>{report.category} · {report.targetType}{report.targetId ? ` · ${report.targetId.slice(0, 8)}` : ''}</span></div><StatusBadge status={report.status} /></div><p>{report.details}</p><small>Reported by {report.reporter?.name || 'Community member'} · {fmtDate(report.createdAt)}</small></div><div className="report-review-action"><label><span>Update status</span><select value={report.status} disabled={busyId === report.id} onChange={(e) => act(report, e.target.value)}><option>Open</option><option>In Review</option><option>Resolved</option><option>Dismissed</option></select></label></div></article>)}</div> : <EmptyState icon={CheckCircle2} title="No reports to review">When a community member flags a concern, it will appear here.</EmptyState>}</section>;
}

function CategoriesPanel({ categories, add, remove, busy }) {
  const [name, setName] = useState('');
  const [error, setError] = useState('');
  async function submit(e) { e.preventDefault(); setError(''); try { await add(name); setName(''); } catch (err) { setError(messageOf(err)); } }
  return <section className="admin-panel categories-panel"><div className="admin-panel-heading"><div><span className="eyebrow">KEEP FOOD EASY TO FIND</span><h3>Donation categories</h3><p>Categories are used in donor forms and food discovery filters.</p></div></div><form className="category-add-form" onSubmit={submit}><label><span className="field-label">New category</span><input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Fresh fruit" maxLength={60} required /></label><button className="button button-primary button-small" disabled={busy}><Plus size={15} /> Add category</button></form>{error && <div className="form-alert"><AlertTriangle size={15} />{error}</div>}<div className="category-admin-list">{categories.map((category) => <div className="category-admin-item" key={category.id}><span className="category-admin-icon"><Leaf size={15} /></span><strong>{category.name}</strong><button className="icon-button icon-danger" disabled={busy === category.id} aria-label={`Remove ${category.name}`} onClick={() => remove(category)}><Trash2 size={15} /></button></div>)}</div>{!categories.length && <p className="muted-copy">No categories have been added yet.</p>}</section>;
}

export default function AdminDashboard() {
  const [params, setParams] = useSearchParams();
  const [analytics, setAnalytics] = useState(null);
  const [users, setUsers] = useState([]);
  const [donations, setDonations] = useState([]);
  const [requests, setRequests] = useState([]);
  const [reports, setReports] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [busyId, setBusyId] = useState('');
  const toast = useToast();
  const tab = adminTabs.some(([key]) => key === params.get('tab')) ? params.get('tab') : 'overview';
  const load = useCallback(async () => {
    setError('');
    try {
      const [a, u, d, r, rep, c] = await Promise.all([api.get('/admin/analytics'), api.get('/admin/users?limit=100'), api.get('/donations?all=1&limit=100'), api.get('/pickup-requests'), api.get('/reports'), api.get('/categories')]);
      setAnalytics(a.data); setUsers(u.data.items || []); setDonations(d.data.items || []); setRequests(r.data.items || []); setReports(rep.data.items || []); setCategories(c.data.items || []);
    } catch (e) { setError(messageOf(e)); }
    finally { setLoading(false); }
  }, []);
  useEffect(() => { load(); }, [load]);
  async function runAction(id, call, success) {
    setBusyId(id);
    try { const { data } = await call(); toast(data.message || success); await load(); }
    catch (e) { toast(messageOf(e), 'error'); }
    finally { setBusyId(''); }
  }
  const accountAction = (user, field, value) => runAction(user.id, () => api.patch(`/admin/users/${user.id}`, { [field]: value }), 'Account updated.');
  async function removeDonation(donation) {
    if (!window.confirm(`Remove “${donation.name}” from the marketplace? Any active pickup requests will be cancelled.`)) return;
    await runAction(donation.id, () => api.delete(`/donations/${donation.id}`), 'Listing removed.');
  }
  const updateReport = (report, status) => runAction(report.id, () => api.patch(`/admin/reports/${report.id}`, { status }), 'Report updated.');
  async function addCategory(name) {
    setBusyId('new-category');
    try { const { data } = await api.post('/admin/categories', { name }); toast(data.message); await load(); }
    catch (e) { toast(messageOf(e), 'error'); throw e; }
    finally { setBusyId(''); }
  }
  async function removeCategory(category) {
    if (!window.confirm(`Remove category “${category.name}”?`)) return;
    await runAction(category.id, () => api.delete(`/admin/categories/${category.id}`), 'Category removed.');
  }
  if (loading) return <DashNav role="Admin" title="Platform admin"><Loading label="Gathering platform activity…" /></DashNav>;
  const view = tab === 'overview' ? <AdminOverview analytics={analytics} requests={requests} reports={reports} donations={donations} />
    : tab === 'users' ? <UsersPanel users={users} act={accountAction} busyId={busyId} />
      : tab === 'listings' ? <ListingsPanel donations={donations} remove={removeDonation} busyId={busyId} />
        : tab === 'requests' ? <RequestsPanel requests={requests} />
          : tab === 'reports' ? <ReportsPanel reports={reports} act={updateReport} busyId={busyId} />
            : <CategoriesPanel categories={categories} add={addCategory} remove={removeCategory} busy={busyId} />;
  const title = tab === 'overview' ? 'Platform overview' : adminTabs.find(([key]) => key === tab)?.[1];
  return <DashNav role="Admin" title="Platform admin"><div className="dashboard-content admin-dashboard-content"><PageHeader eyebrow="FOODBRIDGE ADMINISTRATION" title="A healthier bridge, together." description="Manage community accounts, food listings and platform safety." action={<button className="button button-secondary" onClick={load}><RefreshCw size={15} /> Refresh data</button>} />{error && <div className="dashboard-error"><AlertTriangle size={16} />{error}<button onClick={load}>Retry</button></div>}<div className="admin-tabs" role="tablist" aria-label="Admin dashboard sections">{adminTabs.map(([key, label]) => <button role="tab" aria-selected={tab === key} className={tab === key ? 'admin-tab active' : 'admin-tab'} onClick={() => setParams(key === 'overview' ? {} : { tab: key })} key={key}>{label}{key === 'reports' && reports.filter((r) => r.status === 'Open').length > 0 && <span className="tab-count">{reports.filter((r) => r.status === 'Open').length}</span>}</button>)}</div><div className="admin-tab-content"><div className="admin-tab-title"><span className="eyebrow">WORKSPACE / {tab.toUpperCase()}</span><span className="admin-view-title">{title}</span></div>{view}</div></div></DashNav>;
}
