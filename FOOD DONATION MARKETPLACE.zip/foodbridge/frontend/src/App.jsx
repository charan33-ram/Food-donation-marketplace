import { Navigate, Route, Routes, useLocation } from 'react-router-dom';
import { useEffect } from 'react';
import { useAuth } from './auth';
import { Guard, SiteLayout, ToastProvider } from './components';
import Landing from './pages/Landing';
import { LoginPage, RegisterPage, ForgotPasswordPage, ResetPasswordPage, GuidelinesPage, NotFoundPage } from './pages/PublicPages';
import SearchPage from './pages/SearchPage';
import DonationDetails from './pages/DonationDetails';
import DonorDashboard from './pages/DonorDashboard';
import NGODashboard from './pages/NGODashboard';
import AdminDashboard from './pages/AdminDashboard';
import { ProfilePage, HistoryPage, NotificationsPage, ReportProblemPage } from './pages/AccountPages';

function DashboardRedirect() {
  const { user, loading } = useAuth();
  if (loading) return null;
  if (!user) return <Navigate to="/login" replace />;
  return <Navigate to={user.role === 'Admin' ? '/dashboard/admin' : user.role === 'NGO' ? '/dashboard/ngo' : '/dashboard/donor'} replace />;
}
function TopScroll() {
  const location = useLocation();
  useEffect(() => {
    if (location.hash) {
      const timer = setTimeout(() => document.getElementById(location.hash.slice(1))?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 120);
      return () => clearTimeout(timer);
    }
    window.scrollTo({ top: 0, behavior: 'auto' });
    return undefined;
  }, [location.pathname, location.search, location.hash]);
  return null;
}

export default function App() {
  return <ToastProvider><TopScroll /><Routes><Route element={<SiteLayout />}>
    <Route index element={<Landing />} />
    <Route path="login" element={<LoginPage />} />
    <Route path="register" element={<RegisterPage />} />
    <Route path="forgot-password" element={<ForgotPasswordPage />} />
    <Route path="reset-password" element={<ResetPasswordPage />} />
    <Route path="reset-password/:token" element={<ResetPasswordPage />} />
    <Route path="donations" element={<SearchPage />} />
    <Route path="search" element={<SearchPage />} />
    <Route path="donations/:id" element={<DonationDetails />} />
    <Route path="guidelines" element={<GuidelinesPage />} />
    <Route path="dashboard" element={<DashboardRedirect />} />
    <Route path="dashboard/donor" element={<Guard roles={['Donor']}><DonorDashboard /></Guard>} />
    <Route path="dashboard/ngo" element={<Guard roles={['NGO']}><NGODashboard /></Guard>} />
    <Route path="dashboard/admin" element={<Guard roles={['Admin']}><AdminDashboard /></Guard>} />
    <Route path="profile" element={<Guard><ProfilePage /></Guard>} />
    <Route path="notifications" element={<Guard><NotificationsPage /></Guard>} />
    <Route path="history" element={<Guard><HistoryPage /></Guard>} />
    <Route path="donation-history" element={<Navigate to="/history" replace />} />
    <Route path="reports/new" element={<Guard><ReportProblemPage /></Guard>} />
    <Route path="*" element={<NotFoundPage />} />
  </Route></Routes></ToastProvider>;
}
