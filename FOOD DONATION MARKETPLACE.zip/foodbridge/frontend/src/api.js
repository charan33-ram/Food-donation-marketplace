import axios from 'axios';

export const api = axios.create({ baseURL: '/api', headers: { 'Content-Type': 'application/json' }, timeout: 20000 });
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('foodbridge_token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});
api.interceptors.response.use((response) => response, (error) => {
  const message = error.response?.data?.message || (error.code === 'ECONNABORTED' ? 'The request timed out. Please try again.' : 'Could not reach the FoodBridge API. Make sure the backend is running.');
  error.userMessage = message;
  return Promise.reject(error);
});

export const messageOf = (error) => error?.response?.data?.message || error?.userMessage || error?.message || 'Something went wrong.';
export const fmtDate = (value, options = {}) => {
  if (!value) return '—';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '—';
  return date.toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short', ...options });
};
export const timeLeft = (value) => {
  const diff = new Date(value).getTime() - Date.now();
  if (!Number.isFinite(diff) || diff <= 0) return 'Expired';
  const hours = Math.floor(diff / 3600000);
  if (hours < 1) return `${Math.max(1, Math.floor(diff / 60000))} min left`;
  if (hours < 24) return `${hours}h ${Math.floor((diff % 3600000) / 60000)}m left`;
  return `${Math.floor(hours / 24)}d ${hours % 24}h left`;
};
export const fileToDataUrl = (file) => new Promise((resolve, reject) => {
  if (!file) return resolve('');
  if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) return reject(new Error('Choose a JPG, PNG, or WebP image.'));
  if (file.size > 4 * 1024 * 1024) return reject(new Error('Image must be smaller than 4 MB.'));
  const reader = new FileReader();
  reader.onload = () => resolve(String(reader.result || ''));
  reader.onerror = () => reject(new Error('Image could not be read.'));
  reader.readAsDataURL(file);
});
