import { createContext, useContext, useEffect, useState } from 'react';
import { Link, NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import { ArrowRight, Bell, Check, ChevronDown, CircleHelp, HeartHandshake, Leaf, LoaderCircle, LogOut, Menu, ShieldCheck, Utensils, X } from 'lucide-react';
import { api, messageOf, timeLeft } from './api';
import { useAuth } from './auth';

const ToastContext = createContext(() => {});
export function ToastProvider({ children }) {
  const [items, setItems] = useState([]);
  const push = (message, type = 'success') => {
    const id = `${Date.now()}-${Math.random()}`;
    setItems((current) => [...current, { id, message, type }]);
    setTimeout(() => setItems((current) => current.filter((item) => item.id !== id)), 4400);
  };
  return <ToastContext.Provider value={push}>{children}<div className="toast-stack" aria-live="polite">{items.map((item) => <div key={item.id} className={`toast toast-${item.type}`}><span className="toast-mark">{item.type === 'error' ? '!' : <Check size={16} />}</span><span>{item.message}</span><button aria-label="Dismiss" onClick={() => setItems((current) => current.filter((x) => x.id !== item.id))}><X size={15} /></button></div>)}</div></ToastContext.Provider>;
}
export const useToast = () => useContext(ToastContext);

export function Loading({ label = 'Loading...' }) { return <div className="loading-state"><LoaderCircle size={22} className="spin" /><span>{label}</span></div>; }
export function ErrorState({ message, onRetry }) { return <div className="error-state"><span className="error-state-icon">!</span><div><strong>We couldn’t load this yet</strong><p>{message}</p>{onRetry && <button className="button button-secondary button-small" onClick={onRetry}>Try again</button>}</div></div>; }
export function EmptyState({ icon: Icon = Leaf, title, children, action }) { return <div className="empty-state"><span className="empty-icon"><Icon size={22} /></span><h3>{title}</h3><div className="empty-copy">{children}</div>{action}</div>; }
export function PageHeader({ eyebrow, title, description, action, children }) { return <div className="page-header"><div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1>{description && <p>{description}</p>}{children}</div>{action && <div className="page-header-action">{action}</div>}</div>; }
export function StatusBadge({ status }) {
  const cls = String(status || 'available').toLowerCase().replaceAll(' ', '-');
  return <span className={`status-badge status-${cls}`}><span className="status-dot" />{status || 'Available'}</span>;
}
export function StatCard({ label, value, caption, icon: Icon = Leaf, tone = 'green' }) { return <div className={`stat-card stat-${tone}`}><span className="stat-icon"><Icon size={20} /></span><div><p>{label}</p><strong>{value ?? '—'}</strong>{caption && <small>{caption}</small>}</div></div>; }
export function Avatar({ user, size = 'normal' }) {
  const initials = (user?.name || 'F').split(/\s+/).slice(0, 2).map((part) => part[0]).join('').toUpperCase();
  return <span className={`avatar avatar-${size}`}>{user?.profilePhoto ? <img src={user.profilePhoto} alt="" /> : initials}</span>;
}
export function FoodCard({ donation }) {
  const remaining = donation.availableQuantity ?? Math.max(0, donation.quantity - (donation.reservedQuantity || 0) - (donation.collectedQuantity || 0));
  const low = new Date(donation.expiryAt).getTime() - Date.now() < 8 * 3600000;
  return <article className="food-card">
    <Link className="food-card-media" to={`/donations/${donation.id}`} aria-label={`View ${donation.name}`}>
      {donation.image ? <img src={donation.image} alt={donation.name} /> : <div className={`food-placeholder placeholder-${(donation.category || 'other').toLowerCase().replace(/[^a-z0-9]+/g, '-')}`}><span>{categoryGlyph(donation.category)}</span><small>Freshly shared</small></div>}
      <span className={`expiry-chip ${low ? 'expiry-soon' : ''}`}>{low ? '⚡ ' : ''}{timeLeft(donation.expiryAt)}</span>
    </Link>
    <div className="food-card-body">
      <div className="food-card-kicker"><span>{donation.category}</span><span className={`food-type-dot ${donation.foodType === 'Non-vegetarian' ? 'food-type-nonveg' : ''}`} />{donation.foodType}</div>
      <Link to={`/donations/${donation.id}`} className="food-card-title"><h3>{donation.name}</h3></Link>
      <p className="food-description">{donation.description}</p>
      <div className="food-card-meta"><span><Utensils size={14} /> {remaining} portions</span><span>⌖ {donation.city}</span></div>
      <div className="food-card-footer"><div className="food-donor"><Avatar user={donation.donor} size="tiny" /><span>{donation.donor?.organizationName || donation.donor?.name || 'Food donor'}{donation.donor?.ngoVerified && <ShieldCheck size={13} className="verified-icon" />}</span></div><Link to={`/donations/${donation.id}`} className="round-arrow" aria-label="View listing"><ArrowRight size={17} /></Link></div>
    </div>
  </article>;
}
function categoryGlyph(category = '') {
  const value = category.toLowerCase();
  if (value.includes('bakery')) return '🥐';
  if (value.includes('produce')) return '🥬';
  if (value.includes('dairy')) return '🥛';
  if (value.includes('beverage')) return '🥤';
  if (value.includes('grain') || value.includes('staple')) return '🌾';
  if (value.includes('meal') || value.includes('prepared')) return '🍲';
  return '🥗';
}

function NotificationNav() {
  const { user } = useAuth();
  const [count, setCount] = useState(0);
  useEffect(() => {
    if (!user) return undefined;
    let alive = true;
    const update = () => api.get('/notifications').then(({ data }) => alive && setCount(data.unreadCount || 0)).catch(() => {});
    update();
    const timer = setInterval(update, 20000);
    return () => { alive = false; clearInterval(timer); };
  }, [user?.id]);
  return <NavLink to="/notifications" className={({ isActive }) => `nav-icon-link ${isActive ? 'active' : ''}`} aria-label={`Notifications${count ? `, ${count} unread` : ''}`}><Bell size={19} />{count > 0 && <span className="notification-count">{count > 9 ? '9+' : count}</span>}</NavLink>;
}

export function SiteLayout() {
  const { user, logout } = useAuth();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  useEffect(() => { setMobileOpen(false); setProfileOpen(false); }, [location.pathname, location.search]);
  const goDashboard = () => {
    const target = user?.role === 'Admin' ? '/dashboard/admin' : user?.role === 'NGO' ? '/dashboard/ngo' : '/dashboard/donor';
    navigate(target);
  };
  const signOut = async () => { await logout(); navigate('/'); };
  return <div className="site-shell">
    <header className="site-header">
      <div className="nav-wrap">
        <Link to="/" className="brand" aria-label="FoodBridge home"><span className="brand-icon"><Leaf size={21} fill="currentColor" /></span><span>foodbridge<span className="brand-period">.</span><small>GOOD FOOD, SHARED WELL</small></span></Link>
        <button className="mobile-menu-toggle" onClick={() => setMobileOpen(!mobileOpen)} aria-label={mobileOpen ? 'Close navigation' : 'Open navigation'}>{mobileOpen ? <X /> : <Menu />}</button>
        <nav className={`nav-links ${mobileOpen ? 'nav-open' : ''}`}>
          <NavLink to="/donations" className={({ isActive }) => isActive ? 'nav-active' : ''}>Find food</NavLink>
          <a href="/#how-it-works" onClick={(event) => { if (location.pathname !== '/') { event.preventDefault(); navigate('/#how-it-works'); } }}>How it works</a>
          <NavLink to="/guidelines" className={({ isActive }) => isActive ? 'nav-active' : ''}>Food safety</NavLink>
          {user ? <>
            <button className="nav-dashboard-link" onClick={goDashboard}>Dashboard</button>
            <NotificationNav />
            <div className="profile-menu-wrap">
              <button className="profile-menu-trigger" onClick={() => setProfileOpen(!profileOpen)} aria-expanded={profileOpen}><Avatar user={user} size="tiny" /><span>{user.name.split(' ')[0]}</span><ChevronDown size={14} /></button>
              {profileOpen && <div className="profile-dropdown"><div className="dropdown-user"><strong>{user.name}</strong><small>{user.role} account</small></div><Link to="/profile">My profile</Link><Link to="/history">Donation history</Link><button onClick={signOut}><LogOut size={15} /> Sign out</button></div>}
            </div>
          </> : <><Link to="/login" className="nav-login">Log in</Link><Link to="/register" className="button button-primary nav-cta"><HeartHandshake size={16} /> Join the bridge</Link></>}
        </nav>
      </div>
    </header>
    <main className="main-content"><Outlet /></main>
    <footer className="site-footer">
      <div className="footer-main"><div className="footer-brand-block"><Link to="/" className="brand footer-brand"><span className="brand-icon"><Leaf size={21} fill="currentColor" /></span><span>foodbridge<span className="brand-period">.</span><small>GOOD FOOD, SHARED WELL</small></span></Link><p>Making every meal matter. Connecting surplus food with the communities who need it most.</p></div><div className="footer-links"><div><strong>Discover</strong><Link to="/donations">Find food</Link><Link to="/register">Donate food</Link><Link to="/guidelines">Food safety</Link></div><div><strong>FoodBridge</strong><Link to="/#how-it-works">How it works</Link><Link to="/reports/new">Report a concern</Link><Link to="/login">Sign in</Link></div></div></div>
      <div className="footer-bottom"><span>© {new Date().getFullYear()} FoodBridge. Good food deserves a good home.</span><span><Leaf size={14} /> Built for people, planet & possibility</span></div>
    </footer>
  </div>;
}

export function Guard({ children, roles }) {
  const { user, loading } = useAuth();
  const location = useLocation();
  if (loading) return <Loading label="Checking your session..." />;
  if (!user) return <NavigateToLogin from={location} />;
  if (roles && !roles.includes(user.role)) return <div className="restricted-state"><ShieldCheck size={30} /><h2>That space is for another role</h2><p>Use your {user.role.toLowerCase()} dashboard instead.</p><Link className="button button-primary" to={user.role === 'Admin' ? '/dashboard/admin' : user.role === 'NGO' ? '/dashboard/ngo' : '/dashboard/donor'}>Go to my dashboard</Link></div>;
  return children;
}
function NavigateToLogin({ from }) { const location = from; return <div className="auth-required"><div className="auth-required-card"><span className="auth-icon"><ShieldCheck /></span><h2>Sign in to continue</h2><p>Your account keeps pickup requests and food listings safe.</p><Link className="button button-primary" to="/login" state={{ from: location }}>Sign in</Link><small>New to FoodBridge? <Link to="/register">Create an account</Link></small></div></div>; }

export function DashNav({ role, title, children }) {
  const { user } = useAuth();
  const location = useLocation();
  const links = role === 'Donor'
    ? [['Overview', '/dashboard/donor', '⌂'], ['My listings', '/dashboard/donor#listings', '◈'], ['Pickup requests', '/dashboard/donor#requests', '↗'], ['History & impact', '/history', '✳']]
    : role === 'NGO'
      ? [['Find food', '/dashboard/ngo', '⌕'], ['My requests', '/dashboard/ngo#requests', '↗'], ['Donation history', '/history', '✳']]
      : [['Overview', '/dashboard/admin', '⌂'], ['People & partners', '/dashboard/admin?tab=users', '♙'], ['Listings', '/dashboard/admin?tab=listings', '◈'], ['Pickup requests', '/dashboard/admin?tab=requests', '↗'], ['Safety reports', '/dashboard/admin?tab=reports', '⚑'], ['Categories', '/dashboard/admin?tab=categories', '▦']];
  const selected = (label, href) => {
    if (role === 'Admin') {
      const requestedTab = new URLSearchParams(href.split('?')[1] || '').get('tab');
      const activeTab = new URLSearchParams(location.search).get('tab');
      return location.pathname === '/dashboard/admin' && (requestedTab ? requestedTab === activeTab : !activeTab || activeTab === 'overview');
    }
    if (role === 'Donor') {
      if (href === '/history') return location.pathname === '/history';
      if (location.pathname !== '/dashboard/donor') return false;
      return label === 'Overview' ? !location.hash : label === 'My listings' ? location.hash === '#listings' : location.hash === '#requests';
    }
    if (role === 'NGO') {
      if (href === '/history') return location.pathname === '/history';
      if (location.pathname !== '/dashboard/ngo') return false;
      return label === 'My requests' ? location.hash === '#requests' : location.hash !== '#requests';
    }
    return false;
  };
  return <div className="dashboard-shell"><aside className="dashboard-sidebar"><div className="sidebar-user"><Avatar user={user} /><div><strong>{user?.organizationName || user?.name}</strong><small>{role === 'Admin' ? 'Platform administrator' : `${role} account`}</small></div></div><div className="sidebar-nav-label">WORKSPACE</div><nav>{links.map(([label, href, icon]) => <NavLink key={label} to={href} className={() => `sidebar-link ${selected(label, href) ? 'sidebar-active' : ''}`}><span className="sidebar-glyph">{icon}</span>{label}</NavLink>)}</nav><div className="sidebar-help"><span><CircleHelp size={16} /></span><strong>Need a hand?</strong><p>FoodBridge is here to help keep every handoff safe.</p><Link to="/guidelines">Read our safety guide <ArrowRight size={13} /></Link></div></aside><section className="dashboard-main"><div className="dashboard-mobile-title"><strong>{title}</strong></div>{children}</section></div>;
}
