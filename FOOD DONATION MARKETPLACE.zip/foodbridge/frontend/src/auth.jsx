import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { api } from './api';

const AuthContext = createContext(null);
export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    const token = localStorage.getItem('foodbridge_token');
    if (!token) { setUser(null); setLoading(false); return null; }
    try {
      const { data } = await api.get('/auth/me');
      setUser(data.user);
      return data.user;
    } catch {
      localStorage.removeItem('foodbridge_token');
      setUser(null);
      return null;
    } finally { setLoading(false); }
  }, []);

  useEffect(() => { refresh(); }, [refresh]);

  const acceptSession = useCallback((data) => {
    localStorage.setItem('foodbridge_token', data.token);
    setUser(data.user);
    return data.user;
  }, []);

  const login = useCallback(async (credentials) => {
    const { data } = await api.post('/auth/login', credentials);
    return acceptSession(data);
  }, [acceptSession]);

  const register = useCallback(async (profile) => {
    const { data } = await api.post('/auth/register', profile);
    return acceptSession(data);
  }, [acceptSession]);

  const logout = useCallback(async () => {
    try { if (localStorage.getItem('foodbridge_token')) await api.post('/auth/logout'); } catch { /* Client session is cleared even if the API is offline. */ }
    localStorage.removeItem('foodbridge_token');
    setUser(null);
  }, []);

  const value = useMemo(() => ({ user, loading, login, register, logout, refresh, setUser }), [user, loading, login, register, logout, refresh]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
export const useAuth = () => useContext(AuthContext);
