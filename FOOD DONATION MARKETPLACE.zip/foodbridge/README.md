# FoodBridge — Food Donation Marketplace

FoodBridge is a full-stack MERN-style marketplace that connects restaurants, hotels, supermarkets, event organizers and individuals with NGOs and community kitchens. It supports the complete donation journey: publish food → discover nearby listings → request a pickup → approve and reserve quantity → collect → complete the handoff and update impact totals.

The project is organized into separate `frontend/` and `backend/` workspaces. MongoDB/Mongoose is the production persistence path. For a zero-setup hackathon demo, the API uses a small **persistent local JSON store** when `MONGO_URI` is not set; this fallback runs the same REST workflows and survives restarts, rather than returning mock API responses. Set `MONGO_URI` to use MongoDB.

## Features

- Responsive green-and-white React interface, React Router, reusable components, form feedback, loading/empty states and mobile navigation.
- Donor, NGO and Admin roles with protected dashboards and server-side authorization checks.
- Registration, login, logout with JWT session revocation, password hashing (bcrypt), forgot/reset flow, profile editing and password changes.
- Donation CRUD with image uploads (JPG/PNG/WebP data URLs), quantity, servings, dietary type, preparation and expiry times, allergens, pickup location/window and contact details.
- Search with city/address matching, category, vegetarian/non-vegetarian, quantity and expiry filters, sorting and server pagination. Location discovery works as a list and requires no paid map key.
- Pickup requests with duplicate-request prevention, donor approval/rejection, quantity reservation, cancellation, pickup confirmation and completion. Concurrent approvals cannot reserve more than the listed stock.
- Database-backed notifications for requests, approvals, rejections, handoffs and expiring listings. The UI checks for updates every 15 seconds; the API checks expiry every five minutes.
- Live impact summaries from stored donation/request/user records, food-safety reporting and admin tools for NGO verification, account suspension, listing moderation, report review and category management.
- Downloadable CSV pickup history, seeded demonstration accounts/listings, a custom 404 page and food-safety guidance.
- Automated API journey test covering registration through pickup completion, reservations, impact totals, reporting, password reset and logout.

## Requirements

- Node.js 20+ and npm 9+.
- Optional: Docker Desktop/Engine for a local MongoDB, or a MongoDB Atlas connection string.

## Install and run

From the repository root:

```bash
npm install
```

### Option A — quick demo (no MongoDB installation)

Do **not** create `backend/.env`, or leave `MONGO_URI` unset. The backend starts with a persistent local file store at `backend/data/foodbridge.json` and seeds demo users, categories and food records the first time it starts.

```bash
npm run dev
```

- React app: <http://localhost:5173>
- API health: <http://localhost:5000/api/health>

### Option B — MongoDB (recommended for normal development)

Start a local MongoDB 7 container from the repository root:

```bash
docker compose up -d mongodb
```

Copy the example environment file and set the MongoDB URI and a private JWT secret:

```bash
cp backend/.env.example backend/.env
```

Edit `backend/.env`:

```dotenv
PORT=5000
NODE_ENV=development
CLIENT_URL=http://localhost:5173
JWT_SECRET=use-a-long-random-secret-here
MONGO_URI=mongodb://127.0.0.1:27017/foodbridge
ADMIN_EMAIL=admin@foodbridge.demo
ADMIN_PASSWORD=Admin123!
```

Then run:

```bash
npm run dev
```

For MongoDB Atlas, replace `MONGO_URI` with the Atlas connection string, URL-encode special characters in the password, and allow the development machine’s IP in the Atlas network-access rules. Do not commit `.env` or production secrets. `docker compose down` stops MongoDB; `docker compose down -v` also deletes its persisted volume.

### Run individual services

```bash
npm run dev --workspace foodbridge-api
npm run dev --workspace foodbridge-web -- --host 0.0.0.0
```

The Vite development server proxies relative `/api` calls to `http://127.0.0.1:5000`. For a deployment, serve the built React app from a static host and configure the frontend API base/proxy and `CLIENT_URL` for the actual domain.

## Environment variables

| Variable | Required | Purpose |
|---|---:|---|
| `PORT` | No | Express port; defaults to `5000`. |
| `NODE_ENV` | No | Set `production` to suppress the development reset token in the forgot-password response. |
| `CLIENT_URL` | No | Allowed frontend origin(s), comma-separated; defaults to permissive CORS for local demo use. Configure explicit trusted origins in production. |
| `JWT_SECRET` | Yes for deployment | Secret used to sign seven-day JWTs. A development-only fallback exists; set a long random value before deployment. |
| `MONGO_URI` | No for quick demo; recommended otherwise | MongoDB connection string. If omitted, the persistent JSON demo store is used. If configured but MongoDB is unavailable, startup fails clearly rather than silently changing databases. |
| `ADMIN_EMAIL` | No | Email for the first seeded administrator; defaults to `admin@foodbridge.demo`. |
| `ADMIN_PASSWORD` | No | Password for the first seeded administrator; defaults to `Admin123!`. Change it before deployment. |

You can generate a secret with `node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"`.

## Demonstration accounts

On a fresh database/store, FoodBridge creates:

| Role | Email | Password |
|---|---|---|
| Donor | `demo.donor@foodbridge.demo` | `Demo123!` |
| Verified NGO | `demo.ngo@foodbridge.demo` | `Demo123!` |
| Admin | `admin@foodbridge.demo` | `Admin123!` |

The donor dashboard has a sample pending pickup request; the marketplace has current sample listings and completed pickup history. The first startup seeds these only when the donations collection is empty. In production, set a private admin email/password before the first boot and change/remove all demonstration credentials.

### Create/verify an administrator

Public signup intentionally permits only Donor and NGO roles. On startup the API creates one administrator from `ADMIN_EMAIL` and `ADMIN_PASSWORD` if that email does not already exist. In the demo UI, sign in as the administrator above and open **People & partners** to verify NGO accounts, suspend/restore accounts, and manage moderation. If you change the admin environment variables after an account has already been created, the stored password is not silently overwritten; update it via the signed-in account settings or use the database’s account recovery process.

## Test and build

```bash
npm test
npm run build
```

The end-to-end test starts an isolated in-process HTTP listener and checks the real API workflow, including competing quantity requests. It cleans up its test-created records after the run. The build output is written to `frontend/dist/`.

## Main API endpoints

All API paths are prefixed with `/api`. JSON errors use `{ "message": "..." }`. Protected calls use `Authorization: Bearer <JWT>`. User-facing responses never include password hashes or reset-token hashes.

### Authentication and account

| Method | Path | Access | Description |
|---|---|---|---|
| `POST` | `/auth/register` | Public | Register as `Donor` or `NGO`; admin signup is rejected. |
| `POST` | `/auth/login` | Public | Verify credentials and issue a signed JWT. |
| `POST` | `/auth/logout` | Signed in | Increment the account token version, revoking the current session and any other outstanding tokens. |
| `GET` | `/auth/me` | Signed in | Return the current safe profile. |
| `POST` | `/auth/forgot-password` | Public | Create a one-time, 30-minute reset token. In development the response includes `resetToken` so a demo can proceed without SMTP. Production receives a generic response; connect an email provider before production use. |
| `POST` | `/auth/reset-password` | Public | Exchange a valid reset token for a bcrypt-hashed password. |
| `PATCH` | `/auth/change-password` | Signed in | Verify current password and change it. |
| `GET`, `PUT` | `/users/me` | Signed in | Read/update editable profile fields and profile photo. |

### Food listings and pickup workflow

| Method | Path | Access | Description |
|---|---|---|---|
| `GET` | `/donations` | Public | Browse available food. Query params: `search`, `city`, `category`, `foodType`, `minQuantity`, `expiryWithinHours`, `sort=newest\|expiry\|quantity`, `page`, `limit`. |
| `GET` | `/donations?mine=1` | Donor/Admin | View your own listings (including non-active statuses). |
| `GET` | `/donations?all=1` | Admin | View all listings, including expired/completed. |
| `GET` | `/donations/:id` | Public | View listing details and pickup information. |
| `POST` | `/donations` | Donor | Create a listing. `quantity` is the number of portions/packs; `servings` is the full listing’s estimated meals. |
| `PUT` | `/donations/:id` | Owner/Admin | Update a listing, with quantity and ownership validation. |
| `DELETE` | `/donations/:id` | Owner/Admin | Remove a listing. Donors must first resolve active requests; admins can remove and cancel active requests. |
| `POST` | `/donations/:id/requests` | NGO | Request a quantity and pickup time; duplicate active NGO/listing requests are blocked. |
| `GET` | `/pickup-requests` | Signed in | Donors see requests to their listings, NGOs see their requests, admins see all. |
| `PATCH` | `/pickup-requests/:id/approve` | Listing donor/Admin | Approve and atomically reserve the requested quantity. |
| `PATCH` | `/pickup-requests/:id/reject` | Listing donor/Admin | Reject a waiting request. |
| `PATCH` | `/pickup-requests/:id/cancel` | Requesting NGO/Admin | Cancel a waiting or approved request; approved quantity is released. |
| `PATCH` | `/pickup-requests/:id/picked-up` | Requesting NGO/Admin | Mark an approved handoff as collected. |
| `PATCH` | `/pickup-requests/:id/complete` | Donor, requesting NGO or Admin | Complete the handoff, update collected quantity and impact totals. |

Request states are `Requested`, `Approved`, `Rejected`, `Picked Up`, `Completed` and `Cancelled`; short-lived `Approving`/`Completing` states are used internally to protect atomic stock updates. Listing status is recalculated as `Available`, `Requested`, `Approved`, `Completed` or `Expired` (and retained in the database for dashboards).

### Notifications, impact, safety and admin

| Method | Path | Access | Description |
|---|---|---|---|
| `GET` | `/stats/impact` | Public | Live platform impact totals. Add `?scope=me` for a signed-in donor/NGO’s associated records. |
| `GET` | `/notifications` | Signed in | Get the latest 100 notifications and unread count. |
| `PATCH` | `/notifications/:id/read`, `/notifications/read-all` | Signed in | Mark notifications as read. |
| `GET` | `/history.csv` | Signed in | Download the account’s pickup history as CSV. |
| `GET`, `POST` | `/reports` | Signed in | Submit a safety/trust report and view your reports. Admins see all reports. |
| `PATCH` | `/admin/reports/:id` | Admin | Set report status to Open, In Review, Resolved or Dismissed. |
| `GET` | `/categories` | Public | List donation categories. |
| `POST`, `DELETE` | `/admin/categories`, `/admin/categories/:id` | Admin | Add/remove categories (in-use categories cannot be deleted). |
| `GET` | `/admin/users` | Admin | Search/filter users with pagination. |
| `PATCH` | `/admin/users/:id` | Admin | Verify an NGO or suspend/restore an account. |
| `GET` | `/admin/analytics` | Admin | Current impact, users, donations, categories and pickup status totals. |
| `GET` | `/health` | Public | API and database mode health check. |

## Food safety, expiry and location notes

- The donor form validates required fields and rejects expiry times in the past. The API independently validates all donation data, image type/size, phone, dates, request quantity and role permissions.
- The expiry checker updates listings and sends deduplicated notifications for expired and within-24-hour food. Its scheduler runs in the API process every five minutes.
- Image uploads are stored inline as a data URL in MongoDB or the local demo store, capped at 4 MB per image. A production deployment can replace this with object storage.
- Nearby discovery is a city/address-filtered list and works without a map API key. A map provider can be added later without changing the pickup workflow.
- Estimated kilograms saved are calculated from completed meal estimates at 0.45 kg per meal. Dashboard totals come from persisted donation and pickup records, including the seeded demonstration history.

## Project structure

```text
foodbridge/
├── backend/
│   ├── src/                 # Express API, Mongoose schemas, store adapter and seed logic
│   ├── test/                 # Real API end-to-end test
│   └── .env.example
├── frontend/
│   ├── src/pages/            # Landing, auth, search, dashboards, details and account pages
│   ├── src/components.jsx    # Shared navigation, cards, status UI and feedback
│   └── src/styles.css        # Responsive UI system
├── docker-compose.yml
└── README.md
```

## Upload to GitHub

1. Create an empty GitHub repository (do not add a second README if you already have this one).
2. From the project root:

   ```bash
   git init
   git add .
   git commit -m "Build FoodBridge food donation marketplace"
   git branch -M main
   git remote add origin https://github.com/<your-user>/<your-repository>.git
   git push -u origin main
   ```

3. Verify `.env`, `node_modules/`, build output and the runtime JSON database are not committed; the repository `.gitignore` excludes them.
4. For a hosted demo, deploy the API with a managed MongoDB URI and secure `JWT_SECRET`, configure `CLIENT_URL`, set a private initial admin account, then deploy the built React app with API requests proxied to the API domain.
