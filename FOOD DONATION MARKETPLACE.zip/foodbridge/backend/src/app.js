const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const crypto = require('node:crypto');
const store = require('./store');

const app = express();
const router = express.Router();
app.disable('x-powered-by');
app.use(cors({ origin: process.env.CLIENT_URL ? process.env.CLIENT_URL.split(',').map((s) => s.trim()) : true, credentials: true }));
app.use(express.json({ limit: '8mb' }));
app.use(express.urlencoded({ extended: true, limit: '8mb' }));

class HttpError extends Error {
  constructor(status, message, details) { super(message); this.status = status; this.details = details; }
}
const route = (handler) => (req, res, next) => Promise.resolve(handler(req, res, next)).catch(next);
const fail = (status, message, details) => { throw new HttpError(status, message, details); };
const idOf = (record) => String(record?.id || record?._id || '');
const cleanText = (value, max = 2000) => String(value ?? '').trim().slice(0, max);
const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const validPhone = (phone) => !phone || /^[+\d() .-]{7,24}$/.test(phone);
const validDate = (value) => value && !Number.isNaN(new Date(value).getTime());
const activeRequestStatuses = new Set(['Requested', 'Approving', 'Approved', 'Picked Up', 'Completing']);
const closeRequestStatuses = new Set(['Rejected', 'Completed', 'Cancelled']);
const safeNumber = (value, fallback = 0) => Number.isFinite(Number(value)) ? Number(value) : fallback;

function sanitizeUser(user) {
  if (!user) return null;
  const { password, passwordResetTokenHash, passwordResetExpires, _id, ...rest } = user;
  return { ...rest, id: idOf(user), _id: undefined };
}
function userSelf(user) {
  const clean = sanitizeUser(user);
  if (!clean) return null;
  return {
    id: clean.id, name: clean.name, email: clean.email, role: clean.role, phone: clean.phone || '',
    address: clean.address || '', city: clean.city || '', organizationName: clean.organizationName || '',
    profilePhoto: clean.profilePhoto || '', ngoVerified: Boolean(clean.ngoVerified), suspended: Boolean(clean.suspended),
    createdAt: clean.createdAt, updatedAt: clean.updatedAt
  };
}
function userPublic(user) {
  if (!user) return null;
  return {
    id: idOf(user), name: user.name, role: user.role,
    organizationName: user.organizationName || '', city: user.city || '',
    profilePhoto: user.profilePhoto || '', ngoVerified: Boolean(user.ngoVerified)
  };
}
function parseImage(value) {
  const image = cleanText(value, 7_000_000);
  if (!image) return '';
  if (image.length > 6_500_000) fail(413, 'Image is too large. Please use an image under 4.5 MB.');
  if (/^data:image\/(png|jpe?g|webp);base64,[a-z0-9+/=]+$/i.test(image)) return image;
  if (/^https?:\/\/[^\s]+$/i.test(image)) return image;
  fail(400, 'Please provide a valid JPG, PNG, or WebP image.');
}
function normalizeAllergens(value) {
  const values = Array.isArray(value) ? value : String(value || '').split(',');
  return [...new Set(values.map((item) => cleanText(item, 40)).filter(Boolean))].slice(0, 20);
}
function normalizeDonationInput(body, partial = false) {
  const required = ['name', 'category', 'description', 'quantity', 'servings', 'foodType', 'preparedAt', 'expiryAt', 'pickupAddress', 'city', 'availablePickupTime'];
  if (!partial) {
    const missing = required.filter((field) => body[field] === undefined || body[field] === null || String(body[field]).trim() === '');
    if (missing.length) fail(400, `Please complete all required fields: ${missing.join(', ')}.`);
  }
  const data = {};
  const fields = ['name', 'category', 'description', 'pickupAddress', 'city', 'availablePickupTime', 'contactName', 'contactPhone'];
  for (const field of fields) if (body[field] !== undefined) data[field] = cleanText(body[field], field === 'description' ? 1500 : 160);
  if (data.name !== undefined && (data.name.length < 2 || data.name.length > 100)) fail(400, 'Food name must be between 2 and 100 characters.');
  if (data.category !== undefined && !data.category) fail(400, 'Choose a food category.');
  if (data.description !== undefined && data.description.length < 10) fail(400, 'Description must be at least 10 characters.');
  if (data.city !== undefined && data.city.length < 2) fail(400, 'Enter a valid city.');
  if (data.pickupAddress !== undefined && data.pickupAddress.length < 5) fail(400, 'Enter a pickup address.');
  if (data.availablePickupTime !== undefined && data.availablePickupTime.length < 2) fail(400, 'Enter the available pickup time.');
  if (data.contactPhone !== undefined && !validPhone(data.contactPhone)) fail(400, 'Enter a valid contact phone number.');
  if (body.quantity !== undefined) {
    data.quantity = Number(body.quantity);
    if (!Number.isInteger(data.quantity) || data.quantity < 1 || data.quantity > 100000) fail(400, 'Quantity must be a positive whole number.');
  }
  if (body.servings !== undefined) {
    data.servings = Number(body.servings);
    if (!Number.isInteger(data.servings) || data.servings < 1 || data.servings > 1000000) fail(400, 'Servings must be a positive whole number.');
  }
  if (body.foodType !== undefined) {
    data.foodType = cleanText(body.foodType, 30);
    if (!['Vegetarian', 'Non-vegetarian'].includes(data.foodType)) fail(400, 'Food type must be Vegetarian or Non-vegetarian.');
  }
  for (const field of ['preparedAt', 'expiryAt']) {
    if (body[field] !== undefined) {
      if (!validDate(body[field])) fail(400, `Enter a valid ${field === 'preparedAt' ? 'preparation' : 'expiry'} date and time.`);
      data[field] = new Date(body[field]);
    }
  }
  if (body.allergens !== undefined) data.allergens = normalizeAllergens(body.allergens);
  if (body.image !== undefined) data.image = parseImage(body.image);
  if (body.contactName !== undefined && data.contactName.length > 80) fail(400, 'Contact name is too long.');
  if (data.preparedAt && data.preparedAt.getTime() > Date.now() + 5 * 60_000) fail(400, 'Preparation time cannot be in the future.');
  if (data.expiryAt && data.expiryAt.getTime() <= Date.now()) fail(400, 'Expiry must be a future date and time.');
  if (data.preparedAt && data.expiryAt && data.expiryAt <= data.preparedAt) fail(400, 'Expiry must be after the preparation time.');
  return data;
}
async function assertCategoryExists(category) {
  if (!category) return;
  const categories = await store.all('categories');
  if (!categories.some((item) => item.name.toLowerCase() === category.toLowerCase())) fail(400, 'Choose a valid food category from the FoodBridge list.');
}

async function requireAuth(req, _res, next) {
  try {
    const header = req.headers.authorization || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : '';
    if (!token) return next(new HttpError(401, 'Please sign in to continue.'));
    const payload = jwt.verify(token, process.env.JWT_SECRET || 'foodbridge-local-development-secret-change-me');
    const user = await store.get('users', payload.sub);
    if (!user || Number(payload.ver || 0) !== Number(user.tokenVersion || 0)) return next(new HttpError(401, 'Your session is no longer valid. Please sign in again.'));
    if (user.suspended) return next(new HttpError(403, 'This account has been suspended. Contact FoodBridge support.'));
    req.user = user;
    next();
  } catch (error) {
    if (error instanceof HttpError) return next(error);
    return next(new HttpError(401, 'Your session has expired. Please sign in again.'));
  }
}
function requireRole(...roles) {
  return (req, _res, next) => roles.includes(req.user?.role) ? next() : next(new HttpError(403, 'You do not have permission to do that.'));
}
function requireAdmin(req, res, next) { return requireAuth(req, res, (error) => error ? next(error) : requireRole('Admin')(req, res, next)); }

async function notify(userId, type, title, message, link = '', entityId = '', dedupeKey = '') {
  if (!userId) return null;
  if (dedupeKey) {
    const existing = (await store.all('notifications')).find((n) => n.userId === String(userId) && n.dedupeKey === dedupeKey);
    if (existing) return existing;
  }
  return store.create('notifications', { userId: String(userId), type, title, message, link, entityId: String(entityId || ''), dedupeKey, readAt: null, createdAt: new Date() });
}
async function donationStatus(donationId) {
  const donation = await store.get('donations', donationId);
  if (!donation) return null;
  const now = Date.now();
  const remaining = Number(donation.quantity || 0) - Number(donation.reservedQuantity || 0) - Number(donation.collectedQuantity || 0);
  let status;
  if (Number(donation.collectedQuantity || 0) >= Number(donation.quantity || 0)) status = 'Completed';
  else if (new Date(donation.expiryAt).getTime() <= now) status = 'Expired';
  else if (Number(donation.reservedQuantity || 0) > 0) status = 'Approved';
  else {
    const requests = await store.all('requests');
    status = requests.some((r) => r.donationId === idOf(donation) && ['Requested', 'Approving'].includes(r.status)) ? 'Requested' : 'Available';
    if (remaining <= 0) status = 'Approved';
  }
  if (donation.status !== status) return store.update('donations', idOf(donation), { status });
  return donation;
}
async function donationView(donation, donorMap) {
  if (!donation) return null;
  const donor = donorMap ? donorMap.get(String(donation.donorId)) : await store.get('users', donation.donorId);
  const remaining = Math.max(0, Number(donation.quantity || 0) - Number(donation.reservedQuantity || 0) - Number(donation.collectedQuantity || 0));
  const result = { ...donation, id: idOf(donation), availableQuantity: remaining, donor: userPublic(donor) };
  delete result._id;
  return result;
}
async function requestView(request, donationMap, userMap) {
  const donation = donationMap ? donationMap.get(String(request.donationId)) : await store.get('donations', request.donationId);
  const ngo = userMap ? userMap.get(String(request.ngoId)) : await store.get('users', request.ngoId);
  const donor = userMap ? userMap.get(String(request.donorId)) : await store.get('users', request.donorId);
  const value = { ...request, id: idOf(request), donation: donation ? { id: idOf(donation), name: donation.name, city: donation.city, pickupAddress: donation.pickupAddress, expiryAt: donation.expiryAt, availableQuantity: Math.max(0, Number(donation.quantity || 0) - Number(donation.reservedQuantity || 0) - Number(donation.collectedQuantity || 0)) } : null, ngo: userPublic(ngo), donor: userPublic(donor) };
  delete value._id;
  return value;
}

async function calculateImpact(userId = '') {
  const [donations, requests, users] = await Promise.all([store.all('donations'), store.all('requests'), store.all('users')]);
  let relevantDonations = donations;
  let relevantRequests = requests;
  if (userId) {
    const current = await store.get('users', userId);
    if (current?.role === 'Donor') {
      relevantDonations = donations.filter((d) => d.donorId === userId);
      const donationIds = new Set(relevantDonations.map(idOf));
      relevantRequests = requests.filter((r) => donationIds.has(r.donationId));
    } else if (current?.role === 'NGO') {
      relevantRequests = requests.filter((r) => r.ngoId === userId);
      const relatedIds = new Set(relevantRequests.map((r) => r.donationId));
      relevantDonations = donations.filter((d) => relatedIds.has(idOf(d)));
    }
    else if (current?.role === 'Admin') { /* all records */ }
  }
  const byId = new Map(donations.map((d) => [idOf(d), d]));
  const completed = relevantRequests.filter((r) => r.status === 'Completed');
  const mealsProvided = completed.reduce((sum, request) => {
    const donation = byId.get(String(request.donationId));
    if (!donation) return sum + Number(request.quantity || 0);
    return sum + Math.round((Number(donation.servings || 0) * Number(request.quantity || 0)) / Math.max(1, Number(donation.quantity || 1)));
  }, 0);
  const active = donations.filter((d) => new Date(d.expiryAt).getTime() > Date.now() && Number(d.quantity) - Number(d.reservedQuantity || 0) - Number(d.collectedQuantity || 0) > 0);
  const donorIds = new Set(active.map((d) => d.donorId));
  const activeDonors = users.filter((u) => u.role === 'Donor' && !u.suspended && donorIds.has(idOf(u))).length;
  const participatingNgos = new Set(requests.filter((r) => r.status !== 'Cancelled' && r.status !== 'Rejected').map((r) => r.ngoId)).size;
  return {
    totalDonations: relevantDonations.length,
    activeListings: relevantDonations.filter((d) => new Date(d.expiryAt).getTime() > Date.now() && Number(d.quantity) - Number(d.reservedQuantity || 0) - Number(d.collectedQuantity || 0) > 0).length,
    mealsProvided,
    kilogramsSaved: Math.round(mealsProvided * 0.45 * 10) / 10,
    completedPickups: relevantRequests.filter((r) => r.status === 'Completed').length,
    pendingRequests: relevantRequests.filter((r) => r.status === 'Requested').length,
    activeDonors,
    participatingNgos
  };
}

async function expireAndAlert() {
  const now = Date.now();
  const within = now + 24 * 60 * 60 * 1000;
  const [donations, requests] = await Promise.all([store.all('donations'), store.all('requests')]);
  for (const original of donations) {
    const d = await store.get('donations', idOf(original));
    if (!d) continue;
    const expiry = new Date(d.expiryAt).getTime();
    const outstanding = Number(d.quantity || 0) - Number(d.collectedQuantity || 0);
    if (outstanding <= 0 || d.status === 'Completed') continue;
    if (expiry <= now && d.status !== 'Expired') {
      await store.update('donations', idOf(d), { status: 'Expired' });
      await notify(d.donorId, 'expired', 'Food listing expired', `${d.name} has passed its expiry time. Please review its listing.`, `/donations/${idOf(d)}`, idOf(d), `expired:${idOf(d)}`);
      for (const r of requests.filter((item) => item.donationId === idOf(d) && activeRequestStatuses.has(item.status))) {
        await notify(r.ngoId, 'expired', 'Pickup needs attention', `${d.name} has expired. Contact the donor if collection was already arranged.`, `/donations/${idOf(d)}`, idOf(d), `expired:${idOf(d)}:${r.ngoId}`);
      }
    } else if (expiry <= within && expiry > now) {
      const involved = new Set([String(d.donorId), ...requests.filter((item) => item.donationId === idOf(d) && activeRequestStatuses.has(item.status)).map((r) => String(r.ngoId))]);
      for (const userId of involved) await notify(userId, 'expiring', 'Food expires within 24 hours', `${d.name} in ${d.city} is approaching its expiry time.`, `/donations/${idOf(d)}`, idOf(d), `expiring:${idOf(d)}:${userId}`);
    }
  }
}

// Health and a small public API index help with local setup and monitoring.
app.get('/api/health', (_req, res) => res.json({ ok: true, service: 'FoodBridge API', database: store.mode, time: new Date().toISOString() }));
app.get('/api', (_req, res) => res.json({ name: 'FoodBridge API', version: '1.0.0', docs: 'See README.md for the endpoint reference.' }));

// Authentication: admin accounts are created by seed/configuration, never by public registration.
router.post('/auth/register', route(async (req, res) => {
  const name = cleanText(req.body.name, 80);
  const email = cleanText(req.body.email, 160).toLowerCase();
  const password = String(req.body.password || '');
  const role = cleanText(req.body.role, 20);
  if (name.length < 2) fail(400, 'Name must be at least 2 characters.');
  if (!emailPattern.test(email)) fail(400, 'Enter a valid email address.');
  if (password.length < 8 || password.length > 100) fail(400, 'Password must be 8–100 characters.');
  if (!['Donor', 'NGO'].includes(role)) fail(400, 'Choose Donor or NGO. Admin accounts are created by the administrator.');
  if (role === 'NGO' && cleanText(req.body.organizationName, 100).length < 2) fail(400, 'NGO registration requires an organization name.');
  if (req.body.phone && !validPhone(req.body.phone)) fail(400, 'Enter a valid phone number.');
  if ((await store.all('users')).some((user) => user.email === email)) fail(409, 'An account with this email already exists.');
  let user;
  try {
    user = await store.create('users', {
      name, email, password: await bcrypt.hash(password, 12), role,
      phone: cleanText(req.body.phone, 30), address: cleanText(req.body.address, 180), city: cleanText(req.body.city, 80),
      organizationName: cleanText(req.body.organizationName, 100), profilePhoto: parseImage(req.body.profilePhoto),
      ngoVerified: false, suspended: false, tokenVersion: 0, createdAt: new Date(), updatedAt: new Date()
    });
  } catch (error) {
    if (error.code === 11000) fail(409, 'An account with this email already exists.');
    throw error;
  }
  const token = jwt.sign({ sub: idOf(user), role: user.role, ver: Number(user.tokenVersion || 0) }, process.env.JWT_SECRET || 'foodbridge-local-development-secret-change-me', { expiresIn: '7d' });
  res.status(201).json({ token, user: userSelf(user), message: 'Your FoodBridge account is ready.' });
}));
router.post('/auth/login', route(async (req, res) => {
  const email = cleanText(req.body.email, 160).toLowerCase();
  const password = String(req.body.password || '');
  const user = (await store.all('users')).find((item) => item.email === email);
  if (!user || !(await bcrypt.compare(password, user.password || ''))) fail(401, 'Email or password is incorrect.');
  if (user.suspended) fail(403, 'This account has been suspended. Contact FoodBridge support.');
  const token = jwt.sign({ sub: idOf(user), role: user.role, ver: Number(user.tokenVersion || 0) }, process.env.JWT_SECRET || 'foodbridge-local-development-secret-change-me', { expiresIn: '7d' });
  res.json({ token, user: userSelf(user), message: 'Welcome back.' });
}));
router.post('/auth/logout', requireAuth, route(async (req, res) => {
  await store.update('users', idOf(req.user), { tokenVersion: Number(req.user.tokenVersion || 0) + 1 });
  res.json({ message: 'Signed out successfully.' });
}));
router.get('/auth/me', requireAuth, (req, res) => res.json({ user: userSelf(req.user) }));
router.post('/auth/forgot-password', route(async (req, res) => {
  const email = cleanText(req.body.email, 160).toLowerCase();
  const user = (await store.all('users')).find((item) => item.email === email);
  const response = { message: 'If an account exists for that email, password reset instructions have been prepared.' };
  if (user) {
    const token = crypto.randomBytes(32).toString('hex');
    const tokenHash = crypto.createHash('sha256').update(token).digest('hex');
    await store.update('users', idOf(user), { passwordResetTokenHash: tokenHash, passwordResetExpires: new Date(Date.now() + 30 * 60 * 1000) });
    // In development the link is returned so a hackathon demo can reset without an SMTP account.
    if (process.env.NODE_ENV !== 'production') response.resetToken = token;
  }
  res.json(response);
}));
router.post('/auth/reset-password', route(async (req, res) => {
  const token = cleanText(req.body.token, 200);
  const password = String(req.body.password || '');
  if (password.length < 8 || password.length > 100) fail(400, 'New password must be 8–100 characters.');
  if (!token) fail(400, 'Reset token is required.');
  const tokenHash = crypto.createHash('sha256').update(token).digest('hex');
  const user = (await store.all('users')).find((item) => item.passwordResetTokenHash === tokenHash && new Date(item.passwordResetExpires).getTime() > Date.now());
  if (!user) fail(400, 'This reset link is invalid or has expired. Request a new one.');
  await store.update('users', idOf(user), { password: await bcrypt.hash(password, 12), passwordResetTokenHash: '', passwordResetExpires: null });
  res.json({ message: 'Password reset complete. You can now sign in.' });
}));
router.patch('/auth/change-password', requireAuth, route(async (req, res) => {
  const currentPassword = String(req.body.currentPassword || '');
  const newPassword = String(req.body.newPassword || '');
  if (!(await bcrypt.compare(currentPassword, req.user.password || ''))) fail(400, 'Current password is incorrect.');
  if (newPassword.length < 8 || newPassword.length > 100) fail(400, 'New password must be 8–100 characters.');
  await store.update('users', idOf(req.user), { password: await bcrypt.hash(newPassword, 12) });
  res.json({ message: 'Password updated successfully.' });
}));

// Food discovery and donor-owned CRUD.
router.get('/donations', route(async (req, res) => {
  const mine = req.query.mine === '1';
  const allAdmin = req.query.all === '1';
  if (mine && !req.headers.authorization) fail(401, 'Please sign in to view your listings.');
  let current = null;
  if (mine || allAdmin) {
    const header = req.headers.authorization || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : '';
    if (!token) fail(401, 'Please sign in to continue.');
    let payload;
    try {
      payload = jwt.verify(token, process.env.JWT_SECRET || 'foodbridge-local-development-secret-change-me');
      current = await store.get('users', payload.sub);
    } catch { fail(401, 'Please sign in again.'); }
    if (!current || current.suspended || Number(payload.ver || 0) !== Number(current.tokenVersion || 0)) fail(401, 'Please sign in again.');
    if (mine && !['Donor', 'Admin'].includes(current.role)) fail(403, 'Only donors can view donor listings.');
    if (allAdmin && current.role !== 'Admin') fail(403, 'Administrator access is required.');
  }
  let items = await store.all('donations');
  if (mine) items = items.filter((d) => current.role === 'Admin' ? true : d.donorId === idOf(current));
  else if (!allAdmin) items = items.filter((d) => new Date(d.expiryAt).getTime() > Date.now() && Number(d.quantity) - Number(d.reservedQuantity || 0) - Number(d.collectedQuantity || 0) > 0 && d.status !== 'Expired' && d.status !== 'Completed');
  if (req.query.search) {
    const term = cleanText(req.query.search, 100).toLowerCase();
    items = items.filter((d) => `${d.name} ${d.category} ${d.description} ${d.city}`.toLowerCase().includes(term));
  }
  if (req.query.city) {
    const city = cleanText(req.query.city, 80).toLowerCase();
    items = items.filter((d) => String(d.city).toLowerCase().includes(city) || String(d.pickupAddress).toLowerCase().includes(city));
  }
  if (req.query.category) items = items.filter((d) => d.category.toLowerCase() === cleanText(req.query.category, 80).toLowerCase());
  if (req.query.foodType) items = items.filter((d) => d.foodType === cleanText(req.query.foodType, 30));
  if (req.query.status) items = items.filter((d) => d.status === cleanText(req.query.status, 40));
  if (req.query.minQuantity) items = items.filter((d) => Number(d.quantity) - Number(d.reservedQuantity || 0) - Number(d.collectedQuantity || 0) >= safeNumber(req.query.minQuantity));
  if (req.query.expiryWithinHours) items = items.filter((d) => new Date(d.expiryAt).getTime() <= Date.now() + safeNumber(req.query.expiryWithinHours) * 3600000);
  const sort = String(req.query.sort || 'newest');
  items.sort((a, b) => sort === 'expiry' ? new Date(a.expiryAt) - new Date(b.expiryAt) : sort === 'quantity' ? (Number(b.quantity) - Number(b.reservedQuantity || 0) - Number(b.collectedQuantity || 0)) - (Number(a.quantity) - Number(a.reservedQuantity || 0) - Number(a.collectedQuantity || 0)) : new Date(b.createdAt || 0) - new Date(a.createdAt || 0));
  const total = items.length;
  const page = Math.max(1, safeNumber(req.query.page, 1));
  const limit = Math.min(100, Math.max(1, safeNumber(req.query.limit, 12)));
  const pageItems = items.slice((page - 1) * limit, page * limit);
  const users = await store.all('users');
  const donorMap = new Map(users.map((u) => [idOf(u), u]));
  const rendered = await Promise.all(pageItems.map((d) => donationView(d, donorMap)));
  res.json({ items: rendered, total, page, pages: Math.max(1, Math.ceil(total / limit)), limit });
}));
router.get('/donations/:id', route(async (req, res) => {
  const donation = await store.get('donations', req.params.id);
  if (!donation) fail(404, 'Food listing not found.');
  res.json({ donation: await donationView(donation) });
}));
router.post('/donations', requireAuth, requireRole('Donor'), route(async (req, res) => {
  const data = normalizeDonationInput(req.body);
  await assertCategoryExists(data.category);
  const donation = await store.create('donations', {
    ...data, donorId: idOf(req.user), reservedQuantity: 0, collectedQuantity: 0, status: 'Available', isSample: false, createdAt: new Date(), updatedAt: new Date()
  });
  res.status(201).json({ donation: await donationView(donation), message: 'Food listing published.' });
}));
router.put('/donations/:id', requireAuth, route(async (req, res) => {
  const donation = await store.get('donations', req.params.id);
  if (!donation) fail(404, 'Food listing not found.');
  if (req.user.role !== 'Admin' && donation.donorId !== idOf(req.user)) fail(403, 'You can only edit your own food listings.');
  const data = normalizeDonationInput(req.body, true);
  await assertCategoryExists(data.category);
  if (data.quantity !== undefined && data.quantity < Number(donation.reservedQuantity || 0) + Number(donation.collectedQuantity || 0)) fail(400, 'Quantity cannot be lower than already reserved or collected food.');
  const updated = await store.update('donations', idOf(donation), { ...data, updatedAt: new Date() });
  await donationStatus(idOf(donation));
  res.json({ donation: await donationView(updated), message: 'Food listing updated.' });
}));
router.delete('/donations/:id', requireAuth, route(async (req, res) => {
  const donation = await store.get('donations', req.params.id);
  if (!donation) fail(404, 'Food listing not found.');
  if (req.user.role !== 'Admin' && donation.donorId !== idOf(req.user)) fail(403, 'You can only remove your own food listings.');
  const requests = (await store.all('requests')).filter((r) => r.donationId === idOf(donation));
  if (req.user.role !== 'Admin' && requests.some((r) => activeRequestStatuses.has(r.status))) fail(409, 'This listing has an active pickup request. Resolve or cancel it before deleting.');
  if (req.user.role === 'Admin') {
    for (const request of requests.filter((r) => activeRequestStatuses.has(r.status))) {
      await store.update('requests', idOf(request), { status: 'Cancelled', activeKey: null });
      await notify(request.ngoId, 'listing_removed', 'Food listing removed', `${donation.name} was removed by an administrator.`, '/dashboard', idOf(donation));
    }
  }
  await store.remove('donations', idOf(donation));
  res.json({ message: 'Food listing removed.' });
}));

// Pickup workflow. Approved quantities are reserved atomically so competing requests cannot over-claim stock.
router.post('/donations/:id/requests', requireAuth, requireRole('NGO'), route(async (req, res) => {
  const donation = await store.get('donations', req.params.id);
  if (!donation) fail(404, 'Food listing not found.');
  const remaining = Number(donation.quantity) - Number(donation.reservedQuantity || 0) - Number(donation.collectedQuantity || 0);
  if (new Date(donation.expiryAt).getTime() <= Date.now() || remaining <= 0) fail(409, 'This food is no longer available.');
  const quantity = Number(req.body.quantity);
  if (!Number.isInteger(quantity) || quantity < 1) fail(400, 'Enter a valid pickup quantity.');
  if (quantity > remaining) fail(409, `Only ${remaining} portion${remaining === 1 ? '' : 's'} remain available.`);
  const active = (await store.all('requests')).find((r) => r.donationId === idOf(donation) && r.ngoId === idOf(req.user) && activeRequestStatuses.has(r.status));
  if (active) fail(409, 'You already have an active pickup request for this listing.');
  const pickupAt = req.body.pickupAt;
  if (!validDate(pickupAt) || new Date(pickupAt).getTime() < Date.now() - 60_000) fail(400, 'Choose a pickup time in the future.');
  if (new Date(pickupAt).getTime() > new Date(donation.expiryAt).getTime()) fail(400, 'Pickup must be before the food expiry time.');
  let request;
  try {
    request = await store.create('requests', {
      donationId: idOf(donation), donorId: donation.donorId, ngoId: idOf(req.user), activeKey: `${idOf(donation)}:${idOf(req.user)}`, foodName: donation.name, city: donation.city,
      quantity, pickupAt: new Date(pickupAt), message: cleanText(req.body.message, 500), status: 'Requested', createdAt: new Date(), updatedAt: new Date()
    });
  } catch (error) {
    if (error.code === 11000) fail(409, 'You already have an active pickup request for this listing.');
    throw error;
  }
  await donationStatus(idOf(donation));
  await notify(donation.donorId, 'pickup_request', 'New pickup request', `${req.user.organizationName || req.user.name} requested ${quantity} portion${quantity === 1 ? '' : 's'} of ${donation.name}.`, '/dashboard', idOf(request));
  res.status(201).json({ request: await requestView(request), message: 'Pickup request sent to the donor.' });
}));
router.get('/pickup-requests', requireAuth, route(async (req, res) => {
  let items = await store.all('requests');
  if (req.user.role === 'Donor') items = items.filter((r) => r.donorId === idOf(req.user));
  else if (req.user.role === 'NGO') items = items.filter((r) => r.ngoId === idOf(req.user));
  items.sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0));
  const [donations, users] = await Promise.all([store.all('donations'), store.all('users')]);
  const donationMap = new Map(donations.map((d) => [idOf(d), d]));
  const userMap = new Map(users.map((u) => [idOf(u), u]));
  res.json({ items: await Promise.all(items.map((r) => requestView(r, donationMap, userMap))) });
}));
router.patch('/pickup-requests/:id/approve', requireAuth, route(async (req, res) => {
  const request = await store.get('requests', req.params.id);
  if (!request) fail(404, 'Pickup request not found.');
  if (req.user.role !== 'Admin' && (req.user.role !== 'Donor' || request.donorId !== idOf(req.user))) fail(403, 'Only the donor can approve this request.');
  const donationForApproval = await store.get('donations', request.donationId);
  if (!donationForApproval || new Date(donationForApproval.expiryAt).getTime() <= Date.now()) fail(409, 'This food has expired and can no longer be approved.');
  const claiming = await store.compareAndSetStatus('requests', idOf(request), 'Requested', { status: 'Approving', updatedAt: new Date() });
  if (!claiming) fail(409, 'This request has already been updated. Refresh and try again.');
  const reserved = await store.reserveDonation(request.donationId, Number(request.quantity));
  if (!reserved) {
    await store.compareAndSetStatus('requests', idOf(request), 'Approving', { status: 'Requested', updatedAt: new Date() });
    fail(409, 'There is not enough unreserved food remaining to approve this request.');
  }
  await store.update('requests', idOf(request), { status: 'Approved', updatedAt: new Date() });
  await donationStatus(request.donationId);
  await notify(request.ngoId, 'request_approved', 'Pickup request approved', `Your request for ${request.foodName} was approved. Coordinate the pickup time with the donor.`, `/donations/${request.donationId}`, idOf(request));
  res.json({ message: 'Request approved and quantity reserved.', request: await requestView(await store.get('requests', idOf(request))) });
}));
router.patch('/pickup-requests/:id/reject', requireAuth, route(async (req, res) => {
  const request = await store.get('requests', req.params.id);
  if (!request) fail(404, 'Pickup request not found.');
  if (req.user.role !== 'Admin' && (req.user.role !== 'Donor' || request.donorId !== idOf(req.user))) fail(403, 'Only the donor can reject this request.');
  const updated = await store.compareAndSetStatus('requests', idOf(request), 'Requested', { status: 'Rejected', activeKey: null, updatedAt: new Date() });
  if (!updated) fail(409, 'Only a waiting request can be rejected.');
  await donationStatus(request.donationId);
  await notify(request.ngoId, 'request_rejected', 'Pickup request not approved', `The donor could not approve your request for ${request.foodName}.`, `/donations/${request.donationId}`, idOf(request));
  res.json({ message: 'Request rejected.', request: await requestView(updated) });
}));
router.patch('/pickup-requests/:id/picked-up', requireAuth, route(async (req, res) => {
  const request = await store.get('requests', req.params.id);
  if (!request) fail(404, 'Pickup request not found.');
  if (req.user.role !== 'Admin' && (req.user.role !== 'NGO' || request.ngoId !== idOf(req.user))) fail(403, 'Only the requesting NGO can confirm collection.');
  const updated = await store.compareAndSetStatus('requests', idOf(request), 'Approved', { status: 'Picked Up', updatedAt: new Date() });
  if (!updated) fail(409, 'Only an approved pickup can be marked collected.');
  await donationStatus(request.donationId);
  await notify(request.donorId, 'picked_up', 'Food collected', `${request.foodName} was marked as picked up by the NGO.`, '/dashboard', idOf(request));
  res.json({ message: 'Pickup marked as collected. Confirm completion when the handoff is done.', request: await requestView(updated) });
}));
router.patch('/pickup-requests/:id/complete', requireAuth, route(async (req, res) => {
  const request = await store.get('requests', req.params.id);
  if (!request) fail(404, 'Pickup request not found.');
  if (req.user.role !== 'Admin' && !((req.user.role === 'NGO' && request.ngoId === idOf(req.user)) || (req.user.role === 'Donor' && request.donorId === idOf(req.user)))) fail(403, 'Only the donor or requesting NGO can complete this pickup.');
  const completing = await store.compareAndSetStatus('requests', idOf(request), 'Picked Up', { status: 'Completing', updatedAt: new Date() });
  if (!completing) fail(409, 'Mark the pickup as collected before completing it.');
  const changed = await store.releaseDonation(request.donationId, Number(request.quantity), true);
  if (!changed) {
    await store.compareAndSetStatus('requests', idOf(request), 'Completing', { status: 'Picked Up', updatedAt: new Date() });
    fail(409, 'The reserved quantity could not be reconciled. Please contact support.');
  }
  const completed = await store.update('requests', idOf(request), { status: 'Completed', activeKey: null, updatedAt: new Date() });
  await donationStatus(request.donationId);
  await notify(request.donorId, 'pickup_completed', 'Pickup completed', `${request.quantity} portion${request.quantity === 1 ? '' : 's'} of ${request.foodName} have been recorded as rescued.`, '/history', idOf(request));
  if (request.ngoId !== request.donorId) await notify(request.ngoId, 'pickup_completed', 'Pickup completed', `Thank you for rescuing ${request.foodName}.`, '/history', idOf(request));
  res.json({ message: 'Pickup completed and impact totals updated.', request: await requestView(completed) });
}));
router.patch('/pickup-requests/:id/cancel', requireAuth, route(async (req, res) => {
  const request = await store.get('requests', req.params.id);
  if (!request) fail(404, 'Pickup request not found.');
  if (req.user.role !== 'Admin' && (req.user.role !== 'NGO' || request.ngoId !== idOf(req.user))) fail(403, 'Only the requesting NGO can cancel this request.');
  if (!['Requested', 'Approved'].includes(request.status)) fail(409, 'This request can no longer be cancelled.');
  const previous = request.status;
  const updated = await store.compareAndSetStatus('requests', idOf(request), previous, { status: 'Cancelled', activeKey: null, updatedAt: new Date() });
  if (!updated) fail(409, 'This request has already changed. Refresh and try again.');
  if (previous === 'Approved') await store.releaseDonation(request.donationId, Number(request.quantity), false);
  await donationStatus(request.donationId);
  await notify(request.donorId, 'request_cancelled', 'Pickup request cancelled', `${req.user.organizationName || req.user.name} cancelled the request for ${request.foodName}.`, '/dashboard', idOf(request));
  res.json({ message: 'Pickup request cancelled.', request: await requestView(updated) });
}));

// Profile and account settings.
router.get('/users/me', requireAuth, (req, res) => res.json({ user: userSelf(req.user) }));
router.put('/users/me', requireAuth, route(async (req, res) => {
  const patch = {};
  for (const field of ['name', 'phone', 'address', 'city', 'organizationName']) {
    if (req.body[field] !== undefined) patch[field] = cleanText(req.body[field], field === 'name' ? 80 : 180);
  }
  if (patch.name !== undefined && patch.name.length < 2) fail(400, 'Name must be at least 2 characters.');
  if (patch.phone !== undefined && !validPhone(patch.phone)) fail(400, 'Enter a valid phone number.');
  if (req.body.profilePhoto !== undefined) patch.profilePhoto = parseImage(req.body.profilePhoto);
  const updated = await store.update('users', idOf(req.user), { ...patch, updatedAt: new Date() });
  res.json({ user: userSelf(updated), message: 'Profile saved.' });
}));

// Impact and downloadable report data.
router.get('/stats/impact', route(async (req, res) => {
  let userId = '';
  if (req.query.scope === 'me') {
    const header = req.headers.authorization || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : '';
    if (!token) fail(401, 'Please sign in to view your personal impact.');
    let payload;
    try { payload = jwt.verify(token, process.env.JWT_SECRET || 'foodbridge-local-development-secret-change-me'); userId = payload.sub; }
    catch { fail(401, 'Please sign in again.'); }
    const current = await store.get('users', userId);
    if (!current || current.suspended || Number(payload.ver || 0) !== Number(current.tokenVersion || 0)) fail(401, 'Please sign in again.');
  }
  res.json(await calculateImpact(userId));
}));
router.get('/history.csv', requireAuth, route(async (req, res) => {
  const requests = await store.all('requests');
  const filtered = req.user.role === 'Admin' ? requests : req.user.role === 'Donor' ? requests.filter((r) => r.donorId === idOf(req.user)) : requests.filter((r) => r.ngoId === idOf(req.user));
  const donations = new Map((await store.all('donations')).map((d) => [idOf(d), d]));
  const users = new Map((await store.all('users')).map((u) => [idOf(u), u]));
  const csvCell = (value) => `"${String(value ?? '').replaceAll('"', '""').replace(/[\r\n]+/g, ' ')}"`;
  const rows = [['Food', 'City', 'Donor / NGO', 'Quantity', 'Pickup time', 'Status', 'Requested at']];
  for (const r of filtered) {
    const d = donations.get(r.donationId);
    const counterpart = req.user.role === 'Donor' ? users.get(r.ngoId) : users.get(r.donorId);
    rows.push([r.foodName || d?.name || 'Food listing', r.city || d?.city || '', counterpart?.organizationName || counterpart?.name || '', r.quantity, r.pickupAt ? new Date(r.pickupAt).toLocaleString('en-IN') : '', r.status, r.createdAt ? new Date(r.createdAt).toLocaleString('en-IN') : '']);
  }
  const csv = '\ufeff' + rows.map((row) => row.map(csvCell).join(',')).join('\r\n');
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', 'attachment; filename="foodbridge-donation-history.csv"');
  res.send(csv);
}));

// Notifications are database-backed and the client refreshes them periodically (no paid realtime service required).
router.get('/notifications', requireAuth, route(async (req, res) => {
  const items = (await store.all('notifications')).filter((n) => n.userId === idOf(req.user)).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).slice(0, 100);
  res.json({ items: items.map((n) => ({ ...n, id: idOf(n), _id: undefined })), unreadCount: items.filter((n) => !n.readAt).length });
}));
router.patch('/notifications/read-all', requireAuth, route(async (req, res) => {
  const unread = (await store.all('notifications')).filter((n) => n.userId === idOf(req.user) && !n.readAt);
  for (const item of unread) await store.update('notifications', idOf(item), { readAt: new Date() });
  res.json({ message: 'All notifications marked as read.' });
}));
router.patch('/notifications/:id/read', requireAuth, route(async (req, res) => {
  const item = await store.get('notifications', req.params.id);
  if (!item) fail(404, 'Notification not found.');
  if (item.userId !== idOf(req.user)) fail(403, 'You can only update your notifications.');
  const updated = item.readAt ? item : await store.update('notifications', idOf(item), { readAt: new Date() });
  res.json({ notification: { ...updated, id: idOf(updated), _id: undefined } });
}));

// Reports: any signed-in user can file a safety or trust-and-safety report; only admins can moderate.
router.post('/reports', requireAuth, route(async (req, res) => {
  const subject = cleanText(req.body.subject, 120);
  const category = cleanText(req.body.category, 80);
  const details = cleanText(req.body.details, 1500);
  if (subject.length < 4 || category.length < 3 || details.length < 12) fail(400, 'Add a clear subject, report type, and at least 12 characters of detail.');
  const targetType = ['Donation', 'User', 'Other'].includes(req.body.targetType) ? req.body.targetType : 'Other';
  const report = await store.create('reports', {
    reporterId: idOf(req.user), targetType, targetId: cleanText(req.body.targetId, 100), subject, category, details,
    status: 'Open', createdAt: new Date(), updatedAt: new Date()
  });
  const admins = (await store.all('users')).filter((u) => u.role === 'Admin' && !u.suspended);
  for (const admin of admins) await notify(idOf(admin), 'new_report', 'A new safety report was submitted', subject, '/dashboard/admin?tab=reports', idOf(report));
  res.status(201).json({ report: { ...report, id: idOf(report), _id: undefined }, message: 'Report sent to the FoodBridge safety team.' });
}));
router.get('/reports', requireAuth, route(async (req, res) => {
  let reports = await store.all('reports');
  if (req.user.role !== 'Admin') reports = reports.filter((r) => r.reporterId === idOf(req.user));
  reports.sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0));
  const users = new Map((await store.all('users')).map((u) => [idOf(u), u]));
  res.json({ items: reports.map((r) => ({ ...r, id: idOf(r), reporter: userPublic(users.get(r.reporterId)), _id: undefined })) });
}));

// Categories are admin-managed; default categories are seeded on startup.
router.get('/categories', route(async (_req, res) => {
  const items = (await store.all('categories')).sort((a, b) => a.name.localeCompare(b.name));
  res.json({ items: items.map((item) => ({ id: idOf(item), name: item.name })) });
}));
router.post('/admin/categories', requireAuth, requireRole('Admin'), route(async (req, res) => {
  const name = cleanText(req.body.name, 60);
  if (name.length < 2) fail(400, 'Category name must be at least 2 characters.');
  if ((await store.all('categories')).some((item) => item.name.toLowerCase() === name.toLowerCase())) fail(409, 'That category already exists.');
  const category = await store.create('categories', { name, createdAt: new Date() });
  res.status(201).json({ category: { id: idOf(category), name: category.name }, message: 'Category added.' });
}));
router.delete('/admin/categories/:id', requireAuth, requireRole('Admin'), route(async (req, res) => {
  const category = await store.get('categories', req.params.id);
  if (!category) fail(404, 'Category not found.');
  if ((await store.all('donations')).some((d) => d.category.toLowerCase() === category.name.toLowerCase())) fail(409, 'This category is in use by a listing and cannot be removed yet.');
  await store.remove('categories', idOf(category));
  res.json({ message: 'Category removed.' });
}));

// Administrator control center.
router.get('/admin/users', requireAuth, requireRole('Admin'), route(async (req, res) => {
  let users = await store.all('users');
  const q = cleanText(req.query.search, 100).toLowerCase();
  if (q) users = users.filter((u) => `${u.name} ${u.email} ${u.organizationName} ${u.city}`.toLowerCase().includes(q));
  if (req.query.role) users = users.filter((u) => u.role === req.query.role);
  users.sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0));
  const page = Math.max(1, safeNumber(req.query.page, 1));
  const limit = Math.min(100, Math.max(1, safeNumber(req.query.limit, 50)));
  res.json({ items: users.slice((page - 1) * limit, page * limit).map(userSelf), total: users.length, page, pages: Math.max(1, Math.ceil(users.length / limit)) });
}));
router.patch('/admin/users/:id', requireAuth, requireRole('Admin'), route(async (req, res) => {
  const target = await store.get('users', req.params.id);
  if (!target) fail(404, 'User not found.');
  const patch = {};
  if (req.body.suspended !== undefined) {
    if (typeof req.body.suspended !== 'boolean') fail(400, 'Suspended must be a boolean value.');
    if (target.role === 'Admin' && target.id === idOf(req.user) && req.body.suspended) fail(400, 'You cannot suspend your own administrator account.');
    patch.suspended = Boolean(req.body.suspended);
  }
  if (req.body.ngoVerified !== undefined) {
    if (typeof req.body.ngoVerified !== 'boolean') fail(400, 'ngoVerified must be a boolean value.');
    if (target.role !== 'NGO') fail(400, 'Only NGO accounts can be verified.');
    patch.ngoVerified = req.body.ngoVerified;
  }
  if (!Object.keys(patch).length) fail(400, 'Choose an account action.');
  const updated = await store.update('users', idOf(target), { ...patch, updatedAt: new Date() });
  res.json({ user: userSelf(updated), message: 'Account updated.' });
}));
router.get('/admin/analytics', requireAuth, requireRole('Admin'), route(async (_req, res) => {
  const [impact, users, donations, requests] = await Promise.all([calculateImpact(), store.all('users'), store.all('donations'), store.all('requests')]);
  const byCategory = {};
  for (const donation of donations) byCategory[donation.category] = (byCategory[donation.category] || 0) + 1;
  const byStatus = {};
  for (const request of requests) byStatus[request.status] = (byStatus[request.status] || 0) + 1;
  res.json({ impact, userCounts: { total: users.length, donors: users.filter((u) => u.role === 'Donor').length, ngos: users.filter((u) => u.role === 'NGO').length, admins: users.filter((u) => u.role === 'Admin').length }, donationCount: donations.length, requestCount: requests.length, byCategory, byRequestStatus: byStatus });
}));
router.patch('/admin/reports/:id', requireAuth, requireRole('Admin'), route(async (req, res) => {
  const report = await store.get('reports', req.params.id);
  if (!report) fail(404, 'Report not found.');
  const status = cleanText(req.body.status, 30);
  if (!['Open', 'In Review', 'Resolved', 'Dismissed'].includes(status)) fail(400, 'Choose a valid report status.');
  const updated = await store.update('reports', idOf(report), { status, updatedAt: new Date() });
  await notify(report.reporterId, 'report_update', 'Your report was reviewed', `Your report “${report.subject}” is now ${status.toLowerCase()}.`, '/reports', idOf(report));
  res.json({ report: { ...updated, id: idOf(updated), _id: undefined }, message: 'Report status updated.' });
}));

app.use('/api', router);
app.use((_req, res) => res.status(404).json({ message: 'API endpoint not found.' }));
app.use((error, _req, res, _next) => {
  if (res.headersSent) return;
  const status = error.status || (error.name === 'ValidationError' ? 400 : error.code === 11000 ? 409 : 500);
  const message = status >= 500 ? 'Something went wrong. Please try again.' : error.message;
  if (status >= 500) console.error(error);
  res.status(status).json({ message, ...(error.details ? { details: error.details } : {}) });
});

async function seedDemo() {
  const defaults = [
    { email: 'demo.donor@foodbridge.demo', password: 'Demo123!', role: 'Donor', name: 'Aarav Mehta', organizationName: 'Green Spoon Kitchen', phone: '+91 98765 43210', address: '12 Jubilee Hills Road', city: 'Hyderabad' },
    { email: 'demo.ngo@foodbridge.demo', password: 'Demo123!', role: 'NGO', name: 'Ananya Rao', organizationName: 'Hope Community Kitchen', phone: '+91 98765 43211', address: 'Banjara Hills', city: 'Hyderabad', ngoVerified: true },
    { email: process.env.ADMIN_EMAIL || 'admin@foodbridge.demo', password: process.env.ADMIN_PASSWORD || 'Admin123!', role: 'Admin', name: 'FoodBridge Admin', organizationName: 'FoodBridge', phone: '', address: '', city: 'Hyderabad' }
  ];
  const foundUsers = await store.all('users');
  const byEmail = new Map(foundUsers.map((u) => [u.email, u]));
  for (const data of defaults) {
    if (byEmail.has(data.email)) continue;
    const { password, ...profile } = data;
    await store.create('users', { ...profile, password: await bcrypt.hash(password, 12), ngoVerified: Boolean(data.ngoVerified), suspended: false, profilePhoto: '', createdAt: new Date(), updatedAt: new Date() });
  }
  const existingCategories = await store.all('categories');
  if (!existingCategories.length) {
    for (const name of ['Prepared meals', 'Bakery', 'Produce', 'Dairy', 'Grains & staples', 'Packaged food', 'Beverages', 'Other']) await store.create('categories', { name, createdAt: new Date() });
  }
  const existingDonations = await store.all('donations');
  if (!existingDonations.length) {
    const users = await store.all('users');
    const donor = users.find((u) => u.email === 'demo.donor@foodbridge.demo');
    const ngo = users.find((u) => u.email === 'demo.ngo@foodbridge.demo');
    if (donor && ngo) {
      const now = Date.now();
      const first = await store.create('donations', {
        donorId: idOf(donor), name: 'Fresh market vegetable boxes', category: 'Produce', description: 'Seasonal tomatoes, greens and root vegetables from today’s market. Clean, sorted and packed for community kitchens.',
        quantity: 18, servings: 45, foodType: 'Vegetarian', preparedAt: new Date(now - 60 * 60 * 1000), expiryAt: new Date(now + 20 * 60 * 60 * 1000),
        pickupAddress: '12 Jubilee Hills Road, near the community park', city: 'Hyderabad', availablePickupTime: 'Today, 4:00 PM – 8:00 PM', image: '', allergens: [],
        contactName: donor.name, contactPhone: donor.phone, reservedQuantity: 0, collectedQuantity: 0, status: 'Requested', isSample: true, createdAt: new Date(now - 30 * 60 * 1000), updatedAt: new Date()
      });
      await store.create('requests', {
        donationId: idOf(first), donorId: idOf(donor), ngoId: idOf(ngo), activeKey: `${idOf(first)}:${idOf(ngo)}`, foodName: first.name, city: first.city, quantity: 6,
        pickupAt: new Date(now + 3 * 60 * 60 * 1000), message: 'We can collect this afternoon for our community kitchen.', status: 'Requested', createdAt: new Date(now - 10 * 60 * 1000), updatedAt: new Date()
      });
      await store.create('donations', {
        donorId: idOf(donor), name: 'Bakery bread & breakfast packs', category: 'Bakery', description: 'Individually packed assorted bread rolls and breakfast pastries, prepared this morning and stored safely.',
        quantity: 24, servings: 24, foodType: 'Vegetarian', preparedAt: new Date(now - 2 * 60 * 60 * 1000), expiryAt: new Date(now + 30 * 60 * 60 * 1000),
        pickupAddress: '12 Jubilee Hills Road, loading entrance', city: 'Hyderabad', availablePickupTime: 'Tomorrow, 7:00 AM – 10:00 AM', image: '', allergens: ['Wheat', 'Gluten', 'Dairy'],
        contactName: donor.name, contactPhone: donor.phone, reservedQuantity: 0, collectedQuantity: 0, status: 'Available', isSample: true, createdAt: new Date(now - 2 * 60 * 60 * 1000), updatedAt: new Date()
      });
      const completedDonation = await store.create('donations', {
        donorId: idOf(donor), name: 'Community lunch rice & lentils', category: 'Prepared meals', description: 'A safely prepared, vegetarian community lunch batch shared with a local shelter.',
        quantity: 30, servings: 60, foodType: 'Vegetarian', preparedAt: new Date(now - 8 * 86400000), expiryAt: new Date(now - 7 * 86400000),
        pickupAddress: '12 Jubilee Hills Road', city: 'Hyderabad', availablePickupTime: 'Completed', image: '', allergens: [], contactName: donor.name, contactPhone: donor.phone,
        reservedQuantity: 0, collectedQuantity: 30, status: 'Completed', isSample: true, createdAt: new Date(now - 8 * 86400000), updatedAt: new Date(now - 7 * 86400000)
      });
      await store.create('requests', {
        donationId: idOf(completedDonation), donorId: idOf(donor), ngoId: idOf(ngo), foodName: completedDonation.name, city: completedDonation.city, quantity: 30,
        pickupAt: new Date(now - 7 * 86400000), message: 'Delivered to the Hope Community Kitchen.', status: 'Completed', createdAt: new Date(now - 8 * 86400000), updatedAt: new Date(now - 7 * 86400000)
      });
      console.log('FoodBridge: seeded demonstration donations and pickup history');
    }
  }
  const existingRequests = await store.all('requests');
  for (const request of existingRequests.filter((item) => activeRequestStatuses.has(item.status) && !item.activeKey)) {
    try { await store.update('requests', idOf(request), { activeKey: `${request.donationId}:${request.ngoId}` }); }
    catch (error) { if (error.code !== 11000) throw error; }
  }
}

module.exports = { app, seedDemo, expireAndAlert, calculateImpact, HttpError };
