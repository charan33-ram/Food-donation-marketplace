require('dotenv').config();
const { app, seedDemo, expireAndAlert } = require('./app');
const store = require('./store');

const port = Number(process.env.PORT || 5000);

async function start() {
  await store.connect();
  await seedDemo();
  await expireAndAlert();
  const server = app.listen(port, '0.0.0.0', () => console.log(`FoodBridge API listening on http://0.0.0.0:${port}`));
  const expiryTimer = setInterval(() => expireAndAlert().catch((error) => console.error('Expiry alert check failed:', error.message)), 5 * 60 * 1000);
  expiryTimer.unref();
  const shutdown = () => {
    clearInterval(expiryTimer);
    server.close(() => process.exit(0));
  };
  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);
}

start().catch((error) => {
  console.error('FoodBridge failed to start:', error.message);
  if (process.env.MONGO_URI) console.error('Check that MongoDB is running and MONGO_URI is correct.');
  process.exit(1);
});
