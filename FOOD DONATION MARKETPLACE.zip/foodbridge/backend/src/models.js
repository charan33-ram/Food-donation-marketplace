const mongoose = require('mongoose');

const { Schema } = mongoose;
const userSchema = new Schema({
  name: { type: String, required: true, trim: true, maxlength: 80 },
  email: { type: String, required: true, lowercase: true, trim: true, unique: true, index: true },
  password: { type: String, required: true, select: false },
  role: { type: String, enum: ['Donor', 'NGO', 'Admin'], required: true },
  phone: { type: String, default: '', trim: true },
  address: { type: String, default: '', trim: true },
  city: { type: String, default: '', trim: true },
  organizationName: { type: String, default: '', trim: true },
  profilePhoto: { type: String, default: '' },
  ngoVerified: { type: Boolean, default: false },
  suspended: { type: Boolean, default: false },
  tokenVersion: { type: Number, default: 0 },
  passwordResetTokenHash: { type: String, default: '' },
  passwordResetExpires: { type: Date, default: null }
}, { timestamps: true, versionKey: false });

const donationSchema = new Schema({
  donorId: { type: String, required: true, index: true },
  name: { type: String, required: true, trim: true, maxlength: 100 },
  category: { type: String, required: true, trim: true, maxlength: 60 },
  description: { type: String, required: true, trim: true, maxlength: 1500 },
  quantity: { type: Number, required: true, min: 1 },
  servings: { type: Number, required: true, min: 1 },
  foodType: { type: String, enum: ['Vegetarian', 'Non-vegetarian'], required: true },
  preparedAt: { type: Date, required: true },
  expiryAt: { type: Date, required: true, index: true },
  pickupAddress: { type: String, required: true, trim: true },
  city: { type: String, required: true, trim: true, index: true },
  availablePickupTime: { type: String, required: true, trim: true },
  image: { type: String, default: '' },
  allergens: { type: [String], default: [] },
  contactName: { type: String, default: '', trim: true },
  contactPhone: { type: String, default: '', trim: true },
  reservedQuantity: { type: Number, default: 0, min: 0 },
  collectedQuantity: { type: Number, default: 0, min: 0 },
  status: { type: String, enum: ['Available', 'Requested', 'Approved', 'Rejected', 'Picked Up', 'Completed', 'Expired'], default: 'Available', index: true },
  isSample: { type: Boolean, default: false }
}, { timestamps: true, versionKey: false });

const pickupRequestSchema = new Schema({
  donationId: { type: String, required: true, index: true },
  donorId: { type: String, required: true, index: true },
  ngoId: { type: String, required: true, index: true },
  activeKey: { type: String, default: null },
  foodName: { type: String, required: true },
  city: { type: String, default: '' },
  quantity: { type: Number, required: true, min: 1 },
  pickupAt: { type: Date, required: true },
  message: { type: String, default: '', maxlength: 500 },
  status: { type: String, enum: ['Requested', 'Approving', 'Approved', 'Rejected', 'Picked Up', 'Completing', 'Completed', 'Cancelled'], default: 'Requested', index: true }
}, { timestamps: true, versionKey: false });
pickupRequestSchema.index({ activeKey: 1 }, { unique: true, partialFilterExpression: { activeKey: { $type: 'string' } } });

const notificationSchema = new Schema({
  userId: { type: String, required: true, index: true },
  type: { type: String, required: true },
  title: { type: String, required: true },
  message: { type: String, required: true },
  link: { type: String, default: '' },
  entityId: { type: String, default: '' },
  dedupeKey: { type: String, default: '' },
  readAt: { type: Date, default: null },
  createdAt: { type: Date, default: Date.now }
}, { versionKey: false });

const reportSchema = new Schema({
  reporterId: { type: String, required: true, index: true },
  targetType: { type: String, enum: ['Donation', 'User', 'Other'], default: 'Donation' },
  targetId: { type: String, default: '' },
  subject: { type: String, required: true, trim: true, maxlength: 120 },
  category: { type: String, required: true, trim: true, maxlength: 80 },
  details: { type: String, required: true, trim: true, maxlength: 1500 },
  status: { type: String, enum: ['Open', 'In Review', 'Resolved', 'Dismissed'], default: 'Open', index: true }
}, { timestamps: true, versionKey: false });

const categorySchema = new Schema({ name: { type: String, required: true, trim: true, unique: true } }, { timestamps: true, versionKey: false });

const models = {
  users: mongoose.models.User || mongoose.model('User', userSchema),
  donations: mongoose.models.Donation || mongoose.model('Donation', donationSchema),
  requests: mongoose.models.PickupRequest || mongoose.model('PickupRequest', pickupRequestSchema),
  notifications: mongoose.models.Notification || mongoose.model('Notification', notificationSchema),
  reports: mongoose.models.Report || mongoose.model('Report', reportSchema),
  categories: mongoose.models.Category || mongoose.model('Category', categorySchema)
};

module.exports = { mongoose, models };
