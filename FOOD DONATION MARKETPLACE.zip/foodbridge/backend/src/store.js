const fs = require('node:fs/promises');
const path = require('node:path');
const crypto = require('node:crypto');
const { mongoose, models } = require('./models');

const collections = Object.keys(models);
const filePath = path.join(__dirname, '..', 'data', 'foodbridge.json');
let mode = 'json';
let local = Object.fromEntries(collections.map((name) => [name, []]));
let writeQueue = Promise.resolve();

function idOf(value) { return String(value?.id || value?._id || ''); }
function plain(doc) {
  if (!doc) return null;
  const value = typeof doc.toObject === 'function' ? doc.toObject() : doc;
  const id = idOf(value);
  return { ...value, id, _id: id };
}
function serial(task) {
  const next = writeQueue.then(task, task);
  writeQueue = next.catch(() => {});
  return next;
}
async function persist() {
  await fs.mkdir(path.dirname(filePath), { recursive: true });
  const temporary = `${filePath}.${process.pid}.tmp`;
  await fs.writeFile(temporary, JSON.stringify(local, null, 2), 'utf8');
  await fs.rename(temporary, filePath);
}

async function connect() {
  if (process.env.MONGO_URI) {
    await mongoose.connect(process.env.MONGO_URI, { serverSelectionTimeoutMS: 10000 });
    mode = 'mongo';
    console.log('FoodBridge database: MongoDB connected');
  } else {
    mode = 'json';
    try {
      const contents = await fs.readFile(filePath, 'utf8');
      const saved = JSON.parse(contents);
      for (const name of collections) local[name] = Array.isArray(saved[name]) ? saved[name] : [];
    } catch (error) {
      if (error.code !== 'ENOENT') throw error;
      await persist();
    }
    console.log(`FoodBridge database: persistent local demo store (${filePath})`);
  }
  return mode;
}

async function all(collection) {
  if (!collections.includes(collection)) throw new Error(`Unknown collection: ${collection}`);
  if (mode === 'mongo') {
    const query = models[collection].find({});
    if (collection === 'users') query.select('+password');
    return (await query.lean()).map(plain);
  }
  return structuredClone(local[collection]);
}
async function get(collection, id) {
  if (!collections.includes(collection)) throw new Error(`Unknown collection: ${collection}`);
  if (mode === 'mongo') {
    try {
      const query = models[collection].findById(id);
      if (collection === 'users') query.select('+password');
      return plain(await query.lean());
    } catch (error) { if (error.name === 'CastError') return null; throw error; }
  }
  return structuredClone(local[collection].find((item) => idOf(item) === String(id)) || null);
}
async function create(collection, data) {
  if (!collections.includes(collection)) throw new Error(`Unknown collection: ${collection}`);
  if (mode === 'mongo') return plain(await models[collection].create(data));
  return serial(async () => {
    if (collection === 'requests' && data.activeKey && local.requests.some((item) => item.activeKey === data.activeKey)) {
      const duplicate = new Error('Duplicate active pickup request.');
      duplicate.code = 11000;
      throw duplicate;
    }
    if (collection === 'users' && local.users.some((item) => item.email === data.email)) {
      const duplicate = new Error('An account with this email already exists.');
      duplicate.code = 11000;
      throw duplicate;
    }
    if (collection === 'categories' && local.categories.some((item) => item.name.toLowerCase() === String(data.name).toLowerCase())) {
      const duplicate = new Error('That category already exists.');
      duplicate.code = 11000;
      throw duplicate;
    }
    const value = { ...structuredClone(data), id: crypto.randomUUID(), _id: undefined };
    delete value._id;
    local[collection].push(value);
    await persist();
    return structuredClone(value);
  });
}
async function update(collection, id, patch) {
  if (!collections.includes(collection)) throw new Error(`Unknown collection: ${collection}`);
  if (mode === 'mongo') {
    try { return plain(await models[collection].findByIdAndUpdate(id, { $set: patch }, { new: true, runValidators: true }).lean()); }
    catch (error) { if (error.name === 'CastError') return null; throw error; }
  }
  return serial(async () => {
    const index = local[collection].findIndex((item) => idOf(item) === String(id));
    if (index < 0) return null;
    if (collection === 'requests' && patch.activeKey && local.requests.some((item) => idOf(item) !== String(id) && item.activeKey === patch.activeKey)) {
      const duplicate = new Error('Duplicate active pickup request.');
      duplicate.code = 11000;
      throw duplicate;
    }
    local[collection][index] = { ...local[collection][index], ...structuredClone(patch), id: String(id) };
    await persist();
    return structuredClone(local[collection][index]);
  });
}
async function remove(collection, id) {
  if (!collections.includes(collection)) throw new Error(`Unknown collection: ${collection}`);
  if (mode === 'mongo') {
    try { return plain(await models[collection].findByIdAndDelete(id).lean()); }
    catch (error) { if (error.name === 'CastError') return null; throw error; }
  }
  return serial(async () => {
    const index = local[collection].findIndex((item) => idOf(item) === String(id));
    if (index < 0) return null;
    const [removed] = local[collection].splice(index, 1);
    await persist();
    return structuredClone(removed);
  });
}
async function compareAndSetStatus(collection, id, expectedStatus, patch) {
  if (mode === 'mongo') {
    try {
      return plain(await models[collection].findOneAndUpdate({ _id: id, status: expectedStatus }, { $set: patch }, { new: true, runValidators: true }).lean());
    } catch (error) { if (error.name === 'CastError') return null; throw error; }
  }
  return serial(async () => {
    const item = local[collection].find((record) => idOf(record) === String(id));
    if (!item || item.status !== expectedStatus) return null;
    if (collection === 'requests' && patch.activeKey && local.requests.some((record) => idOf(record) !== String(id) && record.activeKey === patch.activeKey)) {
      const duplicate = new Error('Duplicate active pickup request.');
      duplicate.code = 11000;
      throw duplicate;
    }
    Object.assign(item, structuredClone(patch));
    await persist();
    return structuredClone(item);
  });
}
async function reserveDonation(id, quantity) {
  if (mode === 'mongo') {
    try {
      return plain(await models.donations.findOneAndUpdate({
        _id: id,
        $expr: { $lte: [{ $add: [{ $ifNull: ['$reservedQuantity', 0] }, { $ifNull: ['$collectedQuantity', 0] }, quantity] }, '$quantity'] }
      }, { $inc: { reservedQuantity: quantity } }, { new: true, runValidators: true }).lean());
    } catch (error) { if (error.name === 'CastError') return null; throw error; }
  }
  return serial(async () => {
    const donation = local.donations.find((item) => idOf(item) === String(id));
    if (!donation || (donation.reservedQuantity || 0) + (donation.collectedQuantity || 0) + quantity > donation.quantity) return null;
    donation.reservedQuantity = (donation.reservedQuantity || 0) + quantity;
    await persist();
    return structuredClone(donation);
  });
}
async function releaseDonation(id, quantity, complete = false) {
  if (mode === 'mongo') {
    try {
      const increment = complete
        ? { reservedQuantity: -quantity, collectedQuantity: quantity }
        : { reservedQuantity: -quantity };
      return plain(await models.donations.findOneAndUpdate({ _id: id, reservedQuantity: { $gte: quantity } }, { $inc: increment }, { new: true, runValidators: true }).lean());
    } catch (error) { if (error.name === 'CastError') return null; throw error; }
  }
  return serial(async () => {
    const donation = local.donations.find((item) => idOf(item) === String(id));
    if (!donation || (donation.reservedQuantity || 0) < quantity) return null;
    donation.reservedQuantity -= quantity;
    if (complete) donation.collectedQuantity = (donation.collectedQuantity || 0) + quantity;
    await persist();
    return structuredClone(donation);
  });
}

module.exports = {
  connect, all, get, create, update, remove, compareAndSetStatus, reserveDonation, releaseDonation,
  get mode() { return mode; }, idOf
};
