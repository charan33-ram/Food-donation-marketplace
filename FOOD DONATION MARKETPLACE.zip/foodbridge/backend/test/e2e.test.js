const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });

process.env.NODE_ENV = 'test';
process.env.JWT_SECRET = 'foodbridge-e2e-test-secret-with-enough-entropy';
delete process.env.MONGO_URI;

const store = require('../src/store');
const { app, seedDemo } = require('../src/app');

let server;
let base;
let donorToken;
let donorId;
let ngoToken;
let ngoId;
let secondNgoToken;
let secondNgoId;
let reportId;
let donationId;
const requestIds = [];
const generatedEmails = [];

async function call(path, { method = 'GET', token = '', body } = {}) {
  const response = await fetch(`${base}/api${path}`, {
    method,
    headers: { ...(token ? { Authorization: `Bearer ${token}` } : {}), ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}) },
    ...(body !== undefined ? { body: JSON.stringify(body) } : {})
  });
  const contentType = response.headers.get('content-type') || '';
  const data = contentType.includes('application/json') ? await response.json() : await response.text();
  return { status: response.status, data, headers: response.headers };
}

async function login(email, password) {
  const result = await call('/auth/login', { method: 'POST', body: { email, password } });
  assert.equal(result.status, 200, result.data?.message);
  return result.data;
}

async function cleanTestRecords() {
  const allRequests = await store.all('requests');
  for (const request of allRequests) if (requestIds.includes(request.id) || requestIds.includes(request._id)) await store.remove('requests', request.id || request._id);
  const allNotifications = await store.all('notifications');
  const cleanupEntities = new Set([donationId, reportId, ...requestIds].filter(Boolean).map(String));
  for (const notification of allNotifications) {
    const related = [donorId, ngoId, secondNgoId].filter(Boolean).includes(notification.userId);
    if (cleanupEntities.has(String(notification.entityId)) || related) await store.remove('notifications', notification.id || notification._id);
  }
  if (donationId) await store.remove('donations', donationId);
  const users = await store.all('users');
  for (const user of users) if (generatedEmails.includes(user.email)) await store.remove('users', user.id || user._id);
  const reports = await store.all('reports');
  for (const report of reports) if (reportId && (report.id === reportId || report._id === reportId)) await store.remove('reports', report.id || report._id);
}

test('FoodBridge completes the registration-to-pickup journey end to end', { timeout: 30000 }, async (t) => {
  await store.connect();
  await seedDemo();
  server = app.listen(0, '127.0.0.1');
  await new Promise((resolve) => server.once('listening', resolve));
  base = `http://127.0.0.1:${server.address().port}`;

  try {
    const health = await call('/health');
    assert.equal(health.status, 200);
    assert.equal(health.data.ok, true);

    const suffix = `${Date.now()}-${Math.random().toString(16).slice(2, 8)}`;
    const donorEmail = `e2e.donor.${suffix}@foodbridge.test`;
    const ngoEmail = `e2e.ngo.${suffix}@foodbridge.test`;
    const secondNgoEmail = `e2e.ngo2.${suffix}@foodbridge.test`;
    generatedEmails.push(donorEmail, ngoEmail, secondNgoEmail);

    const donorRegistration = await call('/auth/register', { method: 'POST', body: { name: 'E2E Donor', email: donorEmail, password: 'SecureDemo123!', role: 'Donor', city: 'Hyderabad', phone: '+91 90000 11111', organizationName: 'Test Kitchen' } });
    assert.equal(donorRegistration.status, 201, donorRegistration.data.message);
    assert.ok(donorRegistration.data.token);
    assert.equal(Object.hasOwn(donorRegistration.data.user, 'password'), false);
    donorToken = donorRegistration.data.token;
    donorId = donorRegistration.data.user.id;

    const ngoRegistration = await call('/auth/register', { method: 'POST', body: { name: 'E2E Partner', email: ngoEmail, password: 'SecureDemo123!', role: 'NGO', city: 'Hyderabad', organizationName: 'Test Community Kitchen' } });
    assert.equal(ngoRegistration.status, 201, ngoRegistration.data.message);
    ngoToken = ngoRegistration.data.token;
    ngoId = ngoRegistration.data.user.id;
    const secondNgoRegistration = await call('/auth/register', { method: 'POST', body: { name: 'Second Partner', email: secondNgoEmail, password: 'SecureDemo123!', role: 'NGO', city: 'Hyderabad', organizationName: 'Second Test Kitchen' } });
    assert.equal(secondNgoRegistration.status, 201);
    secondNgoToken = secondNgoRegistration.data.token;
    secondNgoId = secondNgoRegistration.data.user.id;

    const donorLogin = await login(donorEmail, 'SecureDemo123!');
    donorToken = donorLogin.token;
    const ngoLogin = await login(ngoEmail, 'SecureDemo123!');
    ngoToken = ngoLogin.token;

    const now = Date.now();
    const listing = await call('/donations', { method: 'POST', token: donorToken, body: {
      name: 'E2E Community Meal Packs', category: 'Prepared meals', description: 'Fresh vegetarian meal packs prepared safely for same-day community pickup.',
      quantity: 5, servings: 10, foodType: 'Vegetarian', preparedAt: new Date(now - 60 * 60 * 1000).toISOString(), expiryAt: new Date(now + 24 * 60 * 60 * 1000).toISOString(),
      pickupAddress: '10 Test Street, Jubilee Hills', city: 'Hyderabad', availablePickupTime: 'Today, 4 PM – 8 PM', allergens: ['Dairy'], contactName: 'E2E Donor', contactPhone: '+91 90000 11111'
    } });
    assert.equal(listing.status, 201, listing.data.message);
    donationId = listing.data.donation.id;
    assert.equal(listing.data.donation.availableQuantity, 5);

    const browse = await call('/donations?city=Hyderabad&category=Prepared%20meals&sort=expiry');
    assert.equal(browse.status, 200);
    assert.ok(browse.data.items.some((item) => item.id === donationId), 'created food should appear in search results');

    const pickupAt = new Date(Date.now() + 3 * 60 * 60 * 1000).toISOString();
    const firstRequest = await call(`/donations/${donationId}/requests`, { method: 'POST', token: ngoToken, body: { quantity: 4, pickupAt, message: 'We will collect these for our evening meal service.' } });
    assert.equal(firstRequest.status, 201, firstRequest.data.message);
    requestIds.push(firstRequest.data.request.id);
    assert.equal(firstRequest.data.request.status, 'Requested');

    const duplicate = await call(`/donations/${donationId}/requests`, { method: 'POST', token: ngoToken, body: { quantity: 1, pickupAt } });
    assert.equal(duplicate.status, 409, 'duplicate active requests from the same NGO are blocked');

    const secondRequest = await call(`/donations/${donationId}/requests`, { method: 'POST', token: secondNgoToken, body: { quantity: 4, pickupAt } });
    assert.equal(secondRequest.status, 201, secondRequest.data.message);
    requestIds.push(secondRequest.data.request.id);

    const donorQueue = await call('/pickup-requests', { token: donorToken });
    assert.ok(donorQueue.data.items.some((item) => item.id === firstRequest.data.request.id));
    const approval = await call(`/pickup-requests/${firstRequest.data.request.id}/approve`, { method: 'PATCH', token: donorToken });
    assert.equal(approval.status, 200, approval.data.message);
    assert.equal(approval.data.request.status, 'Approved');

    const oversubscribe = await call(`/pickup-requests/${secondRequest.data.request.id}/approve`, { method: 'PATCH', token: donorToken });
    assert.equal(oversubscribe.status, 409, 'a competing request cannot reserve already-claimed portions');
    const reject = await call(`/pickup-requests/${secondRequest.data.request.id}/reject`, { method: 'PATCH', token: donorToken });
    assert.equal(reject.status, 200);

    const reservedListing = await call(`/donations/${donationId}`);
    assert.equal(reservedListing.data.donation.availableQuantity, 1);
    const pickedUp = await call(`/pickup-requests/${firstRequest.data.request.id}/picked-up`, { method: 'PATCH', token: ngoToken });
    assert.equal(pickedUp.status, 200, pickedUp.data.message);
    assert.equal(pickedUp.data.request.status, 'Picked Up');
    const completed = await call(`/pickup-requests/${firstRequest.data.request.id}/complete`, { method: 'PATCH', token: ngoToken });
    assert.equal(completed.status, 200, completed.data.message);
    assert.equal(completed.data.request.status, 'Completed');

    const after = await call(`/donations/${donationId}`);
    assert.equal(after.data.donation.collectedQuantity, 4);
    assert.equal(after.data.donation.availableQuantity, 1);
    const impact = await call('/stats/impact?scope=me', { token: donorToken });
    assert.equal(impact.status, 200);
    assert.ok(impact.data.mealsProvided >= 8, 'completed pickup updates estimated meals');
    assert.ok(impact.data.completedPickups >= 1);

    const notifications = await call('/notifications', { token: ngoToken });
    assert.equal(notifications.status, 200);
    assert.ok(notifications.data.items.some((item) => item.type === 'request_approved'));
    const csv = await call('/history.csv', { token: ngoToken });
    assert.equal(csv.status, 200);
    assert.match(String(csv.data), /E2E Community Meal Packs/);

    const report = await call('/reports', { method: 'POST', token: ngoToken, body: { subject: 'Test report for review', category: 'Incorrect listing information', details: 'This is a test safety report created by the automated end-to-end test.', targetType: 'Donation', targetId: donationId } });
    assert.equal(report.status, 201);
    reportId = report.data.report.id;
    const adminLogin = await login(process.env.ADMIN_EMAIL || 'admin@foodbridge.demo', process.env.ADMIN_PASSWORD || 'Admin123!');
    const adminUsers = await call('/admin/users?limit=100', { token: adminLogin.token });
    assert.equal(adminUsers.status, 200);
    assert.ok(adminUsers.data.items.some((item) => item.id === ngoId));
    const verified = await call(`/admin/users/${ngoId}`, { method: 'PATCH', token: adminLogin.token, body: { ngoVerified: true } });
    assert.equal(verified.status, 200);
    assert.equal(verified.data.user.ngoVerified, true);
    const moderated = await call(`/admin/reports/${reportId}`, { method: 'PATCH', token: adminLogin.token, body: { status: 'In Review' } });
    assert.equal(moderated.status, 200);
    assert.equal(moderated.data.report.status, 'In Review');

    const forgot = await call('/auth/forgot-password', { method: 'POST', body: { email: donorEmail } });
    assert.equal(forgot.status, 200);
    assert.ok(forgot.data.resetToken, 'development mode provides one-time reset token for demo use');
    const reset = await call('/auth/reset-password', { method: 'POST', body: { token: forgot.data.resetToken, password: 'NewSecureDemo123!' } });
    assert.equal(reset.status, 200);
    const resetLogin = await login(donorEmail, 'NewSecureDemo123!');
    const profile = await call('/users/me', { token: resetLogin.token });
    assert.equal(profile.status, 200);
    assert.equal(profile.data.user.role, 'Donor');
    const logout = await call('/auth/logout', { method: 'POST', token: resetLogin.token });
    assert.equal(logout.status, 200);
    const afterLogout = await call('/auth/me', { token: resetLogin.token });
    assert.equal(afterLogout.status, 401, 'logout revokes the current JWT session');
  } finally {
    await cleanTestRecords();
    await new Promise((resolve) => server.close(resolve));
  }
});
